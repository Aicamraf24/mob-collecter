package com.monstercollector;

import com.monstercollector.domain.Abilities;
import com.monstercollector.domain.Ability;
import com.monstercollector.domain.Breeding;
import com.monstercollector.domain.Catalog;
import com.monstercollector.domain.ColorVariant;
import com.monstercollector.domain.CreatureProfile;
import com.monstercollector.domain.Encyclopedia;
import com.monstercollector.domain.Growth;
import com.monstercollector.domain.Hybrid;
import com.monstercollector.domain.Leveling;
import com.monstercollector.domain.Rarity;
import com.monstercollector.combat.AbilityChooser;
import com.monstercollector.combat.Cooldowns;
import com.monstercollector.progression.ExperienceRules;
import com.monstercollector.rig.RigTransforms;
import com.monstercollector.taming.Domestication;
import com.monstercollector.domain.SpawnRules;
import com.monstercollector.domain.Offspring;
import com.monstercollector.domain.Limits;
import com.monstercollector.domain.Sizes;
import com.monstercollector.domain.SpawnTable;
import com.monstercollector.domain.Species;
import com.monstercollector.domain.BaseStats;
import com.monstercollector.rig.Rig;
import com.monstercollector.rig.Rigs;
import com.monstercollector.rig.TexturePacker;

import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Random;

/**
 * Comprobaciones de la lógica pura y de los modelos (sin Minecraft).
 * Ejecutar: java -cp build/catalog-check com.monstercollector.CatalogCheck
 */
public final class CatalogCheck {

    private static int passed = 0;
    private static int failed = 0;

    private static void check(String name, boolean ok) {
        if (ok) {
            passed++;
            System.out.println("  PASS  " + name);
        } else {
            failed++;
            System.out.println("  FAIL  " + name);
        }
    }

    private static boolean throwsIllegalArgument(Runnable action) {
        try {
            action.run();
            return false;
        } catch (IllegalArgumentException expected) {
            return true;
        }
    }

    private static boolean throwsIllegalState(Runnable action) {
        try {
            action.run();
            return false;
        } catch (IllegalStateException expected) {
            return true;
        }
    }

    private static boolean near(double a, double b, double tol) {
        return Math.abs(a - b) <= tol;
    }

    public static void main(String[] args) {
        System.setOut(new PrintStream(System.out, true, StandardCharsets.UTF_8));
        Random rng = new Random(20260611L);

        System.out.println("== Catálogo ==");
        check("hay 44 especies (25 de la especificación + 19 extras)", Species.values().length == 44);
        check("hay al menos 25 especies", Species.values().length >= Catalog.MIN_SPECIES);
        check("validate() no devuelve errores", Catalog.validate().isEmpty());
        check("hay 5 variantes de color", ColorVariant.values().length == 5);
        check("cada variante tiene probabilidad exacta de 0.2",
                java.util.Arrays.stream(ColorVariant.values()).allMatch(v -> near(v.probability(), 0.2, 1e-12)));
        check("hay 220 combinaciones base (44 x 5)", Encyclopedia.totalCombinations() == 220);
        check("hay 3 especies legendarias", java.util.Arrays.stream(Species.values()).filter(s -> s.rarity() == Rarity.LEGENDARY).count() == 3);
        check("reutilización de 1 s es rechazada", throwsIllegalArgument(() -> new Ability("x", "x", Ability.Kind.OFENSIVA, 1, 1.0)));
        check("ofensiva con potencia 0.5 es rechazada", throwsIllegalArgument(() -> new Ability("x", "x", Ability.Kind.OFENSIVA, 5, 0.5)));
        check("estadísticas no positivas son rechazadas", throwsIllegalArgument(() -> new BaseStats(0, 1, 1)));
        check("Abilities.ALL tiene ids únicos", Abilities.ALL.stream().map(Ability::id).distinct().count() == Abilities.ALL.size());
        check("cada variante tiene su índice", ColorVariant.byIndex(5) == ColorVariant.ROJA && ColorVariant.byIndex(-1) == ColorVariant.DORADA);

        System.out.println("== Modelos (rig) ==");
        check("hay un modelo por especie", Rigs.count() == Species.values().length);
        boolean allPacked = true;
        boolean allInside = true;
        boolean allNoOverlap = true;
        boolean allSized = true;
        for (Species s : Species.values()) {
            Rig rig = Rigs.of(s);
            allPacked &= rig.parts().size() >= 3;
            for (Rig.Part p : rig.parts()) {
                allInside &= p.u() >= 0 && p.v() >= 0 && p.u() + p.atlasWidth() <= Rig.ATLAS_SIZE && p.v() + p.atlasHeight() <= Rig.ATLAS_SIZE;
            }
            allNoOverlap &= TexturePacker.overlapFree(rig.parts());
            allSized &= rig.widthBlocks() > 0 && rig.heightBlocks() > 0 && rig.heightBlocks() <= 3.0;
        }
        check("cada modelo tiene al menos 3 piezas", allPacked);
        check("todas las regiones de textura caben en el atlas", allInside);
        check("ninguna región de textura se solapa", allNoOverlap);
        check("hitbox razonable en todas las especies", allSized);
        check("una línea mal formada es rechazada", throwsIllegalArgument(() -> Rig.parse("x", "cuerpo BODY 0 0 0 1 1")));
        check("un rol desconocido es rechazado", throwsIllegalArgument(() -> Rig.parse("x", "cuerpo NADA 0 0 0 1 1 1")));
        check("un nombre de pieza duplicado es rechazado", throwsIllegalArgument(() -> Rig.parse("x", "a BODY 0 0 0 1 1 1\na HEAD 0 0 0 1 1 1")));
        check("un atlas sin espacio se detecta", throwsIllegalState(() -> TexturePacker.pack(
                List.of(new Rig.Part("gigante", Rig.Role.BODY, 0, 0, 0, 100, 100, 100, 0, 0)), Rig.ATLAS_SIZE)));

        System.out.println("== Variantes y rareza (muestreo) ==");
        int samples = 1_000_000;
        int[] variantCount = new int[ColorVariant.COUNT];
        for (int i = 0; i < samples; i++) {
            variantCount[ColorVariant.random(rng).ordinal()]++;
        }
        boolean uniform = true;
        for (int c : variantCount) {
            if (!near((double) c / samples, 0.2, 0.002)) uniform = false;
        }
        check("1.000.000 tiradas: cada variante cae en 20 % ± 0.2 %", uniform);

        List<Species> all = List.of(Species.values());
        int raritySamples = 500_000;
        int[][] byRarityVariant = new int[Rarity.values().length][ColorVariant.COUNT];
        int[] rarityCount = new int[Rarity.values().length];
        for (int i = 0; i < raritySamples; i++) {
            Species s = SpawnTable.pick(all, rng);
            ColorVariant v = ColorVariant.random(rng);
            rarityCount[s.rarity().ordinal()]++;
            byRarityVariant[s.rarity().ordinal()][v.ordinal()]++;
        }
        boolean rarityFollowsWeights =
                near((double) rarityCount[Rarity.COMMON.ordinal()] / raritySamples, 0.60, 0.01)
                && near((double) rarityCount[Rarity.LEGENDARY.ordinal()] / raritySamples, 0.01, 0.003);
        check("la rareza controla la frecuencia (común ≈ 60 %, legendaria ≈ 1 %)", rarityFollowsWeights);

        boolean variantIndependent = true;
        for (Rarity r : Rarity.values()) {
            int total = rarityCount[r.ordinal()];
            if (total < 1000) continue;
            for (int c : byRarityVariant[r.ordinal()]) {
                if (!near((double) c / total, 0.2, 0.03)) variantIndependent = false;
            }
        }
        check("dentro de cada rareza, las variantes siguen siendo 20 % cada una", variantIndependent);

        System.out.println("== Aparición natural ==");
        boolean weightsDecrease = SpawnRules.weight(Rarity.COMMON) > SpawnRules.weight(Rarity.UNCOMMON)
                && SpawnRules.weight(Rarity.UNCOMMON) > SpawnRules.weight(Rarity.RARE)
                && SpawnRules.weight(Rarity.RARE) > SpawnRules.weight(Rarity.EPIC)
                && SpawnRules.weight(Rarity.EPIC) >= SpawnRules.weight(Rarity.LEGENDARY);
        check("las especies raras tienen menos peso de aparición", weightsDecrease);
        boolean groupsValid = true;
        for (Rarity r : Rarity.values()) {
            if (SpawnRules.weight(r) <= 0 || SpawnRules.minGroupSize(r) < 1 || SpawnRules.maxGroupSize(r) < SpawnRules.minGroupSize(r)) groupsValid = false;
        }
        check("pesos y tamaños de grupo válidos para todas las rarezas", groupsValid);
        check("las especies legendarias aparecen en grupos de 1", SpawnRules.maxGroupSize(Rarity.LEGENDARY) == 1);

        System.out.println("== Reproducción ==");
        boolean symmetric = true;
        for (Species a : Species.values()) {
            for (Species b : Species.values()) {
                if (Breeding.canBreed(a, b) != Breeding.canBreed(b, a)) symmetric = false;
            }
        }
        check("la compatibilidad es simétrica", symmetric);
        check("no hay jefes: todas las especies tienen parejas", java.util.Arrays.stream(Species.values()).allMatch(s -> !Breeding.matesOf(s).isEmpty()));
        check("una especie puede reproducirse consigo misma", Breeding.canBreed(Species.VELOCIRAPTOR, Species.VELOCIRAPTOR));
        check("T-Rex y Triceratops no son compatibles", !Breeding.canBreed(Species.TYRANNOSAURUS_REX, Species.TRICERATOPS));
        check("T-Rex y Carnotaurus sí son compatibles (mismo linaje)", Breeding.canBreed(Species.TYRANNOSAURUS_REX, Species.CARNOTAURUS));
        check("Lobo de Sombras y Velociraptor sí son compatibles (par explícito)", Breeding.canBreed(Species.LOBO_DE_SOMBRAS, Species.VELOCIRAPTOR));
        check("Dragón de Cristal y Grifo Salvaje sí son compatibles", Breeding.canBreed(Species.DRAGON_DE_CRISTAL, Species.GRIFO_SALVAJE));
        check("una cría necesita ser adulta para criar", !Breeding.readyToBreed(Growth.newborn(), 0));

        System.out.println("== Híbridos ==");
        Hybrid h1 = Hybrid.breed(Species.TYRANNOSAURUS_REX, Species.CARNOTAURUS, new Random(7));
        Hybrid h2 = Hybrid.breed(Species.CARNOTAURUS, Species.TYRANNOSAURUS_REX, new Random(7));
        check("la clave del híbrido no depende del orden", h1.key().equals(h2.key()) && h1.key().equals("tyrannosaurus_rex+carnotaurus"));
        check("nombre de híbrido determinista (Tyrannotaurus)", h1.name().equals("Tyrannotaurus") && h2.name().equals("Tyrannotaurus"));
        check("la rareza del híbrido es la más alta de sus padres", h1.rarity() == Rarity.EPIC);
        check("la vida del híbrido es la media de los padres con vigor 5 %", near(h1.stats().maxHealth(), (90 + 58) / 2.0 * 1.05, 1e-9));
        check("el mismo seed produce el mismo híbrido", Hybrid.breed(Species.TYRANNOSAURUS_REX, Species.CARNOTAURUS, new Random(7)).equals(h1));
        check("dos ejemplares de la misma especie no generan híbrido", throwsIllegalArgument(() -> Hybrid.breed(Species.VELOCIRAPTOR, Species.VELOCIRAPTOR, rng)));
        check("una combinación incompatible no genera híbrido", throwsIllegalArgument(() -> Hybrid.breed(Species.TYRANNOSAURUS_REX, Species.TRICERATOPS, rng)));
        check("un híbrido de Tyrannotaurus no puede cruzarse con Triceratops", !h1.canBreedWith(Species.TRICERATOPS));
        check("un híbrido de Tyrannotaurus sí puede cruzarse con Allosaurus", h1.canBreedWith(Species.ALLOSAURUS));
        boolean allHybridsValid = true;
        for (Species a : Species.values()) {
            for (Species b : Species.values()) {
                if (a == b || !Breeding.canBreed(a, b)) continue;
                Hybrid h = Hybrid.breed(a, b, rng);
                if (h.abilities().size() > 2 || h.abilities().isEmpty()) allHybridsValid = false;
            }
        }
        check("todos los híbridos compatibles tienen de 1 a 2 habilidades", allHybridsValid);

        System.out.println("== Niveles y experiencia ==");
        CreatureProfile wild = CreatureProfile.wild(Species.VELOCIRAPTOR, ColorVariant.AZUL, 50);
        check("un salvaje empieza en nivel 1 sin experiencia", wild.level() == 1 && wild.xp() == 0);
        check("23 de experiencia suben al nivel 2", wild.gainXp(23).profile().level() == 2);
        check("22 de experiencia no suben de nivel", wild.gainXp(22).profile().level() == 1);
        CreatureProfile.XpGain huge = wild.gainXp(1_000_000L);
        check("el nivel nunca pasa del máximo configurado", huge.profile().level() == 50);
        check("al llegar al máximo la experiencia queda en 0", huge.profile().xp() == 0);
        check("levelsGained coincide con la subida real", huge.levelsGained() == 49);
        check("las estadísticas suben con el nivel", atLevel(wild, 10).currentStats().maxHealth() > wild.currentStats().maxHealth());
        check("el nivel máximo no puede superar 100", throwsIllegalArgument(() -> CreatureProfile.wild(Species.VELOCIRAPTOR, ColorVariant.ROJA, 101)));
        boolean curveIncreases = true;
        for (int lvl = 1; lvl < 100; lvl++) {
            if (Leveling.xpToNextLevel(lvl + 1) <= Leveling.xpToNextLevel(lvl)) curveIncreases = false;
        }
        check("la curva de experiencia crece con el nivel", curveIncreases);

        System.out.println("== Crecimiento ==");
        Growth cria = Growth.newborn();
        check("una cría nueva empieza en etapa CRIA", cria.stage() == Growth.Stage.CRIA && !cria.isAdult());
        check("tras el tiempo completo es adulta", cria.tick(Growth.ADULT_TICKS).isAdult());
        check("alimentar acelera el crecimiento", cria.feed().remainingTicks() == Growth.ADULT_TICKS - Growth.FEED_SPEEDUP_TICKS);
        check("alimentar a un adulto no hace nada", Growth.withRemaining(0).feed().isAdult());

        System.out.println("== Enciclopedia ==");
        Encyclopedia enc = new Encyclopedia();
        check("enciclopedia vacía: 0 %", enc.completionPercent() == 0.0);
        enc.recordSpecimen(Species.VELOCIRAPTOR, ColorVariant.AZUL);
        enc.recordSpecimen(Species.VELOCIRAPTOR, ColorVariant.AZUL);
        check("una combinación de 220 da 100/220 %", near(enc.completionPercent(), 100.0 / 220.0, 1e-9));
        check("cuenta los ejemplares descubiertos", enc.copies(Species.VELOCIRAPTOR, ColorVariant.AZUL) == 2);
        check("lista las variantes que faltan", enc.missingVariants(Species.VELOCIRAPTOR).size() == 4);
        enc.recordHybrid(h1);
        check("los híbridos no suben el porcentaje de colección", near(enc.completionPercent(), 100.0 / 220.0, 1e-9));
        check("los híbridos se registran aparte", enc.hybridsDiscovered() == 1);
        Encyclopedia full = new Encyclopedia();
        for (Species s : Species.values()) for (ColorVariant v : ColorVariant.values()) full.recordSpecimen(s, v);
        check("colección completa: 100 %", near(full.completionPercent(), 100.0, 1e-9));
        check("con colección completa no faltan especies", full.missingSpecies().isEmpty());

        System.out.println("== Combate ==");
        Cooldowns cd = new Cooldowns();
        Ability bite = Abilities.MORDIDA_DEVASTADORA;
        check("sin objetivo y con vida alta no hay habilidad", AbilityChooser.choose(List.of(bite), cd, 0, false, 1.0, rng).isEmpty());
        check("con objetivo se usa la ofensiva lista", AbilityChooser.choose(List.of(bite), cd, 0, true, 1.0, rng).orElse(null) == bite);
        cd.use(bite, 0);
        check("tras usarla, la habilidad no está lista", !cd.isReady(bite, 1));
        check("la reutilización se cumple con el tiempo de la habilidad", cd.isReady(bite, bite.cooldownSeconds() * 20L));
        check("el tiempo restante se calcula bien", cd.remainingTicks(bite, 20) == bite.cooldownSeconds() * 20L - 20);
        check("con la habilidad en espera no hay ataque", AbilityChooser.choose(List.of(bite), cd, 1, true, 1.0, rng).isEmpty());
        Cooldowns cd2 = new Cooldowns();
        Ability shell = Abilities.CAPARAZON;
        check("con poca vida se elige una defensiva", AbilityChooser.choose(List.of(bite, shell), cd2, 0, true, 0.2, rng).orElse(null) == shell);
        check("sin defensiva lista con poca vida, se ataca", AbilityChooser.choose(List.of(bite), cd2, 0, true, 0.2, rng).orElse(null) == bite);
        check("daño ofensivo = ataque x potencia", near(AbilityChooser.damageDealt(bite, 10), 20.0, 1e-9));
        check("una defensiva de potencia 0.5 reduce el daño a la mitad", near(AbilityChooser.damageTaken(10, shell), 5.0, 1e-9));

        System.out.println("== Experiencia ==");
        check("combate: 20 de vida da 5 de experiencia", ExperienceRules.combatXp(20) == 5);
        check("combate: el mínimo es 1", ExperienceRules.combatXp(1) == 1);
        check("exploración: 80 bloques dan 2 de experiencia", ExperienceRules.explorationXp(80) == 2);
        check("exploración: sin movimiento no da nada", ExperienceRules.explorationXp(0) == 0);
        check("alimentar da la experiencia fijada", ExperienceRules.feedXp() == ExperienceRules.FEED_XP);

        System.out.println("== Domesticación ==");
        Domestication notDomesticable = new Domestication(false, true);
        boolean neverTamed = true;
        for (int i = 0; i < 10; i++) neverTamed &= !notDomesticable.feed();
        check("una especie no domesticable nunca se domestica", neverTamed && !notDomesticable.isTamed());
        Domestication pet = new Domestication(true, false);
        check("antes de domesticar no sigue al jugador", !pet.follow());
        pet.feed();
        pet.feed();
        check("con 2 alimentos todavía no está domesticado", !pet.isTamed());
        check("el tercer alimento lo domestica", pet.feed() && pet.isTamed() && pet.mode() == Domestication.Mode.SEGUIR);
        check("puede quedarse quieto", pet.stay() && pet.mode() == Domestication.Mode.QUIETO);
        check("sin anatomía para sentarse no se sienta", !pet.sit());
        Domestication dog = new Domestication(true, true);
        for (int i = 0; i < Domestication.FOOD_TO_TAME; i++) dog.feed();
        check("con anatomía para sentarse, se sienta", dog.sit() && dog.mode() == Domestication.Mode.SENTADO);
        check("un domesticado defiende a su dueño", dog.defendsOwner());

        System.out.println("== Modelos de cría e híbrido ==");
        boolean babiesFit = true;
        boolean babyGroundKept = true;
        for (Species s : Species.values()) {
            Rig adult = Rigs.of(s);
            Rig baby = RigTransforms.baby(adult).packed();
            babiesFit &= baby.parts().size() == adult.parts().size() && TexturePacker.overlapFree(baby.parts());
            for (Rig.Part p : baby.parts()) {
                babiesFit &= p.w() >= 1 && p.h() >= 1 && p.d() >= 1;
                if (p.role() == Rig.Role.LEG) {
                    babyGroundKept &= p.py() + p.h() <= Rig.GROUND_Y + 1;
                }
            }
            babyGroundKept &= RigTransforms.baby(adult).heightBlocks() < adult.heightBlocks();
        }
        check("cada cría tiene las mismas piezas, sin solapes y con tamaño válido", babiesFit);
        check("las patas de la cría llegan al suelo y la cría es más baja", babyGroundKept);
        boolean hybridsFit = true;
        int hybridPairs = 0;
        for (Species a : Species.values()) {
            for (Species b : Species.values()) {
                if (a.ordinal() >= b.ordinal() || !Breeding.canBreed(a, b)) continue;
                hybridPairs++;
                Rig h = RigTransforms.hybrid(Rigs.of(a), Rigs.of(b), a.key() + "_x_" + b.key()).packed();
                hybridsFit &= h.parts().size() >= 3 && TexturePacker.overlapFree(h.parts())
                        && h.parts().stream().allMatch(p -> p.u() + p.atlasWidth() <= Rig.ATLAS_SIZE && p.v() + p.atlasHeight() <= Rig.ATLAS_SIZE);
            }
        }
        check("hay 67 pares compatibles de híbridos", hybridPairs == 67);
        check("todos los modelos de híbrido caben en el atlas", hybridsFit);

        System.out.println("== Descendencia ==");
        List<Offspring> allPairs = Offspring.allHybridPairs();
        check("hay 67 pares de híbrido posibles", allPairs.size() == 67);
        boolean pairsOrdered = allPairs.stream().allMatch(o -> o.isHybrid() && o.primary().ordinal() < o.secondary().ordinal() && Breeding.canBreed(o.primary(), o.secondary()));
        check("cada par de híbrido es compatible y está ordenado", pairsOrdered);
        check("dos especies pura compatibles dan un híbrido", Offspring.resolve(Species.TYRANNOSAURUS_REX, null, Species.CARNOTAURUS, null).map(Offspring::isHybrid).orElse(false));
        check("dos especies incompatibles no dan cría", Offspring.resolve(Species.TYRANNOSAURUS_REX, null, Species.TRICERATOPS, null).isEmpty());
        check("dos ejemplares de la misma especie dan cría pura", Offspring.resolve(Species.VELOCIRAPTOR, null, Species.VELOCIRAPTOR, null).map(o -> !o.isHybrid()).orElse(false));
        boolean hybridCrossesStayCompatible = true;
        for (Offspring pair : allPairs) {
            for (Species z : Species.values()) {
                if (!Breeding.canBreed(pair.primary(), z) && !Breeding.canBreed(pair.secondary(), z)) continue;
                var child = Offspring.resolve(pair.primary(), pair.secondary(), z, null);
                if (child.isEmpty()) { hybridCrossesStayCompatible = false; continue; }
                Offspring c = child.get();
                if (c.isHybrid() && !Breeding.canBreed(c.primary(), c.secondary())) hybridCrossesStayCompatible = false;
            }
        }
        check("un híbrido solo da crías compatibles con uno de sus padres", hybridCrossesStayCompatible);

        System.out.println("== Comandos de domesticación ==");
        Domestication cmd = new Domestication(true, true);
        for (int i = 0; i < Domestication.FOOD_TO_TAME; i++) cmd.feed();
        check("el primer clic de comando sienta a la criatura", cmd.cycleCommand() == Domestication.Mode.SENTADO);
        check("el segundo la deja quieta", cmd.cycleCommand() == Domestication.Mode.QUIETO);
        check("el tercero vuelve a seguir", cmd.cycleCommand() == Domestication.Mode.SEGUIR);
        Domestication noSit = new Domestication(true, false);
        for (int i = 0; i < Domestication.FOOD_TO_TAME; i++) noSit.feed();
        noSit.cycleCommand();
        check("sin anatomía para sentarse, quieto vuelve a seguir", noSit.cycleCommand() == Domestication.Mode.SEGUIR);
        Domestication saved = new Domestication(true, true);
        saved.restore(2, Domestication.Mode.QUIETO);
        check("el estado guardado se restaura (comida y comando)", saved.foodGiven() == 2 && saved.mode() == Domestication.Mode.QUIETO && saved.isTamed());

        System.out.println("== Enciclopedia guardada ==");
        Encyclopedia stored = new Encyclopedia();
        stored.recordSpecimen(Species.VELOCIRAPTOR, ColorVariant.AZUL);
        stored.recordSpecimen(Species.VELOCIRAPTOR, ColorVariant.AZUL);
        stored.recordSpecimen(Species.DRAGON_DE_CRISTAL, ColorVariant.DORADA);
        stored.recordHybridKey("tyrannosaurus_rex_x_carnotaurus");
        String text = stored.toCompact();
        Encyclopedia loaded = Encyclopedia.fromCompact(text);
        check("la enciclopedia se guarda como texto y vuelve igual", loaded.toCompact().equals(text));
        check("las cantidades se conservan al recargar", loaded.copies(Species.VELOCIRAPTOR, ColorVariant.AZUL) == 2);
        check("el porcentaje se conserva al recargar", near(loaded.completionPercent(), stored.completionPercent(), 1e-9));
        check("los híbridos se conservan al recargar", loaded.hybridsDiscovered() == 1 && loaded.discoveredHybridKeys().contains("tyrannosaurus_rex_x_carnotaurus"));
        check("una enciclopedia vacía se carga vacía", Encyclopedia.fromCompact("").completionPercent() == 0.0 && Encyclopedia.fromCompact(null).completionPercent() == 0.0);
        check("una entrada desconocida se ignora sin fallar", Encyclopedia.fromCompact("s:dinosaurio_falso:roja=3;s:velociraptor:roja=1;").discoveredCombinations() == 1);
        check("el límite de criaturas para criar se respeta", Limits.canBreedWithCrowd(Limits.MAX_NEARBY_FOR_BREEDING - 1) && !Limits.canBreedWithCrowd(Limits.MAX_NEARBY_FOR_BREEDING));

        System.out.println("== Tamaños reales ==");
        check("el T-Rex mide al menos 4 bloques", Sizes.targetHeight(Species.TYRANNOSAURUS_REX) >= 4.0);
        check("ninguna especie mide menos de 0.5 bloques ni más de 12", java.util.Arrays.stream(Species.values()).allMatch(s -> Sizes.targetHeight(s) >= 0.5 && Sizes.targetHeight(s) <= 12.0));
        check("un Velociraptor mide más que un Compsognathus", Sizes.targetHeight(Species.VELOCIRAPTOR) > Sizes.targetHeight(Species.COMPSOGNATHUS));
        boolean scalesOk = true;
        for (Species s : Species.values()) {
            Rig r = Rigs.of(s);
            double k = Sizes.modelScale(r.heightBlocks(), Sizes.targetHeight(s));
            scalesOk &= k > 0.1 && k < 20 && r.footprintBlocks() > 0;
        }
        check("el escalado del modelo y la huella son razonables en todas las especies", scalesOk);
        check("la altura de un híbrido es la media de sus padres", near(Sizes.hybridHeight(Species.TYRANNOSAURUS_REX, Species.VELOCIRAPTOR), (4.5 + 2.0) / 2.0, 1e-9));

        System.out.println();
        System.out.println("Resultado: " + passed + " correctas, " + failed + " fallidas");
        if (failed > 0) {
            System.exit(1);
        }
    }

    private static CreatureProfile atLevel(CreatureProfile p, int level) {
        return new CreatureProfile(p.key(), p.name(), p.baseStats(), p.rarity(), p.variant(), p.abilities(), level, 0, p.maxLevel());
    }
}
