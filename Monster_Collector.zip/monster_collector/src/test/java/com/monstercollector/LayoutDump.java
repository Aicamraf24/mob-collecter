package com.monstercollector;

import com.monstercollector.domain.Offspring;
import com.monstercollector.domain.Species;
import com.monstercollector.rig.Rig;
import com.monstercollector.rig.RigTransforms;
import com.monstercollector.rig.Rigs;

/**
 * Herramienta de desarrollo: escribe en JSON la posición de cada pieza en el atlas de texturas,
 * para que el generador de texturas pinte cada cara en su sitio.
 * Ejecutar: java -cp build/catalog-check com.monstercollector.LayoutDump > tools/layouts.json
 */
public final class LayoutDump {

    private LayoutDump() {}

    public static void main(String[] args) {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n  \"species\": {\n");
        boolean first = true;
        for (Species s : Species.values()) {
            if (!first) sb.append(",\n");
            first = false;
            sb.append("    \"").append(s.key()).append("\": ");
            appendRig(sb, Rigs.of(s));
        }
        sb.append("\n  },\n  \"hybrids\": {\n");
        first = true;
        for (Offspring pair : Offspring.allHybridPairs()) {
            String key = pair.primary().key() + "_x_" + pair.secondary().key();
            if (!first) sb.append(",\n");
            first = false;
            sb.append("    \"").append(key).append("\": ");
            appendRig(sb, RigTransforms.hybrid(Rigs.of(pair.primary()), Rigs.of(pair.secondary()), key).packed());
        }
        sb.append("\n  }\n}\n");
        System.out.print(sb);
    }

    private static void appendRig(StringBuilder sb, Rig rig) {
        sb.append("[");
        boolean first = true;
        for (Rig.Part p : rig.parts()) {
            if (!first) sb.append(", ");
            first = false;
            sb.append("{\"name\": \"").append(p.name())
                    .append("\", \"role\": \"").append(p.role().name())
                    .append("\", \"u\": ").append(p.u())
                    .append(", \"v\": ").append(p.v())
                    .append(", \"w\": ").append(p.w())
                    .append(", \"h\": ").append(p.h())
                    .append(", \"d\": ").append(p.d()).append("}");
        }
        sb.append("]");
    }
}
