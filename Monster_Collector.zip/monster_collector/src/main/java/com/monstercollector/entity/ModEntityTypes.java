package com.monstercollector.entity;

import com.monstercollector.MonsterCollector;
import com.monstercollector.domain.BaseStats;
import com.monstercollector.domain.Offspring;
import com.monstercollector.domain.Species;
import com.monstercollector.rig.Rig;
import com.monstercollector.rig.RigTransforms;
import com.monstercollector.rig.Rigs;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;

/** Registro de las 44 especies y de los 67 tipos de híbrido. */
public final class ModEntityTypes {

    private static final Map<Species, EntityType<CreatureEntity>> TYPES = new EnumMap<>(Species.class);
    private static final Map<String, EntityType<CreatureEntity>> HYBRID_TYPES = new HashMap<>();
    /** Tipo → especie principal (para comportamiento y movimiento). */
    private static final Map<EntityType<?>, Species> BY_TYPE = new HashMap<>();

    private ModEntityTypes() {}

    public static void registerAll() {
        for (Species s : Species.values()) {
            Rig rig = Rigs.of(s);
            ResourceKey<EntityType<?>> key = ResourceKey.create(
                    Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath(MonsterCollector.MOD_ID, s.key()));
            EntityType<CreatureEntity> type = Registry.register(
                    BuiltInRegistries.ENTITY_TYPE,
                    key,
                    EntityType.Builder.<CreatureEntity>of((t, level) -> new CreatureEntity(t, level, s), MobCategory.CREATURE)
                            .sized((float) rig.widthBlocks(), (float) rig.heightBlocks())
                            .clientTrackingRange(8)
                            .updateInterval(3)
                            .build(key));
            TYPES.put(s, type);
            BY_TYPE.put(type, s);
            FabricDefaultAttributeRegistry.register(type, CreatureEntity.createAttributes(s.baseStats()));
        }

        for (Offspring pair : Offspring.allHybridPairs()) {
            Species a = pair.primary();
            Species b = pair.secondary();
            String hybridKey = hybridKey(a, b);
            Rig rig = RigTransforms.hybrid(Rigs.of(a), Rigs.of(b), hybridKey).packed();
            ResourceKey<EntityType<?>> key = ResourceKey.create(
                    Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath(MonsterCollector.MOD_ID, hybridKey));
            EntityType<CreatureEntity> type = Registry.register(
                    BuiltInRegistries.ENTITY_TYPE,
                    key,
                    EntityType.Builder.<CreatureEntity>of((t, level) -> new CreatureEntity(t, level, a, b), MobCategory.CREATURE)
                            .sized((float) rig.widthBlocks(), (float) rig.heightBlocks())
                            .clientTrackingRange(8)
                            .updateInterval(3)
                            .build(key));
            HYBRID_TYPES.put(hybridKey, type);
            BY_TYPE.put(type, a);
            FabricDefaultAttributeRegistry.register(type,
                    CreatureEntity.createAttributes(BaseStats.hybridOf(a.baseStats(), b.baseStats())));
        }
    }

    public static EntityType<CreatureEntity> typeOf(Species species) {
        return TYPES.get(species);
    }

    /** Tipo de un híbrido, sin importar el orden de los padres. */
    public static EntityType<CreatureEntity> hybridTypeOf(Species x, Species y) {
        return HYBRID_TYPES.get(hybridKey(x, y));
    }

    /** Clave del híbrido en orden de enum, p. ej. "tyrannosaurus_rex_x_carnotaurus". */
    public static String hybridKey(Species x, Species y) {
        Species first = x.ordinal() < y.ordinal() ? x : y;
        Species second = first == x ? y : x;
        return first.key() + "_x_" + second.key();
    }

    /** Especie principal de un tipo de entidad, o null si no es de Monster Collector. */
    public static Species speciesOf(EntityType<?> type) {
        return BY_TYPE.get(type);
    }
}
