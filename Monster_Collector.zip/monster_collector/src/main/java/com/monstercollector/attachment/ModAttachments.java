package com.monstercollector.attachment;

import com.mojang.serialization.Codec;
import com.monstercollector.MonsterCollector;
import com.monstercollector.domain.Encyclopedia;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentSyncPredicate;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.resources.Identifier;

/**
 * Datos del jugador: su enciclopedia. Se guarda con el jugador, sobrevive a la muerte
 * y se sincroniza solo con el propio jugador para que la pantalla pueda leerla.
 */
public final class ModAttachments {

    public static final AttachmentType<Encyclopedia> ENCYCLOPEDIA = AttachmentRegistry.create(
            Identifier.fromNamespaceAndPath(MonsterCollector.MOD_ID, "encyclopedia"),
            builder -> builder
                    .initializer(Encyclopedia::new)
                    .persistent(Codec.STRING.xmap(Encyclopedia::fromCompact, Encyclopedia::toCompact))
                    .copyOnDeath()
                    .syncWith(
                            ByteBufCodecs.STRING_UTF8.map(Encyclopedia::fromCompact, Encyclopedia::toCompact),
                            AttachmentSyncPredicate.targetOnly()));

    private ModAttachments() {}

    /** Fuerza la carga de la clase para que el adjunto quede registrado al arrancar. */
    public static void register() {
    }
}
