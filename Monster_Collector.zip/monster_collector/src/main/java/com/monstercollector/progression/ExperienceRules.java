package com.monstercollector.progression;

/** Cuánta experiencia da cada actividad. Los valores son iniciales y ajustables. */
public final class ExperienceRules {

    /** Experiencia por alimentar a la criatura una vez. */
    public static final long FEED_XP = 15L;

    /** Un punto de experiencia cada 40 bloques recorridos. */
    public static final double BLOCKS_PER_XP = 40.0;

    private ExperienceRules() {}

    /** Combate: un cuarto de la vida máxima del rival, con mínimo de 1. */
    public static long combatXp(double targetMaxHealth) {
        return Math.max(1L, Math.round(targetMaxHealth / 4.0));
    }

    /** Exploración: proporcional a la distancia recorrida. */
    public static long explorationXp(double blocksWalked) {
        if (blocksWalked <= 0) return 0L;
        return (long) (blocksWalked / BLOCKS_PER_XP);
    }

    public static long feedXp() {
        return FEED_XP;
    }
}
