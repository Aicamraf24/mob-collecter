package com.monstercollector.item;

import com.monstercollector.client.EncyclopediaClient;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Libro de la enciclopedia: al usarlo se abre la pantalla con los descubrimientos del jugador. */
public class EncyclopediaItem extends Item {

    public EncyclopediaItem(Item.Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (level.isClientSide()) {
            EncyclopediaClient.open();
        }
        return InteractionResult.SUCCESS;
    }
}
