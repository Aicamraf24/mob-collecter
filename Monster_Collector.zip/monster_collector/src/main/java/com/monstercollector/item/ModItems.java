package com.monstercollector.item;

import com.monstercollector.MonsterCollector;
import com.monstercollector.domain.Species;
import com.monstercollector.entity.ModEntityTypes;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SpawnEggItem;

import java.util.EnumMap;
import java.util.Map;

public final class ModItems {

    public static final Item ENCYCLOPEDIA = register("encyclopedia");

    private static final Map<Species, Item> SPAWN_EGGS = new EnumMap<>(Species.class);

    private ModItems() {}

    private static Item register(String name) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(MonsterCollector.MOD_ID, name));
        Item.Properties props = new Item.Properties().setId(key).stacksTo(1);
        return Registry.register(BuiltInRegistries.ITEM, key, new EncyclopediaItem(props));
    }

    /**
     * Registra los huevos de aparición de las 44 especies y los añade a sus pestañas de creativo.
     * Debe llamarse después de registrar las entidades.
     */
    public static void register() {
        for (Species species : Species.values()) {
            SPAWN_EGGS.put(species, registerSpawnEgg(species));
        }

        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.SPAWN_EGGS).register(entries -> {
            for (Item egg : SPAWN_EGGS.values()) {
                entries.accept(egg);
            }
        });
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(entries -> {
            entries.accept(ENCYCLOPEDIA);
        });
    }

    private static Item registerSpawnEgg(Species species) {
        ResourceKey<Item> key = ResourceKey.create(
                Registries.ITEM, Identifier.fromNamespaceAndPath(MonsterCollector.MOD_ID, species.key() + "_spawn_egg"));
        Item.Properties props = new Item.Properties().setId(key).spawnEgg(ModEntityTypes.typeOf(species));
        return Registry.register(BuiltInRegistries.ITEM, key, new SpawnEggItem(props));
    }
}
