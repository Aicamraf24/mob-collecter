package com.monstercollector.item;

import com.monstercollector.MonsterCollector;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;

public final class ModItems {

    public static final Item ENCYCLOPEDIA = register("encyclopedia");

    private ModItems() {}

    private static Item register(String name) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(MonsterCollector.MOD_ID, name));
        Item.Properties props = new Item.Properties().setId(key).stacksTo(1);
        return Registry.register(BuiltInRegistries.ITEM, key, new EncyclopediaItem(props));
    }

    /** Fuerza la carga de la clase para que los ítems queden registrados al arrancar. */
    public static void register() {
    }
}
