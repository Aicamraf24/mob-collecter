package com.monstercollector.combat;

import com.monstercollector.domain.Ability;

import java.util.HashMap;
import java.util.Map;

/** Tiempos de reutilización de las habilidades de un ejemplar. Todo en ticks (20 por segundo). */
public final class Cooldowns {

    public static final long TICKS_PER_SECOND = 20L;

    private final Map<String, Long> readyAt = new HashMap<>();

    public boolean isReady(Ability ability, long tick) {
        return tick >= readyAt.getOrDefault(ability.id(), 0L);
    }

    public void use(Ability ability, long tick) {
        readyAt.put(ability.id(), tick + ability.cooldownSeconds() * TICKS_PER_SECOND);
    }

    public long remainingTicks(Ability ability, long tick) {
        return Math.max(0L, readyAt.getOrDefault(ability.id(), 0L) - tick);
    }
}
