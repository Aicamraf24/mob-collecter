package com.monstercollector.combat;

import com.monstercollector.domain.Ability;

import java.util.List;
import java.util.Optional;
import java.util.random.RandomGenerator;

/**
 * Elige qué habilidad usar en cada momento. Con poca vida prefiere las defensivas;
 * con objetivo a la vista usa una ofensiva lista; si no hay nada lista, no hace nada.
 */
public final class AbilityChooser {

    /** Por debajo de este porcentaje de vida se buscan habilidades defensivas. */
    public static final double LOW_HEALTH = 0.35;

    private AbilityChooser() {}

    public static Optional<Ability> choose(List<Ability> abilities, Cooldowns cooldowns, long tick,
                                           boolean hasTarget, double healthRatio, RandomGenerator rng) {
        List<Ability> ready = abilities.stream().filter(a -> cooldowns.isReady(a, tick)).toList();

        if (healthRatio < LOW_HEALTH) {
            List<Ability> defensive = ready.stream().filter(a -> a.kind() == Ability.Kind.DEFENSIVA).toList();
            if (!defensive.isEmpty()) {
                return Optional.of(pick(defensive, rng));
            }
        }

        if (!hasTarget) {
            return Optional.empty();
        }
        List<Ability> offensive = ready.stream().filter(a -> a.kind() == Ability.Kind.OFENSIVA).toList();
        return offensive.isEmpty() ? Optional.empty() : Optional.of(pick(offensive, rng));
    }

    /** Daño de una habilidad ofensiva: ataque base multiplicado por la potencia. */
    public static double damageDealt(Ability ability, double baseAttack) {
        return baseAttack * ability.power();
    }

    /** Daño recibido con una defensiva activa: la potencia es la fracción que se evita. */
    public static double damageTaken(double incoming, Ability defensive) {
        return incoming * (1.0 - defensive.power());
    }

    private static Ability pick(List<Ability> options, RandomGenerator rng) {
        return options.get(rng.nextInt(options.size()));
    }
}
