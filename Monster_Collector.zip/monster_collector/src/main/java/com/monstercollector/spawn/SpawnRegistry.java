package com.monstercollector.spawn;

import com.monstercollector.domain.Habitat;
import com.monstercollector.domain.Movement;
import com.monstercollector.domain.Species;
import com.monstercollector.domain.SpawnRules;
import com.monstercollector.entity.ModEntityTypes;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/** Añade la aparición natural de cada especie en los biomas de su hábitat. */
public final class SpawnRegistry {

    private static final Map<Habitat, List<ResourceKey<Biome>>> BIOMES = new EnumMap<>(Habitat.class);

    static {
        BIOMES.put(Habitat.SELVA, List.of(Biomes.JUNGLE, Biomes.SPARSE_JUNGLE, Biomes.BAMBOO_JUNGLE));
        BIOMES.put(Habitat.LLANURA, List.of(Biomes.PLAINS, Biomes.SUNFLOWER_PLAINS));
        BIOMES.put(Habitat.MONTANA, List.of(Biomes.WINDSWEPT_HILLS, Biomes.STONY_PEAKS, Biomes.MEADOW));
        BIOMES.put(Habitat.ZONA_CALIDA, List.of(Biomes.DESERT, Biomes.SAVANNA, Biomes.BADLANDS));
        BIOMES.put(Habitat.BOSQUE_OSCURO, List.of(Biomes.DARK_FOREST));
        BIOMES.put(Habitat.OCEANO, List.of(Biomes.OCEAN, Biomes.DEEP_OCEAN, Biomes.WARM_OCEAN, Biomes.COLD_OCEAN));
        BIOMES.put(Habitat.AGUA_DULCE, List.of(Biomes.RIVER, Biomes.SWAMP));
        BIOMES.put(Habitat.ZONA_MINERAL, List.of(Biomes.LUSH_CAVES, Biomes.DRIPSTONE_CAVES));
    }

    private SpawnRegistry() {}

    /** Debe llamarse en la inicialización del servidor, después de registrar las entidades. */
    public static void register() {
        for (Species s : Species.values()) {
            MobCategory category = s.movement() == Movement.ACUATICO ? MobCategory.WATER_CREATURE : MobCategory.CREATURE;
            BiomeModifications.addSpawn(
                    BiomeSelectors.includeByKey(BIOMES.get(s.habitat())),
                    category,
                    ModEntityTypes.typeOf(s),
                    SpawnRules.weight(s.rarity()),
                    SpawnRules.minGroupSize(s.rarity()),
                    SpawnRules.maxGroupSize(s.rarity()));
        }
    }
}
