package com.monstercollector;

import com.monstercollector.attachment.ModAttachments;
import com.monstercollector.domain.Catalog;
import com.monstercollector.item.ModItems;
import com.monstercollector.entity.ModEntityTypes;
import com.monstercollector.spawn.SpawnRegistry;
import net.fabricmc.api.ModInitializer;

public class MonsterCollector implements ModInitializer {
    public static final String MOD_ID = "monster_collector";

    @Override
    public void onInitialize() {
        // Falla al arrancar si el catálogo, los modelos o las habilidades están mal definidos.
        Catalog.requireValid();
        ModEntityTypes.registerAll();
        SpawnRegistry.register();
        ModAttachments.register();
        ModItems.register();
    }
}
