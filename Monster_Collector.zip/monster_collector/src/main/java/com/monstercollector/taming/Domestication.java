package com.monstercollector.taming;

/**
 * Domesticación de un ejemplar: se gana alimentándolo varias veces (solo si la especie es domesticable).
 * Una vez domesticado sigue al jugador, puede quedarse quieto, sentarse si su anatomía lo permite y defender a su dueño.
 */
public final class Domestication {

    /** Alimentos necesarios para domesticar. */
    public static final int FOOD_TO_TAME = 3;

    public enum Mode { SALVAJE, SEGUIR, QUIETO, SENTADO }

    private final boolean domesticable;
    private final boolean canSit;
    private int foodGiven;
    private Mode mode = Mode.SALVAJE;

    public Domestication(boolean domesticable, boolean canSit) {
        this.domesticable = domesticable;
        this.canSit = canSit;
    }

    /** Alimenta al ejemplar. Devuelve true solo en el momento en que queda domesticado. */
    public boolean feed() {
        if (mode != Mode.SALVAJE || !domesticable) {
            return false;
        }
        foodGiven++;
        if (foodGiven >= FOOD_TO_TAME) {
            mode = Mode.SEGUIR;
            return true;
        }
        return false;
    }

    public boolean isTamed() {
        return mode != Mode.SALVAJE;
    }

    public boolean isDomesticable() {
        return domesticable;
    }

    public boolean canSit() {
        return canSit;
    }

    /** Defiende al dueño cuando está domesticado. */
    public boolean defendsOwner() {
        return isTamed();
    }

    public boolean follow() {
        if (!isTamed()) return false;
        mode = Mode.SEGUIR;
        return true;
    }

    public boolean stay() {
        if (!isTamed()) return false;
        mode = Mode.QUIETO;
        return true;
    }

    /** Sentarse solo si la anatomía de la especie lo permite. */
    public boolean sit() {
        if (!isTamed() || !canSit) return false;
        mode = Mode.SENTADO;
        return true;
    }

    /**
     * Pasa al siguiente comando. Desde seguir, la criatura se sienta (si su anatomía lo permite) o se queda quieta;
     * después quieta, luego seguir. Devuelve el modo nuevo.
     */
    public Mode cycleCommand() {
        if (!isTamed()) return mode;
        mode = switch (mode) {
            case SEGUIR -> canSit ? Mode.SENTADO : Mode.QUIETO;
            case SENTADO -> Mode.QUIETO;
            case QUIETO, SALVAJE -> Mode.SEGUIR;
        };
        return mode;
    }

    /** Carga el estado guardado en el NBT. */
    public void restore(int food, Mode savedMode) {
        this.foodGiven = Math.max(0, food);
        this.mode = savedMode;
    }

    public Mode mode() {
        return mode;
    }

    public int foodGiven() {
        return foodGiven;
    }
}
