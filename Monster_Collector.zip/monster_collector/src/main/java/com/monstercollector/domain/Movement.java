package com.monstercollector.domain;

public enum Movement implements Labeled {
    TERRESTRE("Terrestre"),
    VOLADOR("Voladora"),
    ACUATICO("Acuática");

    private final String displayName;

    Movement(String displayName) {
        this.displayName = displayName;
    }

    @Override
    public String displayName() {
        return displayName;
    }
}
