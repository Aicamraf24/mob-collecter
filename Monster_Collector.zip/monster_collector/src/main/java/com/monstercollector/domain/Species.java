package com.monstercollector.domain;

import java.util.List;
import java.util.Locale;

/**
 * Las 44 especies: las 25 de la especificación y 19 extras del póster. No hay jefes:
 * todas se reproducen y todas pueden ser capturadas con Cápsulas.
 */
public enum Species implements Labeled {
    TYRANNOSAURUS_REX("Tyrannosaurus Rex", Rarity.EPIC, Movement.TERRESTRE, Lineage.TEROPODOS_GRANDES, Habitat.SELVA, Diet.CARNIVORO, Behavior.AGRESIVO, new BaseStats(90, 20, 0.22), false, Abilities.MORDIDA_DEVASTADORA),
    VELOCIRAPTOR("Velociraptor", Rarity.COMMON, Movement.TERRESTRE, Lineage.TEROPODOS_PLUMADOS, Habitat.SELVA, Diet.CARNIVORO, Behavior.AGRESIVO, new BaseStats(36, 7, 0.34), true, Abilities.ATAQUE_RAPIDO),
    TRICERATOPS("Triceratops", Rarity.COMMON, Movement.TERRESTRE, Lineage.ACORAZADOS, Habitat.LLANURA, Diet.HERBIVORO, Behavior.TERRITORIAL, new BaseStats(70, 9, 0.20), true, Abilities.EMBESTIDA),
    STEGOSAURUS("Stegosaurus", Rarity.COMMON, Movement.TERRESTRE, Lineage.ACORAZADOS, Habitat.LLANURA, Diet.HERBIVORO, Behavior.PASIVO, new BaseStats(60, 11, 0.19), true, Abilities.GOLPE_COLA),
    BRACHIOSAURUS("Brachiosaurus", Rarity.RARE, Movement.TERRESTRE, Lineage.SAUROPODOS, Habitat.SELVA, Diet.HERBIVORO, Behavior.PASIVO, new BaseStats(140, 6, 0.14), true, Abilities.PISOTON),
    SPINOSAURUS("Spinosaurus", Rarity.EPIC, Movement.TERRESTRE, Lineage.TEROPODOS_GRANDES, Habitat.AGUA_DULCE, Diet.CARNIVORO, Behavior.AGRESIVO, new BaseStats(110, 16, 0.24), false, Abilities.ATAQUE_ACUATICO),
    ANKYLOSAURUS("Ankylosaurus", Rarity.UNCOMMON, Movement.TERRESTRE, Lineage.ACORAZADOS, Habitat.LLANURA, Diet.HERBIVORO, Behavior.NEUTRAL, new BaseStats(75, 8, 0.15), true, Abilities.CAPARAZON),
    CARNOTAURUS("Carnotaurus", Rarity.UNCOMMON, Movement.TERRESTRE, Lineage.TEROPODOS_GRANDES, Habitat.LLANURA, Diet.CARNIVORO, Behavior.AGRESIVO, new BaseStats(58, 12, 0.30), true, Abilities.CARGA_RAPIDA),
    PTERANODON("Pteranodon", Rarity.UNCOMMON, Movement.VOLADOR, Lineage.VOLADORES_PREHISTORICOS, Habitat.MONTANA, Diet.PISCIVORO, Behavior.NEUTRAL, new BaseStats(34, 6, 0.30), true, Abilities.VUELO),
    QUETZALCOATLUS("Quetzalcoatlus", Rarity.RARE, Movement.VOLADOR, Lineage.VOLADORES_PREHISTORICOS, Habitat.MONTANA, Diet.CARNIVORO, Behavior.TERRITORIAL, new BaseStats(80, 10, 0.26), false, Abilities.VIENTO),
    DIMORPHODON("Dimorphodon", Rarity.UNCOMMON, Movement.VOLADOR, Lineage.VOLADORES_PREHISTORICOS, Habitat.MONTANA, Diet.CARNIVORO, Behavior.NOCTURNO, new BaseStats(28, 5, 0.36), true, Abilities.PICADO),
    DRAGON_DE_CRISTAL("Dragón de Cristal", Rarity.LEGENDARY, Movement.VOLADOR, Lineage.DRAGONIDOS, Habitat.ZONA_MINERAL, Diet.CARNIVORO, Behavior.TERRITORIAL, new BaseStats(300, 26, 0.30), false, Abilities.ENERGIA, Abilities.VUELO),
    GRIFO_SALVAJE("Grifo Salvaje", Rarity.EPIC, Movement.VOLADOR, Lineage.DRAGONIDOS, Habitat.MONTANA, Diet.CARNIVORO, Behavior.AGRESIVO, new BaseStats(120, 14, 0.30), true, Abilities.GARRA_AEREA),
    MEGALODON("Megalodón", Rarity.EPIC, Movement.ACUATICO, Lineage.TIBURONES, Habitat.OCEANO, Diet.CARNIVORO, Behavior.AGRESIVO, new BaseStats(160, 24, 0.30), false, Abilities.MORDIDA_SUBMARINA),
    MOSASAURUS("Mosasaurus", Rarity.RARE, Movement.ACUATICO, Lineage.MARINOS_PREHISTORICOS, Habitat.OCEANO, Diet.CARNIVORO, Behavior.AGRESIVO, new BaseStats(130, 18, 0.28), false, Abilities.ATAQUE_ACUATICO_PODEROSO),
    PLESIOSAURUS("Plesiosaurus", Rarity.UNCOMMON, Movement.ACUATICO, Lineage.MARINOS_PREHISTORICOS, Habitat.OCEANO, Diet.CARNIVORO, Behavior.NEUTRAL, new BaseStats(90, 12, 0.26), false, Abilities.NADO_VELOZ),
    TIBURON_ABISAL("Tiburón Abisal", Rarity.RARE, Movement.ACUATICO, Lineage.TIBURONES, Habitat.OCEANO, Diet.CARNIVORO, Behavior.AGRESIVO, new BaseStats(70, 13, 0.32), false, Abilities.MORDIDA_RAPIDA),
    CALAMAR_GIGANTE("Calamar Gigante", Rarity.COMMON, Movement.ACUATICO, Lineage.CEFALOPODOS, Habitat.OCEANO, Diet.CARNIVORO, Behavior.PASIVO, new BaseStats(65, 9, 0.20), false, Abilities.TINTA),
    SERPIENTE_MARINA("Serpiente Marina", Rarity.COMMON, Movement.ACUATICO, Lineage.SERPIENTES_MARINAS, Habitat.OCEANO, Diet.CARNIVORO, Behavior.NEUTRAL, new BaseStats(60, 10, 0.27), false, Abilities.CONSTRICCION),
    GOLEM_DE_CRISTAL("Gólem de Cristal", Rarity.EPIC, Movement.TERRESTRE, Lineage.MINERALES, Habitat.ZONA_MINERAL, Diet.MINERAL, Behavior.PASIVO, new BaseStats(180, 14, 0.12), false, Abilities.DEFENSA_CRISTALINA),
    ESCORPION_COLOSAL("Escorpión Colosal", Rarity.UNCOMMON, Movement.TERRESTRE, Lineage.ARTROPODOS, Habitat.ZONA_CALIDA, Diet.CARNIVORO, Behavior.TERRITORIAL, new BaseStats(70, 15, 0.22), false, Abilities.VENENO),
    LOBO_DE_SOMBRAS("Lobo de Sombras", Rarity.RARE, Movement.TERRESTRE, Lineage.LOBUNOS, Habitat.BOSQUE_OSCURO, Diet.CARNIVORO, Behavior.NOCTURNO, new BaseStats(55, 13, 0.32), true, Abilities.SOMBRA),
    RINOCERONTE_ACORAZADO("Rinoceronte Acorazado", Rarity.RARE, Movement.TERRESTRE, Lineage.ACORAZADOS, Habitat.LLANURA, Diet.HERBIVORO, Behavior.TERRITORIAL, new BaseStats(150, 15, 0.20), true, Abilities.CARGA_ACORAZADA),
    FENIX("Fénix", Rarity.LEGENDARY, Movement.VOLADOR, Lineage.DRAGONIDOS, Habitat.ZONA_CALIDA, Diet.OMNIVORO, Behavior.NEUTRAL, new BaseStats(200, 20, 0.30), true, Abilities.FUEGO),
    LEVIATAN_MENOR("Leviatán Menor", Rarity.LEGENDARY, Movement.ACUATICO, Lineage.CETACEOS, Habitat.OCEANO, Diet.CARNIVORO, Behavior.AGRESIVO, new BaseStats(350, 22, 0.25), false, Abilities.OLEAJE),

    PARASAUROLOPHUS("Parasaurolophus", Rarity.UNCOMMON, Movement.TERRESTRE, Lineage.HADROSAURIOS, Habitat.LLANURA, Diet.HERBIVORO, Behavior.NEUTRAL, new BaseStats(64, 6, 0.24), true, Abilities.CRESTA_SONORA),
    ICHTHYOSAURUS("Ichthyosaurus", Rarity.UNCOMMON, Movement.ACUATICO, Lineage.MARINOS_PREHISTORICOS, Habitat.OCEANO, Diet.PISCIVORO, Behavior.NEUTRAL, new BaseStats(50, 7, 0.34), false, Abilities.NADO_VELOZ),
    ALLOSAURUS("Allosaurus", Rarity.RARE, Movement.TERRESTRE, Lineage.TEROPODOS_GRANDES, Habitat.LLANURA, Diet.CARNIVORO, Behavior.AGRESIVO, new BaseStats(100, 17, 0.25), false, Abilities.MORDIDA_DESGARRADORA),
    GIGANOTOSAURUS("Giganotosaurus", Rarity.EPIC, Movement.TERRESTRE, Lineage.TEROPODOS_GRANDES, Habitat.LLANURA, Diet.CARNIVORO, Behavior.AGRESIVO, new BaseStats(130, 21, 0.23), false, Abilities.MORDIDA_COLOSAL),
    DILOPHOSAURUS("Dilophosaurus", Rarity.UNCOMMON, Movement.TERRESTRE, Lineage.TEROPODOS_GRANDES, Habitat.SELVA, Diet.CARNIVORO, Behavior.NEUTRAL, new BaseStats(48, 9, 0.31), true, Abilities.ESCUPITAJO),
    COMPSOGNATHUS("Compsognathus", Rarity.COMMON, Movement.TERRESTRE, Lineage.TEROPODOS_PLUMADOS, Habitat.SELVA, Diet.CARNIVORO, Behavior.PASIVO, new BaseStats(16, 3, 0.40), true, Abilities.ATAQUE_RAPIDO),
    BARYONYX("Baryonyx", Rarity.RARE, Movement.TERRESTRE, Lineage.TEROPODOS_GRANDES, Habitat.AGUA_DULCE, Diet.PISCIVORO, Behavior.AGRESIVO, new BaseStats(110, 15, 0.26), false, Abilities.GARRA_PESCA),
    CERATOSAURUS("Ceratosaurus", Rarity.UNCOMMON, Movement.TERRESTRE, Lineage.TEROPODOS_GRANDES, Habitat.LLANURA, Diet.CARNIVORO, Behavior.NEUTRAL, new BaseStats(72, 12, 0.27), false, Abilities.CUERNO_NASAL),
    IGUANODON("Iguanodon", Rarity.COMMON, Movement.TERRESTRE, Lineage.HADROSAURIOS, Habitat.SELVA, Diet.HERBIVORO, Behavior.PASIVO, new BaseStats(76, 8, 0.20), true, Abilities.PULGAR_ESPINOSO),
    APATOSAURUS("Apatosaurus", Rarity.RARE, Movement.TERRESTRE, Lineage.SAUROPODOS, Habitat.LLANURA, Diet.HERBIVORO, Behavior.PASIVO, new BaseStats(150, 7, 0.13), true, Abilities.COLETAZO),
    ARGENTINOSAURUS("Argentinosaurus", Rarity.EPIC, Movement.TERRESTRE, Lineage.SAUROPODOS, Habitat.LLANURA, Diet.HERBIVORO, Behavior.PASIVO, new BaseStats(220, 12, 0.11), false, Abilities.PISOTON_COLOSAL),
    GALLIMIMUS("Gallimimus", Rarity.COMMON, Movement.TERRESTRE, Lineage.TEROPODOS_PLUMADOS, Habitat.LLANURA, Diet.OMNIVORO, Behavior.NEUTRAL, new BaseStats(34, 4, 0.42), true, Abilities.CARRERA_VELOZ),
    OVIRAPTOR("Oviraptor", Rarity.UNCOMMON, Movement.TERRESTRE, Lineage.TEROPODOS_PLUMADOS, Habitat.ZONA_CALIDA, Diet.OMNIVORO, Behavior.PASIVO, new BaseStats(40, 5, 0.33), true, Abilities.PROTECCION_NIDO),
    THERIZINOSAURUS("Therizinosaurus", Rarity.EPIC, Movement.TERRESTRE, Lineage.TEROPODOS_PLUMADOS, Habitat.LLANURA, Diet.HERBIVORO, Behavior.NEUTRAL, new BaseStats(150, 13, 0.19), false, Abilities.GARRAS_GUADANA),
    PULPO_DE_LAS_PROFUNDIDADES("Pulpo de las Profundidades", Rarity.RARE, Movement.ACUATICO, Lineage.CEFALOPODOS, Habitat.OCEANO, Diet.CARNIVORO, Behavior.NOCTURNO, new BaseStats(80, 11, 0.22), false, Abilities.TINTA_CEGADORA),
    ANGUILA_MARINA("Anguila Marina", Rarity.UNCOMMON, Movement.ACUATICO, Lineage.SERPIENTES_MARINAS, Habitat.OCEANO, Diet.CARNIVORO, Behavior.NEUTRAL, new BaseStats(46, 8, 0.33), false, Abilities.DESCARGA_ELECTRICA),
    RAYA_FANTASMA("Raya Fantasma", Rarity.RARE, Movement.ACUATICO, Lineage.TIBURONES, Habitat.OCEANO, Diet.CARNIVORO, Behavior.PASIVO, new BaseStats(84, 10, 0.25), false, Abilities.DESLIZAMIENTO),
    BALLENA_ABISAL("Ballena Abisal", Rarity.EPIC, Movement.ACUATICO, Lineage.CETACEOS, Habitat.OCEANO, Diet.PISCIVORO, Behavior.PASIVO, new BaseStats(260, 14, 0.20), false, Abilities.CANTO_ABISAL),
    REINA_DE_LAS_PROFUNDIDADES("Reina de las Profundidades", Rarity.EPIC, Movement.ACUATICO, Lineage.MEDUSAS, Habitat.OCEANO, Diet.CARNIVORO, Behavior.NOCTURNO, new BaseStats(120, 16, 0.18), false, Abilities.AGUIJON_LUMINOSO);

    private final String displayName;
    private final Rarity rarity;
    private final Movement movement;
    private final Lineage lineage;
    private final Habitat habitat;
    private final Diet diet;
    private final Behavior behavior;
    private final BaseStats baseStats;
    private final boolean domesticable;
    private final List<Ability> abilities;

    Species(String displayName, Rarity rarity, Movement movement, Lineage lineage, Habitat habitat,
            Diet diet, Behavior behavior, BaseStats baseStats, boolean domesticable, Ability... abilities) {
        this.displayName = displayName;
        this.rarity = rarity;
        this.movement = movement;
        this.lineage = lineage;
        this.habitat = habitat;
        this.diet = diet;
        this.behavior = behavior;
        this.baseStats = baseStats;
        this.domesticable = domesticable;
        this.abilities = List.of(abilities);
    }

    /** Clave estable para registros, texturas y enciclopedia (p. ej. "tyrannosaurus_rex"). */
    public String key() {
        return name().toLowerCase(Locale.ROOT);
    }

    @Override
    public String displayName() {
        return displayName;
    }

    public Rarity rarity() { return rarity; }
    public Movement movement() { return movement; }
    public Lineage lineage() { return lineage; }
    public Habitat habitat() { return habitat; }
    public Diet diet() { return diet; }
    public Behavior behavior() { return behavior; }
    public BaseStats baseStats() { return baseStats; }
    public boolean isDomesticable() { return domesticable; }
    public List<Ability> abilities() { return abilities; }
}
