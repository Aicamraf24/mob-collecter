package com.monstercollector.domain;

/**
 * Reglas de aparición natural. Cuanto más rara la especie, menor peso y menor grupo.
 * Los pesos se comparan con los de las criaturas vanilla de su categoría (p. ej. conejo 10, vaca 8).
 */
public final class SpawnRules {

    private SpawnRules() {}

    public static int weight(Rarity rarity) {
        return switch (rarity) {
            case COMMON -> 10;
            case UNCOMMON -> 5;
            case RARE -> 2;
            case EPIC, LEGENDARY -> 1;
        };
    }

    public static int minGroupSize(Rarity rarity) {
        return 1;
    }

    public static int maxGroupSize(Rarity rarity) {
        return switch (rarity) {
            case COMMON -> 3;
            case UNCOMMON -> 2;
            case RARE, EPIC, LEGENDARY -> 1;
        };
    }
}
