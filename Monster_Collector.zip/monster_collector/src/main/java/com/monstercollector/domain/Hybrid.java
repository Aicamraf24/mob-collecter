package com.monstercollector.domain;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Set;
import java.util.random.RandomGenerator;

/**
 * Híbrido de dos especies distintas. Los padres están siempre ordenados (parentA antes que parentB)
 * para que la clave sea la misma sea cual sea el orden de cruce.
 */
public record Hybrid(
        Species parentA,
        Species parentB,
        String name,
        BaseStats stats,
        List<Ability> abilities,
        ColorVariant variant,
        Rarity rarity) {

    public static final int MAX_ABILITIES = 2;

    public Hybrid {
        Objects.requireNonNull(parentA, "parentA");
        Objects.requireNonNull(parentB, "parentB");
        Objects.requireNonNull(name, "name");
        Objects.requireNonNull(stats, "stats");
        Objects.requireNonNull(variant, "variant");
        Objects.requireNonNull(rarity, "rarity");
        if (parentA.ordinal() >= parentB.ordinal()) {
            throw new IllegalArgumentException("Los padres deben estar ordenados y ser distintos");
        }
        if (!Breeding.canBreed(parentA, parentB)) {
            throw new IllegalArgumentException("Combinación no compatible: " + parentA + " + " + parentB);
        }
        abilities = List.copyOf(abilities);
        if (abilities.isEmpty() || abilities.size() > MAX_ABILITIES) {
            throw new IllegalArgumentException("Un híbrido tiene entre 1 y " + MAX_ABILITIES + " habilidades");
        }
    }

    public String key() {
        return parentA.key() + "+" + parentB.key();
    }

    /** Un híbrido puede cruzarse con una especie si cualquiera de sus padres es compatible con ella. */
    public boolean canBreedWith(Species other) {
        return Breeding.canBreed(parentA, other) || Breeding.canBreed(parentB, other);
    }

    public boolean canBreedWith(Hybrid other) {
        return canBreedWith(other.parentA) || canBreedWith(other.parentB);
    }

    /**
     * Cría un híbrido a partir de dos especies distintas compatibles. El nombre, las estadísticas
     * y la rareza son deterministas; la variante de color y las habilidades usan el generador recibido.
     */
    public static Hybrid breed(Species x, Species y, RandomGenerator rng) {
        if (x == y) {
            throw new IllegalArgumentException("Dos ejemplares de la misma especie no generan híbrido");
        }
        if (!Breeding.canBreed(x, y)) {
            throw new IllegalArgumentException("Combinación no compatible: " + x.displayName() + " + " + y.displayName());
        }
        Species a = x.ordinal() < y.ordinal() ? x : y;
        Species b = a == x ? y : x;

        Set<Ability> pool = new LinkedHashSet<>(a.abilities());
        pool.addAll(b.abilities());
        List<Ability> shuffled = new ArrayList<>(pool);
        shuffle(shuffled, rng);
        List<Ability> chosen = new ArrayList<>(shuffled.subList(0, Math.min(MAX_ABILITIES, shuffled.size())));

        Rarity rarity = a.rarity().ordinal() >= b.rarity().ordinal() ? a.rarity() : b.rarity();

        return new Hybrid(
                a,
                b,
                hybridName(a, b),
                BaseStats.hybridOf(a.baseStats(), b.baseStats()),
                chosen,
                ColorVariant.random(rng),
                rarity);
    }

    /** Mitad inicial del nombre del primer padre y mitad final del segundo. Ej.: Tyrannoraptor. */
    static String hybridName(Species a, Species b) {
        String left = fold(firstWord(a.displayName()));
        String right = fold(firstWord(b.displayName()));
        String joined = left.substring(0, (left.length() + 1) / 2)
                + right.substring(right.length() / 2);
        joined = joined.toLowerCase(Locale.ROOT);
        return Character.toUpperCase(joined.charAt(0)) + joined.substring(1);
    }

    private static String firstWord(String s) {
        return s.split(" ")[0];
    }

    private static String fold(String s) {
        return Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
    }

    private static <T> void shuffle(List<T> list, RandomGenerator rng) {
        for (int i = list.size() - 1; i > 0; i--) {
            Collections.swap(list, i, rng.nextInt(i + 1));
        }
    }
}
