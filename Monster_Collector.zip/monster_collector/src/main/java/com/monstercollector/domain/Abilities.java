package com.monstercollector.domain;

import com.monstercollector.domain.Ability.Kind;

import java.util.List;

/** Catálogo de habilidades. Cada especie usa una o dos de estas. */
public final class Abilities {
    private Abilities() {}

    public static final Ability MORDIDA_DEVASTADORA = new Ability("mordida_devastadora", "Mordida devastadora", Kind.OFENSIVA, 8, 2.0);
    public static final Ability ATAQUE_RAPIDO = new Ability("ataque_rapido", "Ataque rápido", Kind.OFENSIVA, 3, 1.1);
    public static final Ability EMBESTIDA = new Ability("embestida", "Embestida", Kind.OFENSIVA, 10, 1.8);
    public static final Ability GOLPE_COLA = new Ability("golpe_cola", "Golpe con la cola", Kind.OFENSIVA, 6, 1.5);
    public static final Ability PISOTON = new Ability("pisoton", "Pisotón", Kind.OFENSIVA, 12, 1.4);
    public static final Ability ATAQUE_ACUATICO = new Ability("ataque_acuatico", "Ataque acuático", Kind.OFENSIVA, 7, 1.6);
    public static final Ability CAPARAZON = new Ability("caparazon", "Caparazón", Kind.DEFENSIVA, 12, 0.5);
    public static final Ability CARGA_RAPIDA = new Ability("carga_rapida", "Carga rápida", Kind.OFENSIVA, 7, 1.3);
    public static final Ability VUELO = new Ability("vuelo", "Vuelo", Kind.MOVIMIENTO, 15, 1.0);
    public static final Ability VIENTO = new Ability("rafaga_viento", "Ráfaga de viento", Kind.OFENSIVA, 10, 1.3);
    public static final Ability PICADO = new Ability("picado", "Picado", Kind.OFENSIVA, 5, 1.2);
    public static final Ability ENERGIA = new Ability("proyectiles_energia", "Proyectiles de energía", Kind.OFENSIVA, 4, 1.5);
    public static final Ability GARRA_AEREA = new Ability("garra_aerea", "Garra aérea", Kind.OFENSIVA, 6, 1.4);
    public static final Ability MORDIDA_SUBMARINA = new Ability("mordida_submarina", "Mordida submarina", Kind.OFENSIVA, 8, 2.0);
    public static final Ability ATAQUE_ACUATICO_PODEROSO = new Ability("ataque_acuatico_poderoso", "Ataque acuático poderoso", Kind.OFENSIVA, 7, 1.7);
    public static final Ability NADO_VELOZ = new Ability("nado_veloz", "Nado veloz", Kind.MOVIMIENTO, 10, 1.2);
    public static final Ability MORDIDA_RAPIDA = new Ability("mordida_rapida", "Mordida rápida", Kind.OFENSIVA, 4, 1.2);
    public static final Ability TINTA = new Ability("nube_tinta", "Nube de tinta", Kind.DEFENSIVA, 12, 0.6);
    public static final Ability CONSTRICCION = new Ability("constriccion", "Constricción", Kind.OFENSIVA, 6, 1.3);
    public static final Ability DEFENSA_CRISTALINA = new Ability("defensa_cristalina", "Defensa cristalina", Kind.DEFENSIVA, 14, 0.5);
    public static final Ability VENENO = new Ability("aguijon_venenoso", "Aguijón venenoso", Kind.OFENSIVA, 9, 1.3);
    public static final Ability SOMBRA = new Ability("mordida_de_sombra", "Mordida de sombra", Kind.OFENSIVA, 6, 1.4);
    public static final Ability CARGA_ACORAZADA = new Ability("carga_acorazada", "Carga acorazada", Kind.OFENSIVA, 9, 1.6);
    public static final Ability FUEGO = new Ability("ataque_de_fuego", "Ataque de fuego", Kind.OFENSIVA, 8, 1.6);
    public static final Ability OLEAJE = new Ability("oleaje", "Oleaje", Kind.OFENSIVA, 10, 1.5);

    public static final Ability CRESTA_SONORA = new Ability("cresta_sonora", "Cresta sonora", Kind.DEFENSIVA, 15, 0.7);
    public static final Ability MORDIDA_DESGARRADORA = new Ability("mordida_desgarradora", "Mordida desgarradora", Kind.OFENSIVA, 7, 1.5);
    public static final Ability MORDIDA_COLOSAL = new Ability("mordida_colosal", "Mordida colosal", Kind.OFENSIVA, 9, 1.8);
    public static final Ability ESCUPITAJO = new Ability("escupitajo", "Escupitajo", Kind.OFENSIVA, 6, 1.2);
    public static final Ability GARRA_PESCA = new Ability("garra_pesca", "Garra de pesca", Kind.OFENSIVA, 8, 1.5);
    public static final Ability CUERNO_NASAL = new Ability("cuerno_nasal", "Cuerno nasal", Kind.OFENSIVA, 7, 1.4);
    public static final Ability PULGAR_ESPINOSO = new Ability("pulgar_espinoso", "Pulgar espinoso", Kind.OFENSIVA, 7, 1.4);
    public static final Ability COLETAZO = new Ability("coletazo", "Coletazo", Kind.OFENSIVA, 10, 1.6);
    public static final Ability PISOTON_COLOSAL = new Ability("pisoton_colosal", "Pisotón colosal", Kind.OFENSIVA, 14, 2.0);
    public static final Ability CARRERA_VELOZ = new Ability("carrera_veloz", "Carrera veloz", Kind.MOVIMIENTO, 8, 1.6);
    public static final Ability PROTECCION_NIDO = new Ability("proteccion_nido", "Protección del nido", Kind.DEFENSIVA, 10, 0.6);
    public static final Ability GARRAS_GUADANA = new Ability("garras_guadana", "Garras de guadaña", Kind.OFENSIVA, 9, 1.7);
    public static final Ability TINTA_CEGADORA = new Ability("tinta_cegadora", "Tinta cegadora", Kind.DEFENSIVA, 10, 0.5);
    public static final Ability DESCARGA_ELECTRICA = new Ability("descarga_electrica", "Descarga eléctrica", Kind.OFENSIVA, 6, 1.4);
    public static final Ability DESLIZAMIENTO = new Ability("deslizamiento", "Deslizamiento", Kind.MOVIMIENTO, 9, 1.4);
    public static final Ability CANTO_ABISAL = new Ability("canto_abisal", "Canto abisal", Kind.DEFENSIVA, 14, 0.6);
    public static final Ability AGUIJON_LUMINOSO = new Ability("aguijon_luminoso", "Aguijón luminoso", Kind.OFENSIVA, 8, 1.7);

    public static final List<Ability> ALL = List.of(
            MORDIDA_DEVASTADORA, ATAQUE_RAPIDO, EMBESTIDA, GOLPE_COLA, PISOTON, ATAQUE_ACUATICO,
            CAPARAZON, CARGA_RAPIDA, VUELO, VIENTO, PICADO, ENERGIA, GARRA_AEREA, MORDIDA_SUBMARINA,
            ATAQUE_ACUATICO_PODEROSO, NADO_VELOZ, MORDIDA_RAPIDA, TINTA, CONSTRICCION,
            DEFENSA_CRISTALINA, VENENO, SOMBRA, CARGA_ACORAZADA, FUEGO, OLEAJE,
            CRESTA_SONORA, MORDIDA_DESGARRADORA, MORDIDA_COLOSAL, ESCUPITAJO, GARRA_PESCA,
            CUERNO_NASAL, PULGAR_ESPINOSO, COLETAZO, PISOTON_COLOSAL, CARRERA_VELOZ, PROTECCION_NIDO,
            GARRAS_GUADANA, TINTA_CEGADORA, DESCARGA_ELECTRICA, DESLIZAMIENTO, CANTO_ABISAL, AGUIJON_LUMINOSO);
}
