package com.monstercollector.domain;

/**
 * Linaje biológico. Dos especies del mismo linaje pueden reproducirse entre sí.
 * Los linajes de una sola especie solo se cruzan consigo mismos, salvo pares explícitos en {@link Breeding}.
 */
public enum Lineage implements Labeled {
    TEROPODOS_GRANDES("Terópodos grandes"),
    TEROPODOS_PLUMADOS("Terópodos plumados"),
    ACORAZADOS("Acorazados"),
    SAUROPODOS("Saurópodos"),
    HADROSAURIOS("Hadrosaurios"),
    VOLADORES_PREHISTORICOS("Voladores prehistóricos"),
    MARINOS_PREHISTORICOS("Marinos prehistóricos"),
    TIBURONES("Tiburones y rayas"),
    CEFALOPODOS("Cefalópodos"),
    SERPIENTES_MARINAS("Serpientes marinas"),
    CETACEOS("Cetáceos abisales"),
    MEDUSAS("Medusas"),
    DRAGONIDOS("Dragónidos"),
    ARTROPODOS("Artrópodos"),
    MINERALES("Minerales"),
    LOBUNOS("Lobunos");

    private final String displayName;

    Lineage(String displayName) {
        this.displayName = displayName;
    }

    @Override
    public String displayName() {
        return displayName;
    }
}
