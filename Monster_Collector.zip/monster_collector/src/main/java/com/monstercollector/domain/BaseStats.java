package com.monstercollector.domain;

/** Vida, daño y velocidad. Los rangos válidos del catálogo los comprueba {@link Catalog}. */
public record BaseStats(double maxHealth, double attackDamage, double movementSpeed) {

    /** Un híbrido hereda la media de sus padres y gana un 5 % de vigor híbrido en vida y daño. */
    public static final double HYBRID_VIGOR = 1.05;

    public BaseStats {
        if (!(maxHealth > 0) || !(attackDamage > 0) || !(movementSpeed > 0)) {
            throw new IllegalArgumentException("Las estadísticas deben ser positivas");
        }
    }

    /** Escala vida y daño por {@code factor}; la velocidad crece más despacio (raíz cuarta). */
    public BaseStats scaled(double factor) {
        return new BaseStats(maxHealth * factor, attackDamage * factor, movementSpeed * Math.pow(factor, 0.25));
    }

    public static BaseStats hybridOf(BaseStats a, BaseStats b) {
        return new BaseStats(
                (a.maxHealth + b.maxHealth) / 2.0 * HYBRID_VIGOR,
                (a.attackDamage + b.attackDamage) / 2.0 * HYBRID_VIGOR,
                (a.movementSpeed + b.movementSpeed) / 2.0);
    }
}
