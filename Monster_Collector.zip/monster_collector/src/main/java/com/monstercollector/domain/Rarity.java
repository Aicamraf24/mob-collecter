package com.monstercollector.domain;

/**
 * Rareza de una especie. Afecta a la frecuencia de aparición, a la dificultad para encontrarla
 * y a las estadísticas. Nunca afecta a la probabilidad de las variantes de color.
 */
public enum Rarity implements Labeled {
    COMMON("Común", 60, 1.00, 1),
    UNCOMMON("Poco común", 25, 1.10, 2),
    RARE("Rara", 10, 1.25, 3),
    EPIC("Épica", 4, 1.45, 4),
    LEGENDARY("Legendaria", 1, 1.70, 5);

    private final String displayName;
    /** Peso relativo de aparición entre rarezas presentes en el bioma. */
    private final int spawnWeight;
    /** Multiplicador de vida y daño base. */
    private final double statMultiplier;
    /** Nivel de dificultad para encontrarla (1 = fácil, 5 = muy difícil). */
    private final int searchTier;

    Rarity(String displayName, int spawnWeight, double statMultiplier, int searchTier) {
        this.displayName = displayName;
        this.spawnWeight = spawnWeight;
        this.statMultiplier = statMultiplier;
        this.searchTier = searchTier;
    }

    @Override
    public String displayName() {
        return displayName;
    }

    public int spawnWeight() {
        return spawnWeight;
    }

    public double statMultiplier() {
        return statMultiplier;
    }

    public int searchTier() {
        return searchTier;
    }
}
