package com.monstercollector.domain;

/** Nombre visible en español para la enciclopedia y los menús. */
public interface Labeled {
    String displayName();
}
