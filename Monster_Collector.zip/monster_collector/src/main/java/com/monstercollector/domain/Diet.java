package com.monstercollector.domain;

public enum Diet implements Labeled {
    CARNIVORO("Carnívoro"),
    HERBIVORO("Herbívoro"),
    OMNIVORO("Omnívoro"),
    PISCIVORO("Piscívoro"),
    MINERAL("Minerales y cristal");

    private final String displayName;

    Diet(String displayName) {
        this.displayName = displayName;
    }

    @Override
    public String displayName() {
        return displayName;
    }
}
