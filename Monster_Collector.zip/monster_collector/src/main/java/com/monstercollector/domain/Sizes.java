package com.monstercollector.domain;

/**
 * Tamaño real de cada criatura. Un bloque de Minecraft equivale a un metro.
 * La altura de cada especie es su altura real aproximada; las de más de 8 bloques se limitan para que se puedan
 * recorrer y montar. El modelo se escala para que su altura coincida con este valor.
 */
public final class Sizes {

    private Sizes() {}

    /** Altura en bloques (metros) de cada especie. El switch obliga a definir todas. */
    public static double targetHeight(Species species) {
        return switch (species) {
            case TYRANNOSAURUS_REX -> 4.5;
            case VELOCIRAPTOR -> 2.0;
            case TRICERATOPS -> 3.0;
            case STEGOSAURUS -> 3.5;
            case BRACHIOSAURUS -> 12.0;
            case SPINOSAURUS -> 5.0;
            case ANKYLOSAURUS -> 2.0;
            case CARNOTAURUS -> 2.8;
            case PTERANODON -> 2.5;
            case QUETZALCOATLUS -> 5.0;
            case DIMORPHODON -> 1.2;
            case DRAGON_DE_CRISTAL -> 6.0;
            case GRIFO_SALVAJE -> 3.0;
            case MEGALODON -> 6.0;
            case MOSASAURUS -> 3.5;
            case PLESIOSAURUS -> 3.0;
            case TIBURON_ABISAL -> 3.0;
            case CALAMAR_GIGANTE -> 3.0;
            case SERPIENTE_MARINA -> 2.0;
            case GOLEM_DE_CRISTAL -> 6.0;
            case ESCORPION_COLOSAL -> 3.0;
            case LOBO_DE_SOMBRAS -> 1.8;
            case RINOCERONTE_ACORAZADO -> 2.8;
            case FENIX -> 4.0;
            case LEVIATAN_MENOR -> 5.0;
            case PARASAUROLOPHUS -> 4.0;
            case ICHTHYOSAURUS -> 2.0;
            case ALLOSAURUS -> 3.5;
            case GIGANOTOSAURUS -> 4.5;
            case DILOPHOSAURUS -> 2.5;
            case COMPSOGNATHUS -> 0.7;
            case BARYONYX -> 3.0;
            case CERATOSAURUS -> 3.0;
            case IGUANODON -> 3.5;
            case APATOSAURUS -> 8.0;
            case ARGENTINOSAURUS -> 12.0;
            case GALLIMIMUS -> 2.5;
            case OVIRAPTOR -> 1.2;
            case THERIZINOSAURUS -> 3.5;
            case PULPO_DE_LAS_PROFUNDIDADES -> 2.0;
            case ANGUILA_MARINA -> 1.0;
            case RAYA_FANTASMA -> 1.0;
            case BALLENA_ABISAL -> 8.0;
            case REINA_DE_LAS_PROFUNDIDADES -> 2.0;
        };
    }

    /** Altura de un híbrido: la media de la altura de sus padres. */
    public static double hybridHeight(Species a, Species b) {
        return (targetHeight(a) + targetHeight(b)) / 2.0;
    }

    /** Factor con el que se escala el modelo para que su altura sea la deseada. */
    public static double modelScale(double modelHeightBlocks, double targetHeightBlocks) {
        return targetHeightBlocks / modelHeightBlocks;
    }
}
