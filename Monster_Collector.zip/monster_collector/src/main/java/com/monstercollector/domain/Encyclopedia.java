package com.monstercollector.domain;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * Registro de descubrimientos del jugador. El porcentaje de colección cuenta solo las 125 combinaciones
 * base (especie × variante). Los híbridos se registran aparte y no entran en ese porcentaje.
 */
public final class Encyclopedia {

    private final Map<Species, EnumMap<ColorVariant, Integer>> copies = new EnumMap<>(Species.class);
    private final Map<String, Integer> hybridCopies = new TreeMap<>();

    public void recordSpecimen(Species species, ColorVariant variant) {
        copies.computeIfAbsent(species, s -> new EnumMap<>(ColorVariant.class))
                .merge(variant, 1, Integer::sum);
    }

    public void recordHybrid(Hybrid hybrid) {
        hybridCopies.merge(hybrid.key(), 1, Integer::sum);
    }

    public int copies(Species species, ColorVariant variant) {
        EnumMap<ColorVariant, Integer> byVariant = copies.get(species);
        return byVariant == null ? 0 : byVariant.getOrDefault(variant, 0);
    }

    public boolean isDiscovered(Species species, ColorVariant variant) {
        return copies(species, variant) > 0;
    }

    public int discoveredCombinations() {
        int count = 0;
        for (Species s : Species.values()) {
            for (ColorVariant v : ColorVariant.values()) {
                if (isDiscovered(s, v)) count++;
            }
        }
        return count;
    }

    public static int totalCombinations() {
        return Species.values().length * ColorVariant.COUNT;
    }

    public double completionPercent() {
        return 100.0 * discoveredCombinations() / totalCombinations();
    }

    /** Especies de las que todavía no se ha encontrado ninguna variante. */
    public List<Species> missingSpecies() {
        List<Species> missing = new ArrayList<>();
        for (Species s : Species.values()) {
            if (missingVariants(s).size() == ColorVariant.COUNT) {
                missing.add(s);
            }
        }
        return missing;
    }

    /** Variantes de color que aún no se han encontrado para una especie. */
    public Set<ColorVariant> missingVariants(Species species) {
        EnumSet<ColorVariant> missing = EnumSet.allOf(ColorVariant.class);
        for (ColorVariant v : ColorVariant.values()) {
            if (isDiscovered(species, v)) missing.remove(v);
        }
        return missing;
    }

    public Set<String> discoveredHybridKeys() {
        return Collections.unmodifiableSet(hybridCopies.keySet());
    }

    public int hybridsDiscovered() {
        return hybridCopies.size();
    }

    /** Registra un híbrido por su clave, p. ej. "tyrannosaurus_rex_x_carnotaurus". */
    public void recordHybridKey(String key) {
        hybridCopies.merge(key, 1, Integer::sum);
    }

    /**
     * Texto compacto para guardar y sincronizar la enciclopedia. Ejemplo:
     * "s:velociraptor:azul=2;h:tyrannosaurus_rex_x_carnotaurus=1;"
     */
    public String toCompact() {
        StringBuilder sb = new StringBuilder();
        for (Species s : Species.values()) {
            EnumMap<ColorVariant, Integer> byVariant = copies.get(s);
            if (byVariant == null) continue;
            for (ColorVariant v : ColorVariant.values()) {
                int count = byVariant.getOrDefault(v, 0);
                if (count > 0) {
                    sb.append("s:").append(s.key()).append(':').append(v.key()).append('=').append(count).append(';');
                }
            }
        }
        for (Map.Entry<String, Integer> e : hybridCopies.entrySet()) {
            sb.append("h:").append(e.getKey()).append('=').append(e.getValue()).append(';');
        }
        return sb.toString();
    }

    /** Lee el texto de {@link #toCompact()}. Las entradas desconocidas se ignoran. */
    public static Encyclopedia fromCompact(String text) {
        Encyclopedia enc = new Encyclopedia();
        if (text == null || text.isBlank()) {
            return enc;
        }
        for (String entry : text.split(";")) {
            int eq = entry.lastIndexOf('=');
            if (entry.isBlank() || eq < 0) continue;
            String key = entry.substring(0, eq);
            int count;
            try {
                count = Integer.parseInt(entry.substring(eq + 1));
            } catch (NumberFormatException e) {
                continue;
            }
            if (count <= 0) continue;
            if (key.startsWith("s:")) {
                String[] parts = key.substring(2).split(":");
                if (parts.length != 2) continue;
                try {
                    Species species = Species.valueOf(parts[0].toUpperCase(Locale.ROOT));
                    ColorVariant variant = ColorVariant.valueOf(parts[1].toUpperCase(Locale.ROOT));
                    enc.copies.computeIfAbsent(species, k -> new EnumMap<>(ColorVariant.class)).put(variant, count);
                } catch (IllegalArgumentException ignored) {
                    // Clave de una especie o variante que ya no existe: se ignora.
                }
            } else if (key.startsWith("h:")) {
                enc.hybridCopies.put(key.substring(2), count);
            }
        }
        return enc;
    }
}
