package com.monstercollector.domain;

import java.util.List;
import java.util.Objects;

/**
 * Estado de una criatura concreta: especie o híbrido, variante, nivel y experiencia.
 * Es inmutable: cada cambio devuelve un perfil nuevo. La persistencia (NBT) llega en la siguiente parte.
 */
public record CreatureProfile(
        String key,
        String name,
        BaseStats baseStats,
        Rarity rarity,
        ColorVariant variant,
        List<Ability> abilities,
        int level,
        long xp,
        int maxLevel) {

    public CreatureProfile {
        Objects.requireNonNull(key, "key");
        Objects.requireNonNull(name, "name");
        Objects.requireNonNull(baseStats, "baseStats");
        Objects.requireNonNull(rarity, "rarity");
        Objects.requireNonNull(variant, "variant");
        abilities = List.copyOf(abilities);
        if (maxLevel < 1 || maxLevel > Leveling.HARD_MAX_LEVEL) {
            throw new IllegalArgumentException("Nivel máximo fuera de rango: " + maxLevel);
        }
        if (level < 1 || level > maxLevel) {
            throw new IllegalArgumentException("Nivel fuera de rango: " + level);
        }
        if (xp < 0) {
            throw new IllegalArgumentException("La experiencia no puede ser negativa");
        }
    }

    /** Ejemplar salvaje de una especie: nivel 1 y sin experiencia. */
    public static CreatureProfile wild(Species species, ColorVariant variant, int maxLevel) {
        return new CreatureProfile(
                species.key(), species.displayName(), species.baseStats(), species.rarity(),
                variant, species.abilities(), 1, 0L, maxLevel);
    }

    /** Cría recién nacida de un híbrido. */
    public static CreatureProfile ofHybrid(Hybrid hybrid, int maxLevel) {
        return new CreatureProfile(
                hybrid.key(), hybrid.name(), hybrid.stats(), hybrid.rarity(),
                hybrid.variant(), hybrid.abilities(), 1, 0L, maxLevel);
    }

    /** Estadísticas actuales: base × multiplicador de rareza × crecimiento por nivel. */
    public BaseStats currentStats() {
        return baseStats.scaled(rarity.statMultiplier() * Leveling.statMultiplier(level));
    }

    public long xpForNextLevel() {
        return level >= maxLevel ? 0L : Leveling.xpToNextLevel(level);
    }

    /** Suma experiencia y sube de nivel tantas veces como haga falta, sin pasar del máximo. */
    public XpGain gainXp(long amount) {
        if (amount < 0) {
            throw new IllegalArgumentException("La experiencia ganada no puede ser negativa");
        }
        if (level >= maxLevel) {
            return new XpGain(this, 0);
        }
        long pool = xp + amount;
        int newLevel = level;
        while (newLevel < maxLevel && pool >= Leveling.xpToNextLevel(newLevel)) {
            pool -= Leveling.xpToNextLevel(newLevel);
            newLevel++;
        }
        if (newLevel == maxLevel) {
            pool = 0L;
        }
        CreatureProfile updated = new CreatureProfile(
                key, name, baseStats, rarity, variant, abilities, newLevel, pool, maxLevel);
        return new XpGain(updated, newLevel - level);
    }

    public record XpGain(CreatureProfile profile, int levelsGained) {}
}
