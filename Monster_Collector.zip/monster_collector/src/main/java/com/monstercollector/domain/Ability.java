package com.monstercollector.domain;

import java.util.Objects;

/**
 * Habilidad especial. {@code power} es un multiplicador del daño base (ofensiva),
 * una reducción de daño recibido (defensiva, entre 0 y 1) o un multiplicador de movimiento.
 */
public record Ability(String id, String name, Kind kind, int cooldownSeconds, double power) {

    public enum Kind { OFENSIVA, DEFENSIVA, MOVIMIENTO }

    public static final int MIN_COOLDOWN_SECONDS = 2;
    public static final int MAX_COOLDOWN_SECONDS = 20;
    public static final double MAX_POWER = 2.5;

    public Ability {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(name, "name");
        Objects.requireNonNull(kind, "kind");
        if (cooldownSeconds < MIN_COOLDOWN_SECONDS || cooldownSeconds > MAX_COOLDOWN_SECONDS) {
            throw new IllegalArgumentException(id + ": reutilización fuera de rango (" + cooldownSeconds + " s)");
        }
        if (power < 0.0 || power > MAX_POWER) {
            throw new IllegalArgumentException(id + ": potencia fuera de rango (" + power + ")");
        }
        if (kind == Kind.OFENSIVA && power < 1.0) {
            throw new IllegalArgumentException(id + ": una habilidad ofensiva necesita potencia >= 1.0");
        }
        if (kind == Kind.DEFENSIVA && (power <= 0.0 || power >= 1.0)) {
            throw new IllegalArgumentException(id + ": una habilidad defensiva necesita potencia entre 0 y 1");
        }
    }
}
