package com.monstercollector.domain;

/** Hábitat general. La conversión a biomas concretos de Minecraft se hará en la siguiente parte. */
public enum Habitat implements Labeled {
    SELVA("Selvas y junglas"),
    LLANURA("Llanuras"),
    MONTANA("Montañas"),
    ZONA_CALIDA("Regiones cálidas (desierto, sabana)"),
    BOSQUE_OSCURO("Bosques oscuros"),
    OCEANO("Océanos"),
    AGUA_DULCE("Ríos y lagos"),
    ZONA_MINERAL("Zonas de minerales y cristales");

    private final String displayName;

    Habitat(String displayName) {
        this.displayName = displayName;
    }

    @Override
    public String displayName() {
        return displayName;
    }
}
