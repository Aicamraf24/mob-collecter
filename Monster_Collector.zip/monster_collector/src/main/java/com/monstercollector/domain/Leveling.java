package com.monstercollector.domain;

/** Curva de experiencia y crecimiento de estadísticas por nivel. */
public final class Leveling {

    /** Límite técnico. El nivel máximo real es configurable por debajo de este valor. */
    public static final int HARD_MAX_LEVEL = 100;
    public static final int DEFAULT_MAX_LEVEL = 50;

    /** Cada nivel mejora vida y daño un 3 % adicional. */
    private static final double STAT_GROWTH_PER_LEVEL = 0.03;

    private Leveling() {}

    /** Experiencia necesaria para pasar del nivel {@code level} al siguiente. */
    public static long xpToNextLevel(int level) {
        return 20L + 3L * level * level;
    }

    public static double statMultiplier(int level) {
        return 1.0 + STAT_GROWTH_PER_LEVEL * (level - 1);
    }
}
