package com.monstercollector.domain;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.random.RandomGenerator;

/**
 * Selección de especie al generar una criatura. Primero se elige la rareza según su peso
 * y después una especie al azar dentro de esa rareza. Así la rareza controla la frecuencia,
 * y la variante de color se elige aparte (ver {@link ColorVariant#random}).
 */
public final class SpawnTable {

    private SpawnTable() {}

    public static Species pick(List<Species> eligible, RandomGenerator rng) {
        if (eligible.isEmpty()) {
            throw new IllegalArgumentException("No hay especies elegibles");
        }
        Map<Rarity, List<Species>> byRarity = new EnumMap<>(Rarity.class);
        for (Species s : eligible) {
            byRarity.computeIfAbsent(s.rarity(), r -> new ArrayList<>()).add(s);
        }
        int total = 0;
        for (Rarity r : byRarity.keySet()) {
            total += r.spawnWeight();
        }
        int roll = rng.nextInt(total);
        for (Map.Entry<Rarity, List<Species>> entry : byRarity.entrySet()) {
            roll -= entry.getKey().spawnWeight();
            if (roll < 0) {
                List<Species> options = entry.getValue();
                return options.get(rng.nextInt(options.size()));
            }
        }
        throw new IllegalStateException("Selección fuera de rango");
    }
}
