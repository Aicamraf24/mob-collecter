package com.monstercollector.domain;

public enum Behavior implements Labeled {
    PASIVO("Pasivo"),
    NEUTRAL("Neutral"),
    AGRESIVO("Agresivo"),
    TERRITORIAL("Territorial"),
    NOCTURNO("Nocturno");

    private final String displayName;

    Behavior(String displayName) {
        this.displayName = displayName;
    }

    @Override
    public String displayName() {
        return displayName;
    }
}
