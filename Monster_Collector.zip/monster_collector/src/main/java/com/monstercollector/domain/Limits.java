package com.monstercollector.domain;

/**
 * Límites de rendimiento. Todo lo que aparece por frecuencia se cuenta en ticks (20 por segundo).
 */
public final class Limits {

    /** Radio en el que se cuentan las criaturas antes de permitir una cría: 24 bloques. */
    public static final double BREEDING_CHECK_RADIUS = 24.0;

    /** Número máximo de criaturas cercanas para que dos ejemplares puedan criar. */
    public static final int MAX_NEARBY_FOR_BREEDING = 8;

    /** Cada cuánto se busca a un jugador cercano para registrar un descubrimiento: 1 segundo. */
    public static final int DISCOVERY_INTERVAL_TICKS = 20;

    /** Cada cuánto se actualiza la IA de dueño y la experiencia por exploración: medio segundo. */
    public static final int AI_INTERVAL_TICKS = 10;

    private Limits() {}

    /** True si hay sitio para una cría más en la zona. */
    public static boolean canBreedWithCrowd(int nearbyCreatures) {
        return nearbyCreatures < MAX_NEARBY_FOR_BREEDING;
    }
}
