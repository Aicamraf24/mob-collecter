package com.monstercollector.domain;

/** Crecimiento de una cría. Se completa con el tiempo y se acelera alimentándola. Es inmutable. */
public final class Growth {

    /** Tiempo hasta la edad adulta: 20 minutos (24000 ticks). */
    public static final long ADULT_TICKS = 24_000L;
    /** Cada alimentación adelanta 2 minutos (2400 ticks). */
    public static final long FEED_SPEEDUP_TICKS = 2_400L;

    public enum Stage { CRIA, JUVENIL, ADULTO }

    private final long remainingTicks;

    private Growth(long remainingTicks) {
        this.remainingTicks = remainingTicks;
    }

    public static Growth newborn() {
        return new Growth(ADULT_TICKS);
    }

    public static Growth withRemaining(long remainingTicks) {
        if (remainingTicks < 0 || remainingTicks > ADULT_TICKS) {
            throw new IllegalArgumentException("Tiempo restante fuera de rango: " + remainingTicks);
        }
        return new Growth(remainingTicks);
    }

    public Growth tick(long ticks) {
        return new Growth(Math.max(0L, remainingTicks - ticks));
    }

    /** Alimentar a una cría la acerca a la edad adulta. A un adulto no le afecta. */
    public Growth feed() {
        return new Growth(Math.max(0L, remainingTicks - FEED_SPEEDUP_TICKS));
    }

    public boolean isAdult() {
        return remainingTicks == 0L;
    }

    public Stage stage() {
        if (remainingTicks == 0L) return Stage.ADULTO;
        if (remainingTicks > ADULT_TICKS * 2 / 3) return Stage.CRIA;
        return Stage.JUVENIL;
    }

    public long remainingTicks() {
        return remainingTicks;
    }
}
