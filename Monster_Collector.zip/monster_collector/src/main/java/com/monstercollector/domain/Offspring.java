package com.monstercollector.domain;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Resultado de una reproducción: una cría de una especie pura (secondary == null) o un híbrido
 * de dos especies distintas. Un híbrido puede volver a reproducirse si uno de sus padres es compatible.
 */
public record Offspring(Species primary, Species secondary) {

    public boolean isHybrid() {
        return secondary != null;
    }

    /**
     * Calcula la cría de dos ejemplares. Cada ejemplar es una especie pura (secondary null)
     * o un híbrido (secondary no nulo); un híbrido puede cruzarse por cualquiera de sus padres.
     */
    public static Optional<Offspring> resolve(Species a, Species aSecondary, Species b, Species bSecondary) {
        List<Species> left = parents(a, aSecondary);
        List<Species> right = parents(b, bSecondary);
        for (Species x : left) {
            for (Species y : right) {
                if (x == y) return Optional.of(new Offspring(x, null));
            }
        }
        for (Species x : left) {
            for (Species y : right) {
                if (Breeding.canBreed(x, y)) return Optional.of(ordered(x, y));
            }
        }
        return Optional.empty();
    }

    /** Todos los pares de híbrido posibles (a antes que b en el enum). */
    public static List<Offspring> allHybridPairs() {
        List<Offspring> pairs = new ArrayList<>();
        Species[] all = Species.values();
        for (int i = 0; i < all.length; i++) {
            for (int j = i + 1; j < all.length; j++) {
                if (Breeding.canBreed(all[i], all[j])) {
                    pairs.add(new Offspring(all[i], all[j]));
                }
            }
        }
        return pairs;
    }

    private static List<Species> parents(Species primary, Species secondary) {
        List<Species> list = new ArrayList<>();
        list.add(primary);
        if (secondary != null) list.add(secondary);
        return list;
    }

    private static Offspring ordered(Species x, Species y) {
        return x.ordinal() < y.ordinal() ? new Offspring(x, y) : new Offspring(y, x);
    }
}
