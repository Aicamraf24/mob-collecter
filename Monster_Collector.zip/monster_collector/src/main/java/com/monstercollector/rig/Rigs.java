package com.monstercollector.rig;

import com.monstercollector.domain.Species;

import java.util.EnumMap;
import java.util.Map;

/**
 * Anatomía de las 44 especies. Cada línea: nombre ROL px py pz w h d.
 * Las patas (LEG) y los brazos (ARM) cuelgan desde su punto de giro hasta el suelo (y = 24).
 */
public final class Rigs {

    private static final Map<Species, String> TEXT = new EnumMap<>(Species.class);
    private static final Map<Species, Rig> CACHE = new EnumMap<>(Species.class);

    static {
        TEXT.put(Species.TYRANNOSAURUS_REX, """
            body   BODY   0 11 0 12 10 18
            head   HEAD   0 6 -12 10 10 10
            jaw    STATIC 0 12 -17 6 4 8
            arm_l  ARM    5 14 -7 2 4 2
            arm_r  ARM    -5 14 -7 2 4 2
            leg_l  LEG    4 15 2 5 9 5
            leg_r  LEG    -4 15 2 5 9 5
            tail   TAIL   0 11 11 6 6 14
            """);
        TEXT.put(Species.VELOCIRAPTOR, """
            body   BODY   0 12 0 6 6 10
            head   HEAD   0 8 -7 5 5 6
            crest  STATIC 0 5 -6 1 2 4
            arm_l  ARM    3 14 -3 1 3 1
            arm_r  ARM    -3 14 -3 1 3 1
            leg_l  LEG    2 16 1 2 8 2
            leg_r  LEG    -2 16 1 2 8 2
            tail   TAIL   0 13 7 3 3 10
            """);
        TEXT.put(Species.TRICERATOPS, """
            body   BODY   0 12 0 12 9 18
            head   HEAD   0 10 -12 10 9 6
            frill  STATIC 0 9 -10 14 8 2
            horn_l STATIC 4 8 -15 1 3 1
            horn_r STATIC -4 8 -15 1 3 1
            leg_fl LEG    4 16 -6 4 8 4
            leg_fr LEG    -4 16 -6 4 8 4
            leg_bl LEG    4 16 6 4 8 4
            leg_br LEG    -4 16 6 4 8 4
            tail   TAIL   0 12 11 4 4 6
            """);
        TEXT.put(Species.STEGOSAURUS, """
            body   BODY   0 13 0 10 7 16
            head   HEAD   0 11 -10 6 5 6
            plate1 STATIC 0 7 -2 3 4 2
            plate2 STATIC 0 7 3 3 5 2
            plate3 STATIC 0 7 8 3 4 2
            leg_fl LEG    3 16 -5 3 8 3
            leg_fr LEG    -3 16 -5 3 8 3
            leg_bl LEG    3 16 5 3 8 3
            leg_br LEG    -3 16 5 3 8 3
            tail   TAIL   0 12 10 3 3 10
            """);
        TEXT.put(Species.BRACHIOSAURUS, """
            body   BODY   0 10 0 12 8 20
            neck   STATIC 0 6 -9 4 12 4
            head   HEAD   0 0 -11 6 5 7
            leg_fl LEG    4 15 -7 4 9 4
            leg_fr LEG    -4 15 -7 4 9 4
            leg_bl LEG    4 15 7 4 9 4
            leg_br LEG    -4 15 7 4 9 4
            tail   TAIL   0 10 12 4 4 12
            """);
        TEXT.put(Species.SPINOSAURUS, """
            body   BODY   0 11 0 11 9 17
            head   HEAD   0 7 -11 8 8 8
            sail   STATIC 0 6 2 2 8 14
            arm_l  ARM    4 14 -5 2 4 2
            arm_r  ARM    -4 14 -5 2 4 2
            leg_l  LEG    4 15 2 4 9 4
            leg_r  LEG    -4 15 2 4 9 4
            tail   TAIL   0 11 10 5 5 12
            """);
        TEXT.put(Species.ANKYLOSAURUS, """
            body   BODY   0 12 0 14 8 18
            armor  STATIC 0 8 0 14 3 16
            head   HEAD   0 11 -11 8 7 7
            club   TAIL   0 11 12 6 6 6
            leg_fl LEG    5 16 -6 4 8 4
            leg_fr LEG    -5 16 -6 4 8 4
            leg_bl LEG    5 16 6 4 8 4
            leg_br LEG    -5 16 6 4 8 4
            """);
        TEXT.put(Species.CARNOTAURUS, """
            body   BODY   0 11 0 10 9 16
            head   HEAD   0 7 -10 9 8 8
            horn_l STATIC 3 4 -9 1 3 1
            horn_r STATIC -3 4 -9 1 3 1
            arm_l  ARM    4 14 -4 1 3 1
            arm_r  ARM    -4 14 -4 1 3 1
            leg_l  LEG    4 15 2 4 9 4
            leg_r  LEG    -4 15 2 4 9 4
            tail   TAIL   0 11 9 5 5 12
            """);
        TEXT.put(Species.PTERANODON, """
            body   BODY   0 12 0 5 5 8
            head   HEAD   0 9 -6 5 4 4
            beak   STATIC 0 9 -9 1 1 4
            wing_l WING   6 9 0 14 1 6
            wing_r WING   -6 9 0 14 1 6
            leg_l  LEG    2 18 0 1 6 1
            leg_r  LEG    -2 18 0 1 6 1
            tail   TAIL   0 12 6 2 2 4
            """);
        TEXT.put(Species.QUETZALCOATLUS, """
            body   BODY   0 11 0 5 6 9
            head   HEAD   0 8 -7 5 5 6
            crest  STATIC 0 6 -5 1 3 3
            beak   STATIC 0 9 -11 1 2 6
            wing_l WING   7 9 0 22 1 8
            wing_r WING   -7 9 0 22 1 8
            leg_l  LEG    2 17 0 2 7 2
            leg_r  LEG    -2 17 0 2 7 2
            tail   TAIL   0 11 6 2 2 5
            """);
        TEXT.put(Species.DIMORPHODON, """
            body   BODY   0 12 0 4 5 7
            head   HEAD   0 9 -5 4 4 4
            wing_l WING   5 9 0 10 1 5
            wing_r WING   -5 9 0 10 1 5
            leg_l  LEG    2 18 0 1 6 1
            leg_r  LEG    -2 18 0 1 6 1
            tail   TAIL   0 12 5 1 1 8
            """);
        TEXT.put(Species.DRAGON_DE_CRISTAL, """
            body   BODY   0 11 0 12 9 20
            head   HEAD   0 7 -14 9 8 9
            crown  STATIC 0 3 -12 6 4 4
            wing_l WING   9 9 0 24 1 14
            wing_r WING   -9 9 0 24 1 14
            leg_fl LEG    4 17 -6 3 7 3
            leg_fr LEG    -4 17 -6 3 7 3
            leg_bl LEG    4 17 6 3 7 3
            leg_br LEG    -4 17 6 3 7 3
            tail   TAIL   0 11 12 5 5 14
            """);
        TEXT.put(Species.GRIFO_SALVAJE, """
            body   BODY   0 13 0 10 8 16
            head   HEAD   0 10 -10 8 8 7
            beak   STATIC 0 11 -14 3 3 3
            wing_l WING   7 8 0 16 1 9
            wing_r WING   -7 8 0 16 1 9
            leg_fl LEG    3 16 -5 3 8 3
            leg_fr LEG    -3 16 -5 3 8 3
            leg_bl LEG    3 16 5 3 8 3
            leg_br LEG    -3 16 5 3 8 3
            tail   TAIL   0 13 10 3 3 10
            """);
        TEXT.put(Species.MEGALODON, """
            body   BODY   0 12 0 9 8 18
            head   HEAD   0 11 -10 9 7 6
            dorsal STATIC 0 7 1 2 4 5
            fin_l  FIN    5 14 -1 5 1 4
            fin_r  FIN    -5 14 -1 5 1 4
            tail   TAIL   0 13 11 1 9 4
            """);
        TEXT.put(Species.MOSASAURUS, """
            body   BODY   0 12 0 9 7 20
            head   HEAD   0 10 -12 8 6 8
            jaw    STATIC 0 12 -17 6 2 6
            fin_fl FIN    5 13 -5 6 1 4
            fin_fr FIN    -5 13 -5 6 1 4
            fin_bl FIN    5 13 5 6 1 4
            fin_br FIN    -5 13 5 6 1 4
            tail   TAIL   0 12 13 4 4 12
            """);
        TEXT.put(Species.PLESIOSAURUS, """
            body   BODY   0 12 0 10 6 12
            neck   STATIC 0 8 -7 3 8 3
            head   HEAD   0 4 -10 5 4 6
            fin_fl FIN    6 13 -4 7 1 3
            fin_fr FIN    -6 13 -4 7 1 3
            fin_bl FIN    6 13 4 7 1 3
            fin_br FIN    -6 13 4 7 1 3
            tail   TAIL   0 12 8 3 3 9
            """);
        TEXT.put(Species.TIBURON_ABISAL, """
            body   BODY   0 12 0 6 7 16
            head   HEAD   0 11 -10 6 6 6
            dorsal STATIC 0 7 0 1 4 6
            fin_l  FIN    3 13 -2 6 1 4
            fin_r  FIN    -3 13 -2 6 1 4
            tail   TAIL   0 12 10 1 8 4
            """);
        TEXT.put(Species.CALAMAR_GIGANTE, """
            mantle BODY   0 12 0 8 12 8
            eye_l  STATIC 3 9 -4 2 2 2
            eye_r  STATIC -3 9 -4 2 2 2
            tent1  TAIL   3 18 0 1 6 1
            tent2  TAIL   -3 18 0 1 6 1
            tent3  TAIL   2 18 2 1 6 1
            tent4  TAIL   -2 18 2 1 6 1
            tent5  TAIL   0 18 -2 1 6 1
            """);
        TEXT.put(Species.SERPIENTE_MARINA, """
            body   BODY   0 12 -2 4 4 12
            seg2   BODY   0 13 6 4 4 6
            head   HEAD   0 11 -13 5 5 6
            dorsal STATIC 0 9 2 1 3 10
            tail   TAIL   0 13 12 3 3 8
            """);
        TEXT.put(Species.GOLEM_DE_CRISTAL, """
            body   BODY   0 12 0 12 10 10
            head   HEAD   0 4 0 9 7 8
            crystal STATIC 0 5 0 4 5 4
            arm_l  ARM    8 14 0 4 9 4
            arm_r  ARM    -8 14 0 4 9 4
            leg_l  LEG    4 15 0 4 9 4
            leg_r  LEG    -4 15 0 4 9 4
            """);
        TEXT.put(Species.ESCORPION_COLOSAL, """
            body   BODY   0 12 2 10 6 14
            head   HEAD   0 10 -7 7 5 6
            claw_l ARM    6 13 -10 3 2 4
            claw_r ARM    -6 13 -10 3 2 4
            leg_1  LEG    6 18 -2 1 6 1
            leg_2  LEG    -6 18 -2 1 6 1
            leg_3  LEG    6 18 2 1 6 1
            leg_4  LEG    -6 18 2 1 6 1
            leg_5  LEG    6 18 6 1 6 1
            leg_6  LEG    -6 18 6 1 6 1
            stinger TAIL  0 11 13 2 2 12
            """);
        TEXT.put(Species.LOBO_DE_SOMBRAS, """
            body   BODY   0 12 0 6 6 12
            head   HEAD   0 9 -8 6 6 6
            snout  STATIC 0 10 -12 3 3 3
            ear_l  STATIC 2 5 -8 2 3 1
            ear_r  STATIC -2 5 -8 2 3 1
            leg_fl LEG    2 16 -4 2 8 2
            leg_fr LEG    -2 16 -4 2 8 2
            leg_bl LEG    2 16 4 2 8 2
            leg_br LEG    -2 16 4 2 8 2
            tail   TAIL   0 11 9 2 2 8
            """);
        TEXT.put(Species.RINOCERONTE_ACORAZADO, """
            body   BODY   0 12 0 13 10 20
            head   HEAD   0 10 -12 9 8 8
            horn   STATIC 0 6 -17 3 5 3
            armor  STATIC 0 7 0 14 2 18
            leg_fl LEG    4 16 -6 4 8 4
            leg_fr LEG    -4 16 -6 4 8 4
            leg_bl LEG    4 16 6 4 8 4
            leg_br LEG    -4 16 6 4 8 4
            tail   TAIL   0 12 11 2 2 5
            """);
        TEXT.put(Species.FENIX, """
            body   BODY   0 12 0 7 8 11
            head   HEAD   0 8 -7 6 6 6
            crest  STATIC 0 3 -5 6 4 4
            beak   STATIC 0 8 -11 2 2 3
            wing_l WING   7 8 0 16 1 9
            wing_r WING   -7 8 0 16 1 9
            tail   TAIL   0 12 8 6 2 12
            leg_l  LEG    2 18 0 1 6 1
            leg_r  LEG    -2 18 0 1 6 1
            """);
        TEXT.put(Species.LEVIATAN_MENOR, """
            body   BODY   0 12 0 11 9 22
            head   HEAD   0 11 -12 9 8 8
            fin_l  FIN    6 13 -3 7 1 5
            fin_r  FIN    -6 13 -3 7 1 5
            spine  STATIC 0 7 0 2 3 14
            tail   TAIL   0 12 13 3 9 6
            """);
        TEXT.put(Species.PARASAUROLOPHUS, """
            body   BODY   0 12 0 9 8 16
            head   HEAD   0 9 -11 6 6 6
            crest  STATIC 0 5 -14 2 6 3
            arm_l  ARM    3 15 -5 2 4 2
            arm_r  ARM    -3 15 -5 2 4 2
            leg_l  LEG    3 15 3 4 9 4
            leg_r  LEG    -3 15 3 4 9 4
            tail   TAIL   0 12 9 4 4 12
            """);
        TEXT.put(Species.ICHTHYOSAURUS, """
            body   BODY   0 12 0 6 6 14
            head   HEAD   0 11 -9 6 5 5
            fin_l  FIN    4 13 -1 5 1 4
            fin_r  FIN    -4 13 -1 5 1 4
            dorsal STATIC 0 8 1 1 2 5
            tail   TAIL   0 12 9 1 8 4
            """);
        TEXT.put(Species.ALLOSAURUS, """
            body   BODY   0 11 0 10 9 16
            head   HEAD   0 7 -10 9 8 8
            crest  STATIC 0 4 -9 2 3 4
            arm_l  ARM    4 14 -4 2 4 2
            arm_r  ARM    -4 14 -4 2 4 2
            leg_l  LEG    4 15 2 4 9 4
            leg_r  LEG    -4 15 2 4 9 4
            tail   TAIL   0 11 9 5 5 12
            """);
        TEXT.put(Species.GIGANOTOSAURUS, """
            body   BODY   0 11 0 12 11 20
            head   HEAD   0 6 -12 11 10 10
            arm_l  ARM    5 14 -5 2 4 2
            arm_r  ARM    -5 14 -5 2 4 2
            leg_l  LEG    5 14 2 5 10 5
            leg_r  LEG    -5 14 2 5 10 5
            tail   TAIL   0 11 11 6 6 14
            """);
        TEXT.put(Species.DILOPHOSAURUS, """
            body   BODY   0 12 0 6 6 12
            head   HEAD   0 9 -8 6 5 6
            crest_l STATIC 2 6 -8 1 3 2
            crest_r STATIC -2 6 -8 1 3 2
            arm_l  ARM    3 15 -3 1 3 1
            arm_r  ARM    -3 15 -3 1 3 1
            leg_l  LEG    3 16 1 3 8 3
            leg_r  LEG    -3 16 1 3 8 3
            tail   TAIL   0 12 8 3 3 10
            """);
        TEXT.put(Species.COMPSOGNATHUS, """
            body   BODY   0 15 0 4 4 6
            head   HEAD   0 13 -4 4 4 4
            arm_l  ARM    2 18 -2 1 2 1
            arm_r  ARM    -2 18 -2 1 2 1
            leg_l  LEG    2 19 1 1 5 1
            leg_r  LEG    -2 19 1 1 5 1
            tail   TAIL   0 16 5 2 2 8
            """);
        TEXT.put(Species.BARYONYX, """
            body   BODY   0 11 0 9 8 16
            head   HEAD   0 7 -10 8 7 9
            snout  STATIC 0 9 -15 4 3 5
            claw_l ARM    4 14 -5 1 4 1
            claw_r ARM    -4 14 -5 1 4 1
            leg_l  LEG    4 15 2 4 9 4
            leg_r  LEG    -4 15 2 4 9 4
            tail   TAIL   0 11 9 5 5 12
            """);
        TEXT.put(Species.CERATOSAURUS, """
            body   BODY   0 11 0 9 8 16
            head   HEAD   0 7 -10 8 7 8
            horn   STATIC 0 4 -10 2 3 2
            arm_l  ARM    4 14 -4 2 3 2
            arm_r  ARM    -4 14 -4 2 3 2
            leg_l  LEG    4 15 2 4 9 4
            leg_r  LEG    -4 15 2 4 9 4
            tail   TAIL   0 11 9 5 5 12
            """);
        TEXT.put(Species.IGUANODON, """
            body   BODY   0 11 0 10 9 16
            head   HEAD   0 7 -10 7 7 7
            thumb_l STATIC 5 15 -6 2 2 2
            thumb_r STATIC -5 15 -6 2 2 2
            arm_l  ARM    4 15 -5 2 4 2
            arm_r  ARM    -4 15 -5 2 4 2
            leg_l  LEG    4 15 3 4 9 4
            leg_r  LEG    -4 15 3 4 9 4
            tail   TAIL   0 12 9 4 4 10
            """);
        TEXT.put(Species.APATOSAURUS, """
            body   BODY   0 9 0 14 9 22
            neck   STATIC 0 3 -10 4 12 4
            head   HEAD   0 -3 -12 6 5 7
            leg_fl LEG    5 15 -8 5 9 5
            leg_fr LEG    -5 15 -8 5 9 5
            leg_bl LEG    5 15 8 5 9 5
            leg_br LEG    -5 15 8 5 9 5
            tail   TAIL   0 9 14 4 4 16
            """);
        TEXT.put(Species.ARGENTINOSAURUS, """
            body   BODY   0 9 0 16 10 26
            neck   STATIC 0 3 -12 5 13 5
            head   HEAD   0 -2 -14 7 6 8
            leg_fl LEG    6 15 -10 6 9 6
            leg_fr LEG    -6 15 -10 6 9 6
            leg_bl LEG    6 15 10 6 9 6
            leg_br LEG    -6 15 10 6 9 6
            tail   TAIL   0 9 17 5 5 14
            """);
        TEXT.put(Species.GALLIMIMUS, """
            body   BODY   0 13 0 7 6 10
            head   HEAD   0 9 -7 5 5 5
            neck   STATIC 0 10 -5 3 4 3
            arm_l  ARM    3 16 -2 1 3 1
            arm_r  ARM    -3 16 -2 1 3 1
            leg_l  LEG    2 15 1 2 9 2
            leg_r  LEG    -2 15 1 2 9 2
            tail   TAIL   0 13 7 2 2 10
            """);
        TEXT.put(Species.OVIRAPTOR, """
            body   BODY   0 13 0 6 6 10
            head   HEAD   0 9 -7 5 6 5
            crest  STATIC 0 7 -6 2 3 2
            arm_l  ARM    3 16 -3 1 4 1
            arm_r  ARM    -3 16 -3 1 4 1
            leg_l  LEG    2 15 1 2 9 2
            leg_r  LEG    -2 15 1 2 9 2
            tail   TAIL   0 13 7 2 2 9
            """);
        TEXT.put(Species.THERIZINOSAURUS, """
            body   BODY   0 11 0 11 9 14
            head   HEAD   0 6 -9 6 6 6
            neck   STATIC 0 7 -6 3 4 3
            arm_l  ARM    5 13 -5 2 9 2
            arm_r  ARM    -5 13 -5 2 9 2
            leg_l  LEG    4 15 2 4 9 4
            leg_r  LEG    -4 15 2 4 9 4
            tail   TAIL   0 11 9 4 4 8
            """);
        TEXT.put(Species.PULPO_DE_LAS_PROFUNDIDADES, """
            mantle BODY   0 11 0 10 10 10
            eye_l  STATIC 3 9 -5 2 2 1
            eye_r  STATIC -3 9 -5 2 2 1
            tent1  TAIL   4 17 2 1 7 1
            tent2  TAIL   -4 17 2 1 7 1
            tent3  TAIL   2 17 4 1 7 1
            tent4  TAIL   -2 17 4 1 7 1
            tent5  TAIL   0 17 5 1 7 1
            tent6  TAIL   0 17 -1 1 7 1
            tent7  TAIL   6 17 -1 1 7 1
            tent8  TAIL   -6 17 -1 1 7 1
            """);
        TEXT.put(Species.ANGUILA_MARINA, """
            body   BODY   0 12 0 4 4 16
            seg1   BODY   0 12 -7 4 4 6
            head   HEAD   0 11 -13 5 4 5
            fin    STATIC 0 9 4 1 3 14
            tail   TAIL   0 12 13 3 3 8
            """);
        TEXT.put(Species.RAYA_FANTASMA, """
            body   BODY   0 12 0 14 3 14
            head   HEAD   0 12 -8 6 2 4
            wing_l FIN    9 12 0 8 1 12
            wing_r FIN    -9 12 0 8 1 12
            tail   TAIL   0 12 9 1 1 10
            """);
        TEXT.put(Species.BALLENA_ABISAL, """
            body   BODY   0 11 0 14 12 28
            head   HEAD   0 9 -16 12 9 10
            jaw    STATIC 0 13 -18 10 3 6
            fin_l  FIN    7 15 -4 8 1 5
            fin_r  FIN    -7 15 -4 8 1 5
            dorsal STATIC 0 6 2 2 4 6
            tail   TAIL   0 11 16 9 2 8
            """);
        TEXT.put(Species.REINA_DE_LAS_PROFUNDIDADES, """
            bell   BODY   0 9 0 12 8 12
            tent1  TAIL   4 16 0 1 9 1
            tent2  TAIL   -4 16 0 1 9 1
            tent3  TAIL   0 16 4 1 9 1
            tent4  TAIL   0 16 -4 1 9 1
            tent5  TAIL   2 16 2 1 8 1
            tent6  TAIL   -2 16 -2 1 8 1
            glow   STATIC 0 7 0 6 3 6
            """);
    }

    private Rigs() {}

    /** Modelo de la especie, ya con sus piezas colocadas en el atlas. */
    public static Rig of(Species species) {
        return CACHE.computeIfAbsent(species, s -> {
            String text = TEXT.get(s);
            if (text == null) {
                throw new IllegalStateException("Falta el modelo de " + s.displayName());
            }
            return Rig.parse(s.key(), text).packed();
        });
    }

    /** Número de modelos definidos. Debe coincidir con el número de especies. */
    public static int count() {
        return TEXT.size();
    }
}
