package com.monstercollector.rig;

import java.util.ArrayList;
import java.util.List;

/**
 * Coloca las regiones de las cajas en un atlas de texturas (estantes de izquierda a derecha).
 * Cada caja ocupa (2w + 2d) x (d + h) píxeles, igual que el desplegado de cubo de Minecraft.
 */
public final class TexturePacker {

    private TexturePacker() {}

    public static List<Rig.Part> pack(List<Rig.Part> parts, int atlasSize) {
        List<Rig.Part> out = new ArrayList<>(parts.size());
        int x = 0;
        int y = 0;
        int shelfHeight = 0;
        for (Rig.Part p : parts) {
            int w = p.atlasWidth();
            int h = p.atlasHeight();
            if (w > atlasSize || h > atlasSize) {
                throw new IllegalStateException("La pieza " + p.name() + " es mayor que el atlas");
            }
            if (x + w > atlasSize) {
                x = 0;
                y += shelfHeight;
                shelfHeight = 0;
            }
            if (y + h > atlasSize) {
                throw new IllegalStateException("El atlas se queda sin espacio en la pieza " + p.name());
            }
            out.add(p.withUv(x, y));
            x += w;
            shelfHeight = Math.max(shelfHeight, h);
        }
        return out;
    }

    /** True si ninguna región de textura se solapa con otra. */
    public static boolean overlapFree(List<Rig.Part> packed) {
        for (int i = 0; i < packed.size(); i++) {
            Rig.Part a = packed.get(i);
            for (int j = i + 1; j < packed.size(); j++) {
                Rig.Part b = packed.get(j);
                boolean separate = a.u() + a.atlasWidth() <= b.u() || b.u() + b.atlasWidth() <= a.u()
                        || a.v() + a.atlasHeight() <= b.v() || b.v() + b.atlasHeight() <= a.v();
                if (!separate) return false;
            }
        }
        return true;
    }
}
