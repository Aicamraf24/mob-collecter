package com.monstercollector.rig;

import java.util.ArrayList;
import java.util.List;

/** Transformaciones de anatomía: modelo infantil y modelo de híbrido. Puras, sin Minecraft. */
public final class RigTransforms {

    /** Tamaño de las crías respecto al adulto. */
    public static final float BABY_FACTOR = 0.6f;

    private RigTransforms() {}

    /**
     * Modelo de cría: el adulto escalado por BABY_FACTOR. El suelo (y = 24) se mantiene,
     * así la cría no flota ni se hunde.
     */
    public static Rig baby(Rig adult) {
        List<Rig.Part> parts = new ArrayList<>();
        for (Rig.Part p : adult.parts()) {
            parts.add(new Rig.Part(
                    p.name(), p.role(),
                    p.px() * BABY_FACTOR,
                    Rig.GROUND_Y - (Rig.GROUND_Y - p.py()) * BABY_FACTOR,
                    p.pz() * BABY_FACTOR,
                    scaleSize(p.w()), scaleSize(p.h()), scaleSize(p.d()),
                    0, 0));
        }
        return new Rig(adult.key() + "_cria", parts);
    }

    /**
     * Modelo de híbrido: cuerpo, cabeza, patas y brazos del primer padre; alas, cola, aletas y
     * adornos del segundo. Las piezas llevan prefijo para no repetir nombres. Hay que empaquetarlo después.
     */
    public static Rig hybrid(Rig parentA, Rig parentB, String key) {
        List<Rig.Part> parts = new ArrayList<>();
        for (Rig.Part p : parentA.parts()) {
            if (takesFromFirst(p.role())) {
                parts.add(renamed(p, "a_"));
            }
        }
        for (Rig.Part p : parentB.parts()) {
            if (takesFromSecond(p.role())) {
                parts.add(renamed(p, "b_"));
            }
        }
        return new Rig(key, parts);
    }

    private static boolean takesFromFirst(Rig.Role role) {
        return role == Rig.Role.BODY || role == Rig.Role.HEAD || role == Rig.Role.LEG || role == Rig.Role.ARM;
    }

    private static boolean takesFromSecond(Rig.Role role) {
        return role == Rig.Role.WING || role == Rig.Role.TAIL || role == Rig.Role.FIN || role == Rig.Role.STATIC;
    }

    private static Rig.Part renamed(Rig.Part p, String prefix) {
        return new Rig.Part(prefix + p.name(), p.role(), p.px(), p.py(), p.pz(), p.w(), p.h(), p.d(), 0, 0);
    }

    private static int scaleSize(int size) {
        return Math.max(1, Math.round(size * BABY_FACTOR));
    }
}
