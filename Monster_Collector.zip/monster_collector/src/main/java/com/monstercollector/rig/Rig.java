package com.monstercollector.rig;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Anatomía de una criatura: un conjunto de piezas-caja. Pura (sin Minecraft), así se puede probar.
 * Coordenadas en unidades de modelo de Minecraft: 16 unidades = 1 bloque, el suelo está en y = 24,
 * y en el modelo "más alto" significa "más abajo".
 */
public record Rig(String key, List<Part> parts) {

    public static final int ATLAS_SIZE = 256;
    public static final float GROUND_Y = 24f;

    /** Función de cada pieza: determina qué animación recibe. */
    public enum Role {
        BODY, HEAD, LEG, ARM, WING, TAIL, FIN, STATIC;

        /** Las extremidades cuelgan desde su punto de giro hacia abajo; el resto se centra en él. */
        public boolean hangsDown() {
            return this == LEG || this == ARM;
        }
    }

    /**
     * Pieza de la criatura. (px, py, pz) es el punto de giro; w, h, d son las dimensiones de la caja;
     * (u, v) es la posición en el atlas de texturas, asignada por {@link TexturePacker}.
     */
    public record Part(String name, Role role, float px, float py, float pz, int w, int h, int d, int u, int v) {
        public Part {
            if (w <= 0 || h <= 0 || d <= 0) {
                throw new IllegalArgumentException("Dimensiones no válidas en la pieza " + name);
            }
        }

        public Part withUv(int newU, int newV) {
            return new Part(name, role, px, py, pz, w, h, d, newU, newV);
        }

        /** Ancho de la región de textura que ocupa la caja (las seis caras). */
        public int atlasWidth() {
            return 2 * w + 2 * d;
        }

        /** Alto de la región de textura que ocupa la caja. */
        public int atlasHeight() {
            return d + h;
        }
    }

    public Rig {
        parts = List.copyOf(parts);
        if (parts.isEmpty()) {
            throw new IllegalArgumentException("El modelo " + key + " no tiene piezas");
        }
        Set<String> names = new HashSet<>();
        for (Part p : parts) {
            if (!names.add(p.name())) {
                throw new IllegalArgumentException("Nombre de pieza duplicado en " + key + ": " + p.name());
            }
        }
    }

    /**
     * Lee un modelo desde texto. Cada línea es:
     * {@code nombre ROL px py pz w h d} (8 campos). Las líneas vacías y las que empiezan por # se ignoran.
     */
    public static Rig parse(String key, String text) {
        if (text == null) {
            throw new IllegalArgumentException("Falta el modelo de " + key);
        }
        List<Part> parts = new ArrayList<>();
        int lineNo = 0;
        for (String raw : text.split("\\R")) {
            lineNo++;
            String line = raw.trim();
            if (line.isEmpty() || line.startsWith("#")) {
                continue;
            }
            String[] t = line.split("\\s+");
            if (t.length != 8) {
                throw new IllegalArgumentException(key + ":" + lineNo + " esperaba 8 campos y hay " + t.length);
            }
            Role role;
            try {
                role = Role.valueOf(t[1]);
            } catch (IllegalArgumentException e) {
                throw new IllegalArgumentException(key + ":" + lineNo + " rol desconocido " + t[1]);
            }
            parts.add(new Part(
                    t[0], role,
                    Float.parseFloat(t[2]), Float.parseFloat(t[3]), Float.parseFloat(t[4]),
                    Integer.parseInt(t[5]), Integer.parseInt(t[6]), Integer.parseInt(t[7]),
                    0, 0));
        }
        return new Rig(key, parts);
    }

    /** Devuelve el mismo modelo con cada pieza colocada en el atlas. */
    public Rig packed() {
        return new Rig(key, TexturePacker.pack(parts, ATLAS_SIZE));
    }

    /** Ancho del modelo en bloques, para el tamaño de la hitbox. */
    public double widthBlocks() {
        double extent = 0;
        for (Part p : parts) {
            extent = Math.max(extent, Math.abs(p.px()) + p.w() / 2.0);
        }
        return Math.max(0.5, 2 * extent / 16.0);
    }

    /**
     * Huella del modelo en bloques, para la hitbox: el mayor de ancho y largo, sin contar las alas,
     * para que una voladora no tenga una caja enorme en el suelo.
     */
    public double footprintBlocks() {
        double extent = 0;
        for (Part p : parts) {
            if (p.role() == Role.WING) continue;
            extent = Math.max(extent, Math.abs(p.px()) + p.w() / 2.0);
            extent = Math.max(extent, Math.abs(p.pz()) + p.d() / 2.0);
        }
        return Math.max(0.5, 2 * extent / 16.0);
    }

    /** Alto del modelo en bloques, desde el suelo hasta la pieza más alta. */
    public double heightBlocks() {
        double top = GROUND_Y;
        for (Part p : parts) {
            double partTop = p.role().hangsDown() ? p.py() : p.py() - p.h() / 2.0;
            top = Math.min(top, partTop);
        }
        return Math.max(0.5, (GROUND_Y - top) / 16.0);
    }
}
