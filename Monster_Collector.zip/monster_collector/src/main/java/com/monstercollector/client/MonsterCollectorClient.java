package com.monstercollector.client;

import net.fabricmc.api.ClientModInitializer;

public class MonsterCollectorClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        CreatureClient.register();
    }
}
