package com.monstercollector.client;

import net.minecraft.client.Minecraft;

/** Punto de entrada de la pantalla de la enciclopedia. Solo se llama desde el cliente. */
public final class EncyclopediaClient {

    private EncyclopediaClient() {}

    public static void open() {
        Minecraft.getInstance().setScreen(new EncyclopediaScreen());
    }
}
