package com.monstercollector.client;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

/** Datos que el renderizador necesita del ejemplar en cada fotograma. */
public class CreatureRenderState extends LivingEntityRenderState {
    /** Clave de la especie o del híbrido, para elegir la textura. */
    public String speciesKey = "";
    public int variantIndex;
    public boolean baby;
    public boolean resting;
    public boolean sitting;
    public boolean saddled;
    public boolean attacking;
    public boolean flying;
    public boolean swimming;
}
