package com.monstercollector.client;

import com.monstercollector.MonsterCollector;
import com.monstercollector.domain.Offspring;
import com.monstercollector.domain.Species;
import com.monstercollector.entity.CreatureEntity;
import com.monstercollector.entity.ModEntityTypes;
import com.monstercollector.rig.Rig;
import com.monstercollector.rig.RigTransforms;
import com.monstercollector.rig.Rigs;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.EntityType;

/** Registro de modelos y renderizadores de las 44 especies y de los 67 híbridos en el cliente. */
public final class CreatureClient {

    private CreatureClient() {}

    public static ModelLayerLocation layerOf(String key) {
        return new ModelLayerLocation(Identifier.fromNamespaceAndPath(MonsterCollector.MOD_ID, key), "main");
    }

    public static void register() {
        for (Species s : Species.values()) {
            registerKind(s.key(), Rigs.of(s), ModEntityTypes.typeOf(s));
        }
        for (Offspring pair : Offspring.allHybridPairs()) {
            Species a = pair.primary();
            Species b = pair.secondary();
            String key = ModEntityTypes.hybridKey(a, b);
            Rig rig = RigTransforms.hybrid(Rigs.of(a), Rigs.of(b), key).packed();
            registerKind(key, rig, ModEntityTypes.hybridTypeOf(a, b));
        }
    }

    private static void registerKind(String key, Rig rig, EntityType<CreatureEntity> type) {
        ModelLayerRegistry.registerModelLayer(layerOf(key), () -> CreatureModel.createLayer(rig));
        EntityRendererRegistry.register(type, context -> new CreatureRenderer(context, key, rig));
    }
}
