package com.monstercollector.client;

import com.monstercollector.attachment.ModAttachments;
import com.monstercollector.domain.Ability;
import com.monstercollector.domain.Breeding;
import com.monstercollector.domain.ColorVariant;
import com.monstercollector.domain.Encyclopedia;
import com.monstercollector.domain.Leveling;
import com.monstercollector.domain.Species;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Enciclopedia en pantalla: lista de las 44 especies a la izquierda y la ficha de la seleccionada a la derecha.
 * Las especies sin descubrir aparecen marcadas; las variantes que faltan se listan en la ficha.
 */
public class EncyclopediaScreen extends Screen {

    private static final int PAGE_SIZE = 12;
    private static final int LIST_X = 12;
    private static final int LIST_TOP = 40;
    private static final int PANEL_X = 170;
    private static final int PANEL_TOP = 40;
    private static final int LINE_HEIGHT = 11;

    private final Encyclopedia encyclopedia;
    private final Species[] species = Species.values();
    private int page;
    private int selected;

    public EncyclopediaScreen() {
        super(Component.translatable("gui.monster_collector.encyclopedia.title"));
        this.encyclopedia = Minecraft.getInstance().player.getAttachedOrCreate(ModAttachments.ENCYCLOPEDIA);
    }

    private int pageCount() {
        return (species.length + PAGE_SIZE - 1) / PAGE_SIZE;
    }

    @Override
    protected void init() {
        for (int i = 0; i < PAGE_SIZE; i++) {
            int index = page * PAGE_SIZE + i;
            if (index >= species.length) break;
            final int target = index;
            Component label = Component.literal((isFound(species[index]) ? "[✓] " : "[ ] ") + speciesName(species[index]));
            this.addRenderableWidget(Button.builder(label, b -> selected = target)
                    .bounds(LIST_X, LIST_TOP + i * 18, 150, 16)
                    .build());
        }

        int bottom = this.height - 26;
        this.addRenderableWidget(Button.builder(Component.translatable("gui.monster_collector.encyclopedia.prev"), b -> {
            if (page > 0) {
                page--;
                selected = page * PAGE_SIZE;
                this.rebuildWidgets();
            }
        }).bounds(LIST_X, bottom, 70, 18).build());

        this.addRenderableWidget(Button.builder(Component.translatable("gui.monster_collector.encyclopedia.next"), b -> {
            if (page < pageCount() - 1) {
                page++;
                selected = page * PAGE_SIZE;
                this.rebuildWidgets();
            }
        }).bounds(LIST_X + 92, bottom, 70, 18).build());

        this.addRenderableWidget(Button.builder(CommonComponents.GUI_DONE, b -> this.onClose())
                .bounds(this.width - 92, bottom, 80, 18).build());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        super.extractRenderState(graphics, mouseX, mouseY, delta);

        int percent = (int) Math.round(encyclopedia.completionPercent());
        graphics.text(this.font,
                Component.translatable("gui.monster_collector.encyclopedia.progress", percent,
                        encyclopedia.discoveredCombinations(), Encyclopedia.totalCombinations()),
                LIST_X, 22, 0xFFFFFFFF, false);

        drawDetails(graphics, species[selected]);
    }

    private void drawDetails(GuiGraphicsExtractor graphics, Species s) {
        List<Component> lines = new ArrayList<>();
        lines.add(Component.translatable("entity.monster_collector." + s.key()));
        lines.add(label("gui.monster_collector.rarity", Component.translatable("gui.monster_collector.rarity." + s.rarity().name().toLowerCase(Locale.ROOT))));
        lines.add(stat("gui.monster_collector.health", String.format(Locale.ROOT, "%.0f", s.baseStats().maxHealth())));
        lines.add(stat("gui.monster_collector.damage", String.format(Locale.ROOT, "%.0f", s.baseStats().attackDamage())));
        lines.add(stat("gui.monster_collector.speed", String.format(Locale.ROOT, "%.2f", s.baseStats().movementSpeed())));
        lines.add(stat("gui.monster_collector.max_level", String.valueOf(Leveling.DEFAULT_MAX_LEVEL)));
        lines.add(label("gui.monster_collector.habitat", Component.translatable("gui.monster_collector.habitat." + s.habitat().name().toLowerCase(Locale.ROOT))));
        lines.add(label("gui.monster_collector.diet", Component.translatable("gui.monster_collector.diet." + s.diet().name().toLowerCase(Locale.ROOT))));
        lines.add(label("gui.monster_collector.behavior", Component.translatable("gui.monster_collector.behavior." + s.behavior().name().toLowerCase(Locale.ROOT))));
        lines.add(stat("gui.monster_collector.mates", String.valueOf(Breeding.matesOf(s).size())));

        lines.add(Component.translatable("gui.monster_collector.encyclopedia.abilities"));
        for (Ability a : s.abilities()) {
            lines.add(Component.literal("  " + a.name() + " (" + a.cooldownSeconds() + " s)"));
        }

        int copies = 0;
        for (ColorVariant v : ColorVariant.values()) copies += encyclopedia.copies(s, v);
        lines.add(stat("gui.monster_collector.copies", String.valueOf(copies)));

        List<String> missing = new ArrayList<>();
        for (ColorVariant v : encyclopedia.missingVariants(s)) {
            missing.add(Component.translatable("gui.monster_collector.variant." + v.key()).getString());
        }
        lines.add(Component.translatable("gui.monster_collector.encyclopedia.missing",
                missing.isEmpty() ? Component.translatable("gui.monster_collector.encyclopedia.none").getString() : String.join(", ", missing)));

        int y = PANEL_TOP;
        for (Component line : lines) {
            graphics.text(this.font, line, PANEL_X, y, 0xFFFFFFFF, false);
            y += LINE_HEIGHT;
        }
    }

    private boolean isFound(Species s) {
        return encyclopedia.missingVariants(s).size() < ColorVariant.COUNT;
    }

    private String speciesName(Species s) {
        return Component.translatable("entity.monster_collector." + s.key()).getString();
    }

    private static Component label(String key, Component value) {
        return Component.translatable(key).copy().append(": ").append(value);
    }

    private static Component stat(String key, String value) {
        return Component.translatable(key).copy().append(": " + value);
    }
}
