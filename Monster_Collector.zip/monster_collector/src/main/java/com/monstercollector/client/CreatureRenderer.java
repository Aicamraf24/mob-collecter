package com.monstercollector.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.monstercollector.MonsterCollector;
import com.monstercollector.domain.ColorVariant;
import com.monstercollector.domain.Movement;
import com.monstercollector.entity.CreatureEntity;
import com.monstercollector.rig.Rig;
import com.monstercollector.rig.RigTransforms;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

/**
 * Renderiza una especie o un híbrido. Las crías usan la textura infantil y se dibujan a escala
 * {@link RigTransforms#BABY_FACTOR}, con el suelo en el mismo sitio.
 */
public class CreatureRenderer extends MobRenderer<CreatureEntity, CreatureRenderState, CreatureModel> {

    private final String textureKey;
    private final float modelScale;

    public CreatureRenderer(EntityRendererProvider.Context context, String textureKey, Rig rig, float modelScale) {
        super(context,
                new CreatureModel(context.bakeLayer(CreatureClient.layerOf(textureKey)), rig),
                (float) (rig.footprintBlocks() * modelScale * 0.4));
        this.textureKey = textureKey;
        this.modelScale = modelScale;
    }

    @Override
    public CreatureRenderState createRenderState() {
        return new CreatureRenderState();
    }

    @Override
    public void extractRenderState(CreatureEntity entity, CreatureRenderState state, float tickProgress) {
        super.extractRenderState(entity, state, tickProgress);
        state.speciesKey = textureKey;
        state.variantIndex = entity.variantIndex();
        state.baby = entity.isBaby();
        state.resting = entity.isResting() || entity.domestication().mode() == com.monstercollector.taming.Domestication.Mode.SENTADO;
        state.attacking = entity.isAttacking();
        state.sitting = entity.isSitting();
        state.saddled = entity.isSaddled() && !entity.isBaby();
        state.flying = entity.species().movement() == Movement.VOLADOR;
        state.swimming = entity.species().movement() == Movement.ACUATICO;
    }

    @Override
    public Identifier getTextureLocation(CreatureRenderState state) {
        String suffix = state.baby ? "_cria" : state.saddled ? "_silla" : "";
        return Identifier.fromNamespaceAndPath(
                MonsterCollector.MOD_ID,
                "textures/entity/" + state.speciesKey + "_" + ColorVariant.byIndex(state.variantIndex).key() + suffix + ".png");
    }

    @Override
    protected void scale(CreatureRenderState state, PoseStack poseStack) {
        super.scale(state, poseStack);
        float f = modelScale * (state.baby ? RigTransforms.BABY_FACTOR : 1.0f);
        poseStack.scale(f, f, f);
    }
}
