package com.monstercollector.client;

import com.monstercollector.rig.Rig;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

import java.util.ArrayList;
import java.util.List;

/**
 * Modelo genérico construido a partir de la anatomía de la especie ({@link Rig}).
 * La forma de cada criatura viene de sus datos; la animación depende de la función de cada pieza.
 */
public class CreatureModel extends EntityModel<CreatureRenderState> {

    private record Limb(ModelPart part, float phase) {}
    private record Wing(ModelPart part, float side) {}

    private ModelPart head;
    private ModelPart body;
    private final List<Limb> limbs = new ArrayList<>();
    private final List<Wing> wings = new ArrayList<>();
    private final List<ModelPart> tails = new ArrayList<>();
    private final List<ModelPart> fins = new ArrayList<>();

    public CreatureModel(ModelPart root, Rig rig) {
        super(root);
        int limbCount = 0;
        for (Rig.Part p : rig.parts()) {
            ModelPart mp = root.getChild(p.name());
            switch (p.role()) {
                case HEAD -> head = mp;
                case BODY -> {
                    if (body == null) body = mp;
                }
                case LEG, ARM -> {
                    // Las patas alternan fase para que caminen en oposición
                    limbs.add(new Limb(mp, limbCount % 2 == 0 ? 0.0f : Mth.PI));
                    limbCount++;
                }
                case WING -> wings.add(new Wing(mp, p.px() < 0 ? -1.0f : 1.0f));
                case TAIL -> tails.add(mp);
                case FIN -> fins.add(mp);
                default -> { }
            }
        }
    }

    /** Capa de geometría del modelo. Se registra una vez por especie en el cliente. */
    public static LayerDefinition createLayer(Rig rig) {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        for (Rig.Part p : rig.parts()) {
            float x = -p.w() / 2.0f;
            float z = -p.d() / 2.0f;
            float y = p.role().hangsDown() ? 0.0f : -p.h() / 2.0f;
            CubeListBuilder cubes = CubeListBuilder.create()
                    .texOffs(p.u(), p.v())
                    .addBox(x, y, z, p.w(), p.h(), p.d());
            root.addOrReplaceChild(p.name(), cubes, PartPose.offset(p.px(), p.py(), p.pz()));
        }
        return LayerDefinition.create(mesh, Rig.ATLAS_SIZE, Rig.ATLAS_SIZE);
    }

    @Override
    public void setupAnim(CreatureRenderState state) {
        super.setupAnim(state);

        if (state.sitting) {
            // Sentada: las patas se doblan hacia delante y el cuerpo se inclina hacia atrás.
            for (Limb limb : limbs) {
                limb.part().xRot = -1.2f;
            }
            if (body != null) {
                body.xRot = -0.35f;
            }
        } else {
            float amplitude = Math.min(state.walkAnimationSpeed, 1.0f);
            for (Limb limb : limbs) {
                limb.part().xRot = Mth.cos(state.walkAnimationPos * 0.6662f + limb.phase()) * 1.4f * amplitude;
            }
            if (body != null) {
                body.xRot = state.attacking ? 0.12f : 0.0f;
            }
        }

        if (head != null) {
            head.xRot = state.resting ? 0.6f : (state.attacking ? -0.2f : 0.0f);
        }

        for (Wing wing : wings) {
            wing.part().zRot = state.flying ? Mth.sin(state.ageInTicks * 0.6f) * 0.8f * wing.side() : 0.0f;
        }

        float sway = Mth.sin(state.ageInTicks * 0.1f) * 0.25f;
        for (ModelPart tail : tails) {
            tail.yRot = sway;
        }

        float swim = Mth.sin(state.ageInTicks * 0.15f) * 0.3f;
        for (ModelPart fin : fins) {
            fin.yRot = state.swimming ? swim : 0.0f;
        }
    }
}
