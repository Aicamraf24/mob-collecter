#!/usr/bin/env python3
"""
Genera los datos de Monster Collector: idiomas (es_es y en_us), ítem de la enciclopedia (modelo, textura y receta),
y las tablas de botín de las 44 especies y de los 67 híbridos.

Uso, desde la raíz del proyecto:
    python3 tools/generate_data.py

Todo se lee de Species.java y Breeding.java, así que no hay que mantener nada a mano en dos sitios.
"""
import json
import os
import re
import struct
import zlib

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DOMAIN = os.path.join(ROOT, "src/main/java/com/monstercollector/domain")
OUT = os.path.join(ROOT, "src/main/resources")
NS_ASSETS = os.path.join(OUT, "assets/monster_collector")
NS_DATA = os.path.join(OUT, "data/monster_collector")
RARITY_ORDER = ["COMMON", "UNCOMMON", "RARE", "EPIC", "LEGENDARY"]

# Nombres en inglés de las especies con nombre en español. Los nombres científicos se quedan igual.
ENGLISH_NAMES = {
    "gólem de cristal": "Crystal Golem", "escorpión colosal": "Colossal Scorpion",
    "lobo de sombras": "Shadow Wolf", "rinoceronte acorazado": "Armored Rhinoceros",
    "fénix": "Phoenix", "grifo salvaje": "Wild Griffin", "dragón de cristal": "Crystal Dragon",
    "megalodón": "Megalodon", "tiburón abisal": "Abyssal Shark", "calamar gigante": "Giant Squid",
    "serpiente marina": "Sea Serpent", "leviatán menor": "Lesser Leviathan",
    "pulpo de las profundidades": "Deep Octopus", "anguila marina": "Sea Eel",
    "raya fantasma": "Ghost Ray", "ballena abisal": "Abyssal Whale",
    "reina de las profundidades": "Queen of the Deep",
}

SPANISH_UI = {
    "gui.monster_collector.encyclopedia.title": "Enciclopedia de criaturas",
    "gui.monster_collector.encyclopedia.progress": "Colección: %1$s%% (%2$s de %3$s variantes)",
    "gui.monster_collector.encyclopedia.prev": "Anterior",
    "gui.monster_collector.encyclopedia.next": "Siguiente",
    "gui.monster_collector.encyclopedia.abilities": "Habilidades:",
    "gui.monster_collector.encyclopedia.missing": "Colores que faltan: %s",
    "gui.monster_collector.encyclopedia.none": "ninguno",
    "gui.monster_collector.rarity": "Rareza",
    "gui.monster_collector.health": "Vida",
    "gui.monster_collector.damage": "Daño",
    "gui.monster_collector.speed": "Velocidad",
    "gui.monster_collector.max_level": "Nivel máximo",
    "gui.monster_collector.habitat": "Hábitat",
    "gui.monster_collector.diet": "Alimentación",
    "gui.monster_collector.behavior": "Comportamiento",
    "gui.monster_collector.mates": "Puede cruzarse con (especies)",
    "gui.monster_collector.copies": "Ejemplares descubiertos",
    "gui.monster_collector.rarity.common": "Común",
    "gui.monster_collector.rarity.uncommon": "Poco común",
    "gui.monster_collector.rarity.rare": "Rara",
    "gui.monster_collector.rarity.epic": "Épica",
    "gui.monster_collector.rarity.legendary": "Legendaria",
    "gui.monster_collector.habitat.selva": "Selvas y junglas",
    "gui.monster_collector.habitat.llanura": "Llanuras",
    "gui.monster_collector.habitat.montana": "Montañas",
    "gui.monster_collector.habitat.zona_calida": "Regiones cálidas",
    "gui.monster_collector.habitat.bosque_oscuro": "Bosques oscuros",
    "gui.monster_collector.habitat.oceano": "Océanos",
    "gui.monster_collector.habitat.agua_dulce": "Ríos y lagos",
    "gui.monster_collector.habitat.zona_mineral": "Zonas de minerales y cristales",
    "gui.monster_collector.diet.carnivoro": "Carnívoro",
    "gui.monster_collector.diet.herbivoro": "Herbívoro",
    "gui.monster_collector.diet.omnivoro": "Omnívoro",
    "gui.monster_collector.diet.piscivoro": "Piscívoro",
    "gui.monster_collector.diet.mineral": "Minerales y cristal",
    "gui.monster_collector.behavior.pasivo": "Pasivo",
    "gui.monster_collector.behavior.neutral": "Neutral",
    "gui.monster_collector.behavior.agresivo": "Agresivo",
    "gui.monster_collector.behavior.territorial": "Territorial",
    "gui.monster_collector.behavior.nocturno": "Nocturno",
    "gui.monster_collector.variant.roja": "Roja",
    "gui.monster_collector.variant.azul": "Azul",
    "gui.monster_collector.variant.verde": "Verde",
    "gui.monster_collector.variant.negra": "Negra",
    "gui.monster_collector.variant.dorada": "Dorada",
    "item.monster_collector.encyclopedia": "Enciclopedia de criaturas",
}

ENGLISH_UI = {
    "gui.monster_collector.encyclopedia.title": "Creature Encyclopedia",
    "gui.monster_collector.encyclopedia.progress": "Collection: %1$s%% (%2$s of %3$s variants)",
    "gui.monster_collector.encyclopedia.prev": "Previous",
    "gui.monster_collector.encyclopedia.next": "Next",
    "gui.monster_collector.encyclopedia.abilities": "Abilities:",
    "gui.monster_collector.encyclopedia.missing": "Missing colors: %s",
    "gui.monster_collector.encyclopedia.none": "none",
    "gui.monster_collector.rarity": "Rarity",
    "gui.monster_collector.health": "Health",
    "gui.monster_collector.damage": "Damage",
    "gui.monster_collector.speed": "Speed",
    "gui.monster_collector.max_level": "Max level",
    "gui.monster_collector.habitat": "Habitat",
    "gui.monster_collector.diet": "Diet",
    "gui.monster_collector.behavior": "Behavior",
    "gui.monster_collector.mates": "Can breed with (species)",
    "gui.monster_collector.copies": "Individuals discovered",
    "gui.monster_collector.rarity.common": "Common",
    "gui.monster_collector.rarity.uncommon": "Uncommon",
    "gui.monster_collector.rarity.rare": "Rare",
    "gui.monster_collector.rarity.epic": "Epic",
    "gui.monster_collector.rarity.legendary": "Legendary",
    "gui.monster_collector.habitat.selva": "Jungles",
    "gui.monster_collector.habitat.llanura": "Plains",
    "gui.monster_collector.habitat.montana": "Mountains",
    "gui.monster_collector.habitat.zona_calida": "Warm regions",
    "gui.monster_collector.habitat.bosque_oscuro": "Dark forests",
    "gui.monster_collector.habitat.oceano": "Oceans",
    "gui.monster_collector.habitat.agua_dulce": "Rivers and lakes",
    "gui.monster_collector.habitat.zona_mineral": "Mineral and crystal zones",
    "gui.monster_collector.diet.carnivoro": "Carnivore",
    "gui.monster_collector.diet.herbivoro": "Herbivore",
    "gui.monster_collector.diet.omnivoro": "Omnivore",
    "gui.monster_collector.diet.piscivoro": "Piscivore",
    "gui.monster_collector.diet.mineral": "Minerals and crystal",
    "gui.monster_collector.behavior.pasivo": "Passive",
    "gui.monster_collector.behavior.neutral": "Neutral",
    "gui.monster_collector.behavior.agresivo": "Aggressive",
    "gui.monster_collector.behavior.territorial": "Territorial",
    "gui.monster_collector.behavior.nocturno": "Nocturnal",
    "gui.monster_collector.variant.roja": "Red",
    "gui.monster_collector.variant.azul": "Blue",
    "gui.monster_collector.variant.verde": "Green",
    "gui.monster_collector.variant.negra": "Black",
    "gui.monster_collector.variant.dorada": "Golden",
    "item.monster_collector.encyclopedia": "Creature Encyclopedia",
}


def read_species():
    """[(clave, nombre, rareza, movimiento, dieta)] en el mismo orden que el enum Species."""
    pattern = re.compile(
        r'^\s+([A-Z0-9_]+)\("([^"]+)", Rarity\.(\w+), Movement\.(\w+), Lineage\.\w+, Habitat\.\w+, Diet\.(\w+)',
        re.M)
    with open(os.path.join(DOMAIN, "Species.java"), encoding="utf-8") as f:
        text = f.read()
    found = [(m.group(1).lower(), m.group(2), m.group(3), m.group(4), m.group(5)) for m in pattern.finditer(text)]
    if len(found) < 25:
        raise SystemExit("No se han encontrado las especies en Species.java")
    return found


def read_extra_pairs():
    with open(os.path.join(DOMAIN, "Breeding.java"), encoding="utf-8") as f:
        text = f.read()
    return {frozenset((a.lower(), b.lower()))
            for a, b in re.findall(r'Set\.of\(Species\.([A-Z0-9_]+), Species\.([A-Z0-9_]+)\)', text)}


def compatible_pairs(species):
    extra = read_extra_pairs()
    lineage = {}
    with open(os.path.join(DOMAIN, "Species.java"), encoding="utf-8") as f:
        for key, lin in re.findall(r'^\s+([A-Z0-9_]+)\("[^"]+".*?Lineage\.(\w+)', f.read(), re.M):
            lineage[key.lower()] = lin
    pairs = []
    keys = [s[0] for s in species]
    for i, ka in enumerate(keys):
        for kb in keys[i + 1:]:
            if lineage[ka] == lineage[kb] or frozenset((ka, kb)) in extra:
                pairs.append((ka, kb))
    return pairs


def write_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write("\n")


def uniform(item, low, high):
    return {
        "function": "minecraft:set_count",
        "count": {"type": "minecraft:uniform", "min": low, "max": high},
    }


def pool(*entries):
    return {"rolls": 1, "entries": list(entries)}


def item_entry(name, low, high):
    return {"type": "minecraft:item", "name": name, "functions": [uniform(None, low, high)]}


def drops_for(diet, movement, rarity):
    """Tabla de botín: huesos siempre; el resto depende de la dieta, el movimiento y la rareza."""
    pools = [pool(item_entry("minecraft:bone", 0, 2))]
    diet_drop = {
        "HERBIVORO": ("minecraft:leather", 0, 2),
        "CARNIVORO": ("minecraft:beef", 0, 1),
        "OMNIVORO": ("minecraft:chicken", 0, 1),
        "PISCIVORO": ("minecraft:cod", 0, 1),
        "MINERAL": ("minecraft:amethyst_shard", 1, 3),
    }.get(diet)
    if diet_drop:
        pools.append(pool(item_entry(*diet_drop)))
    if movement == "VOLADOR":
        pools.append(pool(item_entry("minecraft:feather", 0, 3)))
    if movement == "ACUATICO":
        pools.append(pool(item_entry("minecraft:prismarine_shard", 0, 2)))
    rare_drop = {
        "RARE": ("minecraft:emerald", 0, 1),
        "EPIC": ("minecraft:diamond", 0, 1),
        "LEGENDARY": ("minecraft:nether_star", 0, 1),
    }.get(rarity)
    if rare_drop:
        pools.append(pool(item_entry(*rare_drop)))
    return {"type": "minecraft:entity", "pools": pools}


def png_bytes(width, height, rows):
    raw = b"".join(b"\x00" + bytes(row) for row in rows)

    def chunk(tag, data):
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    header = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", header) + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")


def book_icon():
    """Icono de 16x16: libro marrón con páginas claras."""
    rows = []
    for y in range(16):
        row = bytearray(16 * 3)
        for x in range(16):
            if x in (0, 15) or y in (0, 15):
                color = (60, 30, 15)
            elif 2 <= x <= 13 and 2 <= y <= 13:
                color = (235, 225, 200)
            else:
                color = (130, 75, 35)
            row[x * 3:x * 3 + 3] = bytes(color)
        rows.append(row)
    return png_bytes(16, 16, rows)


def write_lang(species, hybrids):
    lang_dir = os.path.join(NS_ASSETS, "lang")
    os.makedirs(lang_dir, exist_ok=True)
    spanish = {}
    english = {}
    for key, name, _, _, _ in species:
        spanish[f"entity.monster_collector.{key}"] = name
        english[f"entity.monster_collector.{key}"] = ENGLISH_NAMES.get(name.lower(), name)
    names = {key: name for key, name, _, _, _ in species}
    for a, b in hybrids:
        key = f"{a}_x_{b}"
        spanish[f"entity.monster_collector.{key}"] = f"{names[a]} × {names[b]}"
        english[f"entity.monster_collector.{key}"] = f"{ENGLISH_NAMES.get(names[a].lower(), names[a])} × {ENGLISH_NAMES.get(names[b].lower(), names[b])}"
    spanish.update(SPANISH_UI)
    english.update(ENGLISH_UI)
    for locale, entries in (("es_es", spanish), ("en_us", english)):
        with open(os.path.join(lang_dir, f"{locale}.json"), "w", encoding="utf-8") as f:
            json.dump(entries, f, ensure_ascii=False, indent=2, sort_keys=True)
            f.write("\n")
    return len(spanish)


def main():
    species = read_species()
    pairs = compatible_pairs(species)
    by_key = {key: (name, rarity, movement, diet) for key, name, rarity, movement, diet in species}

    # Ítem de la enciclopedia: modelo, textura y receta.
    write_json(os.path.join(NS_ASSETS, "items/encyclopedia.json"),
               {"model": {"type": "minecraft:model", "model": "monster_collector:item/encyclopedia"}})
    write_json(os.path.join(NS_ASSETS, "models/item/encyclopedia.json"),
               {"parent": "minecraft:item/generated",
                "textures": {"layer0": "monster_collector:item/encyclopedia"}})
    os.makedirs(os.path.join(NS_ASSETS, "textures/item"), exist_ok=True)
    with open(os.path.join(NS_ASSETS, "textures/item/encyclopedia.png"), "wb") as f:
        f.write(book_icon())
    write_json(os.path.join(NS_DATA, "recipe/encyclopedia.json"), {
        "type": "minecraft:crafting_shaped",
        "category": "misc",
        "pattern": ["PPP", "PBP", "PPP"],
        "key": {"P": "minecraft:paper", "B": "minecraft:book"},
        "result": {"id": "monster_collector:encyclopedia", "count": 1},
    })

    # Botín de las especies.
    for key, _, rarity, movement, diet in species:
        write_json(os.path.join(NS_DATA, f"loot_table/entities/{key}.json"),
                   drops_for(diet, movement, rarity))

    # Botín de los híbridos: dieta y movimiento del primer padre, rareza de la más alta.
    for a, b in pairs:
        _, ra, ma, da = by_key[a]
        _, rb, _, _ = by_key[b]
        rarity = ra if RARITY_ORDER.index(ra) >= RARITY_ORDER.index(rb) else rb
        write_json(os.path.join(NS_DATA, f"loot_table/entities/{a}_x_{b}.json"),
                   drops_for(da, ma, rarity))

    entries = write_lang(species, pairs)
    print(f"Idiomas: {entries} entradas en es_es y en_us")
    print(f"Botín: {len(species)} especies y {len(pairs)} híbridos")


if __name__ == "__main__":
    main()
