#!/usr/bin/env python3
"""
Genera las texturas de las criaturas.

Cada criatura tiene UNA textura base, la del póster (color principal, color secundario en el vientre y en las
manchas, ojos en la cabeza). Las cinco variantes son recolores de esa misma textura: la variante que coincide con el
póster usa la base tal cual, y las otras cuatro mapean su luminosidad a un degradado de color (ROJA, AZUL, VERDE,
NEGRA, DORADA). Por último, la versión con silla de montar (sufijo _silla) pinta la silla sobre el lomo.

Uso, desde la raíz del proyecto:
    python3 tools/generate_assets.py [all|species|babies|hybrids]
"""
import json
import math
import os
import struct
import sys
import zlib

import palette

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TEX_DIR = os.path.join(ROOT, "src/main/resources/assets/monster_collector/textures/entity")
LAYOUTS = os.path.join(ROOT, "tools/layouts.json")
SIZE = 256

# Degradados de recolor: oscuro, medio y claro de cada variante.
RAMPS = {
    "ROJA": ((70, 8, 8), (200, 38, 34), (255, 150, 120)),
    "AZUL": ((8, 22, 78), (40, 105, 215), (160, 210, 255)),
    "VERDE": ((14, 58, 20), (64, 160, 62), (200, 240, 150)),
    "NEGRA": ((4, 4, 6), (58, 58, 66), (170, 170, 178)),
    "DORADA": ((72, 40, 4), (205, 142, 30), (255, 242, 150)),
}

STYLE_GROUPS = [
    ({"tyrannosaurus_rex", "velociraptor", "triceratops", "stegosaurus", "brachiosaurus", "spinosaurus",
      "ankylosaurus", "carnotaurus", "parasaurolophus", "allosaurus", "giganotosaurus", "dilophosaurus",
      "compsognathus", "baryonyx", "ceratosaurus", "iguanodon", "apatosaurus", "argentinosaurus",
      "gallimimus", "oviraptor", "therizinosaurus", "rinoceronte_acorazado"}, "scales"),
    ({"pteranodon", "quetzalcoatlus", "dimorphodon", "grifo_salvaje", "fenix"}, "stripes"),
    ({"mosasaurus", "plesiosaurus", "ichthyosaurus", "megalodon", "tiburon_abisal", "raya_fantasma",
      "ballena_abisal", "leviatan_menor", "serpiente_marina", "anguila_marina"}, "belly"),
    ({"calamar_gigante", "pulpo_de_las_profundidades"}, "spots"),
    ({"reina_de_las_profundidades", "dragon_de_cristal"}, "glow"),
    ({"golem_de_cristal"}, "crystal"),
    ({"escorpion_colosal"}, "segments"),
    ({"lobo_de_sombras"}, "fur"),
]


def style_of(key):
    for group, style in STYLE_GROUPS:
        if key in group:
            return style
    return "scales"


def seed_of(key):
    return zlib.crc32(key.encode("utf-8")) & 0xFFFF


def clamp01(x):
    return max(0.0, min(1.0, x))


def smooth(a, b, x):
    t = clamp01((x - a) / (b - a))
    return t * t * (3 - 2 * t)


def lerp(a, b, t):
    return tuple(a[i] + (b[i] - a[i]) * t for i in range(3))


def mul(c, f):
    return tuple(max(0.0, min(255.0, c[i] * f)) for i in range(3))


def hash8(x, y, seed):
    return ((x * 73856093) ^ (y * 19349663) ^ seed) & 0xFF


FACE_SHADE = {"top": 1.0, "front": 0.97, "right": 0.92, "left": 0.92, "back": 0.9, "bottom": 0.84}


def faces_of(u, v, w, h, d):
    return {
        "top": (u + d, v, w, d),
        "bottom": (u + d + w, v, w, d),
        "right": (u, v + d, d, h),
        "front": (u + d, v + d, w, h),
        "left": (u + d + w, v + d, d, h),
        "back": (u + 2 * d + w, v + d, w, h),
    }


class Canvas:
    def __init__(self, fill=None, pixels=None):
        self.px = bytearray(pixels) if pixels is not None else bytearray(SIZE * SIZE * 3)
        if pixels is None:
            fill_bytes = bytes(int(c) for c in fill)
            for i in range(0, len(self.px), 3):
                self.px[i:i + 3] = fill_bytes

    def put(self, x, y, c):
        if 0 <= x < SIZE and 0 <= y < SIZE:
            i = (y * SIZE + x) * 3
            self.px[i] = int(c[0])
            self.px[i + 1] = int(c[1])
            self.px[i + 2] = int(c[2])

    def get(self, x, y):
        i = (y * SIZE + x) * 3
        return (self.px[i], self.px[i + 1], self.px[i + 2])

    def copy(self):
        return Canvas(pixels=self.px)

    def rows(self):
        return [self.px[y * SIZE * 3:(y + 1) * SIZE * 3] for y in range(SIZE)]


def pattern_color(style, lx, ly, fw, fh, primary, secondary, seed):
    """Color de un píxel de cara: degradado del vientre y el detalle propio de cada tipo de criatura, todo suave."""
    v = ly / max(1, fh - 1)
    belly = smooth(0.6, 0.85, v) * 0.7
    col = lerp(primary, secondary, belly)
    if style == "scales":
        if lx % 6 == 0 or ly % 6 == 0:
            col = mul(col, 0.92)
    elif style == "stripes":
        band = 0.5 + 0.5 * math.cos(2 * math.pi * (lx + ly) / 9.0)
        col = lerp(col, secondary, band * 0.45)
    elif style == "belly":
        col = mul(col, 0.94 + 0.1 * smooth(0.0, 1.0, v))
    elif style == "spots":
        gx, gy = lx % 9 - 4.5, ly % 9 - 4.5
        dist = math.sqrt(gx * gx + gy * gy)
        col = lerp(col, secondary, clamp01(1 - (dist - 2.2) / 1.2) * 0.8)
    elif style == "glow":
        t = 0.5 + 0.5 * math.sin(0.8 * lx + 0.6 * ly + seed % 10)
        col = lerp(col, lerp(primary, (255, 255, 255), 0.5), t * 0.3)
    elif style == "crystal":
        facet = ((lx + ly) % 8) / 8.0
        col = mul(col, 1.12 - 0.22 * facet)
    elif style == "segments":
        t = 0.5 + 0.5 * math.cos(2 * math.pi * ly / 6.0)
        col = mul(col, 0.92 + 0.1 * t)
    elif style == "fur":
        col = mul(col, 1.0 + (hash8(lx, ly, seed) % 7 - 3) / 100.0)
    return col


def draw_base(canvas, part, primary, secondary, style, seed):
    u, v, w, h, d = part["u"], part["v"], part["w"], part["h"], part["d"]
    role = part["role"]
    regions = faces_of(u, v, w, h, d)
    for face, (fx, fy, fw, fh) in regions.items():
        shade = FACE_SHADE[face]
        for ly in range(fh):
            top_light = 1.06 - 0.12 * (ly / max(1, fh - 1))
            for lx in range(fw):
                col = pattern_color(style, lx, ly, fw, fh, primary, secondary, seed)
                col = mul(col, shade * top_light)
                if lx == 0 or ly == 0 or lx == fw - 1 or ly == fh - 1:
                    col = mul(col, 0.9)
                canvas.put(fx + lx, fy + ly, col)

    if role == "HEAD" and w >= 4 and h >= 4:
        fx, fy, fw, fh = regions["front"]
        eye = max(1, fw // 5)
        for ex in (int(fw * 0.3), int(fw * 0.7) - eye):
            ey = int(fh * 0.4)
            for dy in range(eye):
                for dx in range(eye):
                    canvas.put(fx + ex + dx, fy + ey + dy, (20, 15, 15))
            canvas.put(fx + ex, fy + ey, (240, 240, 240))
        for mx in range(int(fw * 0.3), int(fw * 0.7)):
            canvas.put(fx + mx, fy + int(fh * 0.8), mul(primary, 0.55))


def draw_saddle(canvas, part):
    if part["role"] != "BODY":
        return
    u, v, w, h, d = part["u"], part["v"], part["w"], part["h"], part["d"]
    regions = faces_of(u, v, w, h, d)
    fx, fy, fw, fh = regions["top"]
    leather, dark_leather, stitch = (124, 76, 36), (92, 52, 22), (214, 180, 130)
    for ly in range(1, fh - 1):
        for lx in range(1, fw - 1):
            c = leather
            if ly == 2 or ly == fh - 3:
                c = stitch if lx % 2 == 0 else dark_leather
            canvas.put(fx + lx, fy + ly, c)
    for side in ("right", "left"):
        sx, sy, sw, sh = regions[side]
        for ly in range(max(1, sh // 3)):
            for lx in range(sw):
                canvas.put(sx + lx, sy + ly, dark_leather)


def render_base(parts, origins):
    """origins: {"a": (primario, secundario, estilo, semilla), "b": ...}. Las piezas b_ usan el segundo padre."""
    pa = origins["a"]
    canvas = Canvas(fill=mul(pa[0], 0.25))
    for part in parts:
        o = origins["b"] if part["name"].startswith("b_") and "b" in origins else origins["a"]
        draw_base(canvas, part, o[0], o[1], o[2], o[3])
    return canvas


def gradient_map(canvas, ramp):
    dark, mid, light = ramp
    out = bytearray(len(canvas.px))
    for i in range(0, len(canvas.px), 3):
        r, g, b = canvas.px[i], canvas.px[i + 1], canvas.px[i + 2]
        lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255.0
        if lum < 0.5:
            c = lerp(dark, mid, lum * 2)
        else:
            c = lerp(mid, light, (lum - 0.5) * 2)
        out[i], out[i + 1], out[i + 2] = int(c[0]), int(c[1]), int(c[2])
    return Canvas(pixels=out)


def lighten_canvas(canvas, amount=0.3):
    out = bytearray(len(canvas.px))
    for i in range(0, len(canvas.px), 3):
        for k in range(3):
            out[i + k] = int(canvas.px[i + k] + (255 - canvas.px[i + k]) * amount)
    return Canvas(pixels=out)


def png_rgb(rows):
    raw = b"".join(b"\x00" + bytes(row) for row in rows)

    def chunk(tag, data):
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    header = struct.pack(">IIBBBBB", SIZE, SIZE, 8, 2, 0, 0, 0)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", header) + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")


def write(path, canvas):
    with open(path, "wb") as f:
        f.write(png_rgb(canvas.rows()))


def load_layouts():
    with open(LAYOUTS, encoding="utf-8") as f:
        return json.load(f)


def write_variants(base_by_variant, parts, name, tex_dir, saddled=True):
    count = 0
    for variant, canvas in base_by_variant.items():
        write(os.path.join(tex_dir, f"{name}_{variant.lower()}.png"), canvas)
        count += 1
        if saddled:
            sad = canvas.copy()
            for part in parts:
                draw_saddle(sad, part)
            write(os.path.join(tex_dir, f"{name}_{variant.lower()}_silla.png"), sad)
            count += 1
    return count


def variants_of(base_canvas, identity):
    """La variante del póster es la base; las demás son recolores de la misma base."""
    result = {}
    for variant in palette.VARIANTS:
        result[variant] = base_canvas if variant == identity else gradient_map(base_canvas, RAMPS[variant])
    return result


def make_species(layouts, base, tex_dir):
    count = 0
    for key, parts in layouts["species"].items():
        primary, secondary = base[key]
        origins = {"a": (primary, secondary, style_of(key), seed_of(key))}
        canvas = render_base(parts, origins)
        identity = palette._identity_family(primary, secondary)
        count += write_variants(variants_of(canvas, identity), parts, key, tex_dir)
    return count


def make_babies(layouts, base, tex_dir):
    count = 0
    for key, parts in layouts["species"].items():
        primary, secondary = base[key]
        origins = {"a": (primary, secondary, style_of(key), seed_of(key))}
        canvas = render_base(parts, origins)
        identity = palette._identity_family(primary, secondary)
        for variant, variant_canvas in variants_of(canvas, identity).items():
            write(os.path.join(tex_dir, f"{key}_{variant.lower()}_cria.png"), lighten_canvas(variant_canvas))
            count += 1
    return count


def make_hybrids(layouts, base, tex_dir):
    count = 0
    for key, parts in layouts["hybrids"].items():
        a, b = key.split("_x_")
        origins = {
            "a": (base[a][0], base[a][1], style_of(a), seed_of(a)),
            "b": (base[b][0], base[b][1], style_of(b), seed_of(b)),
        }
        canvas = render_base(parts, origins)
        identity = palette._identity_family(*base[a])
        count += write_variants(variants_of(canvas, identity), parts, key, tex_dir)
    return count


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else "all"
    if mode not in ("all", "species", "babies", "hybrids"):
        raise SystemExit("Uso: generate_assets.py [all|species|babies|hybrids]")
    layouts = load_layouts()
    base = palette.base_palettes()
    os.makedirs(TEX_DIR, exist_ok=True)
    if mode in ("all", "species"):
        print(f"Especies (con silla): {make_species(layouts, base, TEX_DIR)} texturas")
    if mode in ("all", "babies"):
        print(f"Crías: {make_babies(layouts, base, TEX_DIR)} texturas")
    if mode in ("all", "hybrids"):
        print(f"Híbridos (con silla): {make_hybrids(layouts, base, TEX_DIR)} texturas")


if __name__ == "__main__":
    main()
