#!/usr/bin/env python3
"""
Genera las texturas y los archivos de idioma de Monster Collector.

Uso, desde la raíz del proyecto:
    python3 tools/generate_assets.py [all|species|babies|hybrids]

- species: 44 especies x 5 variantes (220 texturas).
- babies:  versión infantil de cada variante, más clara (220 texturas).
- hybrids: un híbrido por cada par compatible y variante. Una mitad de la textura sigue el patrón
           del primer padre y la otra mitad el del segundo.

Los nombres y los linajes se leen de los archivos Java, así no hay que mantenerlos a mano en dos sitios.
"""
import json
import os
import re
import struct
import sys
import zlib

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SPECIES_JAVA = os.path.join(ROOT, "src/main/java/com/monstercollector/domain/Species.java")
BREEDING_JAVA = os.path.join(ROOT, "src/main/java/com/monstercollector/domain/Breeding.java")
OUT = os.path.join(ROOT, "src/main/resources/assets/monster_collector")
SIZE = 256  # mismo tamaño que Rig.ATLAS_SIZE
SPLIT = SIZE // 2

# Mismo orden que ColorVariant: ROJA, AZUL, VERDE, NEGRA, DORADA. Cada paleta: (base, acento, sombra).
PALETTES = [
    ((178, 38, 34), (255, 124, 56), (88, 18, 18)),
    ((36, 88, 186), (120, 206, 255), (16, 36, 98)),
    ((52, 148, 70), (168, 236, 112), (22, 78, 34)),
    ((40, 40, 46), (128, 118, 138), (8, 8, 12)),
    ((212, 160, 42), (255, 240, 130), (118, 78, 14)),
]
VARIANT_KEYS = ["roja", "azul", "verde", "negra", "dorada"]


def read_species():
    """Devuelve [(clave, nombre, linaje)] en el mismo orden que el enum Species."""
    pattern = re.compile(r'^\s+([A-Z0-9_]+)\("([^"]+)".*?Lineage\.([A-Z_]+)', re.M)
    with open(SPECIES_JAVA, encoding="utf-8") as f:
        text = f.read()
    found = [(m.group(1).lower(), m.group(2), m.group(3)) for m in pattern.finditer(text)]
    if len(found) < 25:
        raise SystemExit("No se han encontrado las especies en Species.java")
    return found


def read_extra_pairs():
    """Pares explícitos de reproducción definidos en Breeding.java (Set.of(Species.A, Species.B))."""
    with open(BREEDING_JAVA, encoding="utf-8") as f:
        text = f.read()
    return {frozenset((a.lower(), b.lower())) for a, b in re.findall(r'Set\.of\(Species\.([A-Z0-9_]+), Species\.([A-Z0-9_]+)\)', text)}


def compatible_pairs(species):
    """Pares (a, b) con a antes que b en el enum, compatibles por linaje o por par explícito."""
    extra = read_extra_pairs()
    pairs = []
    for i, (ka, _, la) in enumerate(species):
        for kb, _, lb in species[i + 1:]:
            if la == lb or frozenset((ka, kb)) in extra:
                pairs.append((ka, kb))
    return pairs


def png_bytes(width, height, rows):
    raw = b"".join(b"\x00" + bytes(row) for row in rows)

    def chunk(tag, data):
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    header = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)  # RGB, 8 bits
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", header) + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")


def pattern_color(seed, x, y, palette):
    """Color del patrón de una especie en un píxel."""
    base, accent, dark = palette
    style = seed % 4
    ox = (seed >> 3) % 17
    oy = (seed >> 7) % 13
    if style == 0:  # rayas diagonales
        band = ((x + y + ox) // 10) % 3
        return dark if band == 0 else (base if band == 1 else accent)
    if style == 1:  # manchas
        dx = (x + ox) % 32 - 16
        dy = (y + oy) % 32 - 16
        return accent if dx * dx + dy * dy < 30 else base
    if style == 2:  # escamas
        gx = (x + ox) % 16 - 8
        gy = (y + oy) % 12 - 6
        edge = gx * gx / 64.0 + gy * gy / 36.0
        return accent if edge < 0.25 else (base if edge < 0.8 else dark)
    shade = y / SIZE  # degradado con ruido
    noise = ((x * 73856093) ^ (y * 19349663) ^ seed) & 0x1F
    return tuple(min(255, max(0, int(base[i] * (1 - shade) + dark[i] * shade) + noise - 16)) for i in range(3))


def render(color_at):
    rows = []
    for y in range(SIZE):
        row = bytearray(SIZE * 3)
        for x in range(SIZE):
            c = color_at(x, y)
            i = x * 3
            row[i], row[i + 1], row[i + 2] = c
        rows.append(row)
    return rows


def lighten(palette, amount=0.35):
    return tuple(tuple(int(c + (255 - c) * amount) for c in color) for color in palette)


def write(path, rows):
    with open(path, "wb") as f:
        f.write(png_bytes(SIZE, SIZE, rows))


def seed_of(key):
    return zlib.crc32(key.encode("utf-8")) & 0xFFFF


def make_species(species, tex_dir):
    count = 0
    for key, _, _ in species:
        seed = seed_of(key)
        for variant_key, palette in zip(VARIANT_KEYS, PALETTES):
            write(os.path.join(tex_dir, f"{key}_{variant_key}.png"),
                  render(lambda x, y, s=seed, p=palette: pattern_color(s, x, y, p)))
            count += 1
    return count


def make_babies(species, tex_dir):
    count = 0
    for key, _, _ in species:
        seed = seed_of(key)
        for variant_key, palette in zip(VARIANT_KEYS, PALETTES):
            light = lighten(palette)
            write(os.path.join(tex_dir, f"{key}_{variant_key}_cria.png"),
                  render(lambda x, y, s=seed, p=light: pattern_color(s, x, y, p)))
            count += 1
    return count


def make_hybrids(species, tex_dir):
    count = 0
    for ka, kb in compatible_pairs(species):
        seed_a, seed_b = seed_of(ka), seed_of(kb)
        for variant_key, palette in zip(VARIANT_KEYS, PALETTES):
            def color_at(x, y, sa=seed_a, sb=seed_b, p=palette):
                return pattern_color(sa, x, y, p) if x < SPLIT else pattern_color(sb, x, y, p)
            write(os.path.join(tex_dir, f"{ka}_x_{kb}_{variant_key}.png"), render(color_at))
            count += 1
    return count


def _unused_write_lang(species):
    lang_dir = os.path.join(OUT, "lang")
    os.makedirs(lang_dir, exist_ok=True)
    entries = {f"entity.monster_collector.{key}": name for key, name, _ in species}
    for locale in ("es_es", "en_us"):
        with open(os.path.join(lang_dir, f"{locale}.json"), "w", encoding="utf-8") as f:
            json.dump(entries, f, ensure_ascii=False, indent=2, sort_keys=True)
    return len(entries)


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else "all"
    if mode not in ("all", "species", "babies", "hybrids"):
        raise SystemExit("Uso: generate_assets.py [all|species|babies|hybrids]")
    species = read_species()
    tex_dir = os.path.join(OUT, "textures/entity")
    os.makedirs(tex_dir, exist_ok=True)
    if mode in ("all", "species"):
        print(f"Especies: {make_species(species, tex_dir)} texturas")
    if mode in ("all", "babies"):
        print(f"Crías: {make_babies(species, tex_dir)} texturas")
    if mode in ("all", "hybrids"):
        print(f"Híbridos: {make_hybrids(species, tex_dir)} texturas ({len(compatible_pairs(species))} pares)")


if __name__ == "__main__":
    main()
