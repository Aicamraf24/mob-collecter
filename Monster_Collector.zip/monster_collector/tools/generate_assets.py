#!/usr/bin/env python3
"""
Genera las texturas de las criaturas con estilo voxel, usando la posición real de cada pieza en el atlas
(tools/layouts.json, generado por LayoutDump.java).

Uso, desde la raíz del proyecto:
    python3 tools/generate_assets.py [all|species|babies|hybrids]

Cada cara se pinta según su orientación: arriba más claro, abajo más oscuro, la cara frontal de la cabeza
con ojos. Cada tipo de criatura tiene su propio patrón (escamas, rayas, manchas, cristal, vientre claro...).
Las cinco variantes comparten el patrón y cambian el color (tools/palette.py).

Por cada criatura se genera además la versión con silla de montar (sufijo _silla), con la silla pintada sobre el lomo.
"""
import json
import os
import re
import struct
import sys
import zlib

import palette

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TEX_DIR = os.path.join(ROOT, "src/main/resources/assets/monster_collector/textures/entity")
LAYOUTS = os.path.join(ROOT, "tools/layouts.json")
SIZE = 256

SCALES = {"tyrannosaurus_rex", "velociraptor", "triceratops", "stegosaurus", "brachiosaurus", "spinosaurus",
          "ankylosaurus", "carnotaurus", "parasaurolophus", "allosaurus", "giganotosaurus", "dilophosaurus",
          "compsognathus", "baryonyx", "ceratosaurus", "iguanodon", "apatosaurus", "argentinosaurus",
          "gallimimus", "oviraptor", "therizinosaurus", "rinoceronte_acorazado"}
STRIPES = {"pteranodon", "quetzalcoatlus", "dimorphodon", "grifo_salvaje", "fenix"}
BELLY = {"mosasaurus", "plesiosaurus", "ichthyosaurus", "megalodon", "tiburon_abisal", "raya_fantasma",
         "ballena_abisal", "leviatan_menor", "serpiente_marina", "anguila_marina"}
SPOTS = {"calamar_gigante", "pulpo_de_las_profundidades"}
GLOW = {"reina_de_las_profundidades", "dragon_de_cristal"}
CRYSTAL = {"golem_de_cristal"}
SEGMENTS = {"escorpion_colosal"}
FUR = {"lobo_de_sombras"}


def style_of(key):
    for group, style in ((SCALES, "scales"), (STRIPES, "stripes"), (BELLY, "belly"), (SPOTS, "spots"),
                         (GLOW, "glow"), (CRYSTAL, "crystal"), (SEGMENTS, "segments"), (FUR, "fur")):
        if key in group:
            return style
    return "scales"


def seed_of(key):
    return zlib.crc32(key.encode("utf-8")) & 0xFFFF


def hash8(x, y, seed):
    return ((x * 73856093) ^ (y * 19349663) ^ seed) & 0xFF


def pattern(style, x, y, w, h, seed):
    """Categoría de color de un píxel: 0 principal, 1 secundario, 2 sombra, 3 luz."""
    if style == "scales":
        cx, cy = x % 4, y % 4
        if cx == 0 or cy == 0:
            return 2
        if cx == 1 and cy == 1:
            return 3
        return 1 if hash8(x // 4, y // 4, seed) % 7 == 0 else 0
    if style == "stripes":
        if (x + y + seed) // 3 % 4 == 0:
            return 1
        return 3 if (x + seed) % 8 == 0 else 0
    if style == "belly":
        if y / h < 0.12:
            return 2
        return 1 if y / h > 0.55 else 0
    if style == "spots":
        cx, cy = x % 8 - 4, y % 8 - 4
        return 1 if cx * cx + cy * cy <= 3 else 0
    if style == "glow":
        if hash8(x, y, seed) % 11 == 0:
            return 3
        return 1 if (x - y) % 6 == 0 else 0
    if style == "crystal":
        facet = ((x + y) // 3 + (x - y) // 3 + seed) % 3
        return (3, 0, 2)[facet]
    if style == "segments":
        if y % 12 == 0:
            return 1
        return 2 if (y // 3) % 2 else 0
    if style == "fur":
        if hash8(x, y, seed) % 5 == 0:
            return 2
        return 1 if hash8(y, x, seed) % 9 == 0 else 0
    return 0


FACE_SHADE = {"top": 1.0, "front": 0.95, "right": 0.86, "left": 0.86, "back": 0.82, "bottom": 0.66}


def faces_of(u, v, w, h, d):
    """Regiones de cada cara en el atlas, según el desplegado estándar de un cubo de Minecraft."""
    return {
        "top": (u + d, v, w, d),
        "bottom": (u + d + w, v, w, d),
        "right": (u, v + d, d, h),
        "front": (u + d, v + d, w, h),
        "left": (u + d + w, v + d, d, h),
        "back": (u + 2 * d + w, v + d, w, h),
    }


def scale(color, factor):
    return tuple(max(0, min(255, int(c * factor))) for c in color)


class Canvas:
    def __init__(self, fill):
        self.px = bytearray(SIZE * SIZE * 3)
        for i in range(0, len(self.px), 3):
            self.px[i:i + 3] = bytes(fill)

    def put(self, x, y, color):
        if 0 <= x < SIZE and 0 <= y < SIZE:
            i = (y * SIZE + x) * 3
            self.px[i:i + 3] = bytes(color)

    def rows(self):
        return [self.px[y * SIZE * 3:(y + 1) * SIZE * 3] for y in range(SIZE)]


def draw_part(canvas, part, origin, saddle):
    palette_pair, style, seed = origin
    primary, secondary = palette_pair
    colors = (primary, secondary, scale(primary, 0.55), palette.lighten(primary, 0.3))
    u, v, w, h, d = part["u"], part["v"], part["w"], part["h"], part["d"]
    role = part["role"]
    regions = faces_of(u, v, w, h, d)
    for face, (fx, fy, fw, fh) in regions.items():
        shade = FACE_SHADE[face]
        for ly in range(fh):
            for lx in range(fw):
                cat = pattern(style, lx, ly, fw, fh, seed)
                c = scale(colors[cat], shade)
                if lx == 0 or ly == 0 or lx == fw - 1 or ly == fh - 1:
                    c = scale(c, 0.72)
                canvas.put(fx + lx, fy + ly, c)

    if role == "HEAD" and w >= 4 and h >= 4:
        fx, fy, fw, fh = regions["front"]
        eye = max(1, fw // 5)
        for ex in (int(fw * 0.3), int(fw * 0.7) - eye):
            ey = int(fh * 0.4)
            for dy in range(eye):
                for dx in range(eye):
                    canvas.put(fx + ex + dx, fy + ey + dy, (20, 15, 15))
            canvas.put(fx + ex, fy + ey, (240, 240, 240))
        for mx in range(int(fw * 0.3), int(fw * 0.7)):
            canvas.put(fx + mx, fy + int(fh * 0.8), scale(colors[2], 0.8))

    if saddle and role == "BODY":
        fx, fy, fw, fh = regions["top"]
        leather, dark_leather, stitch = (124, 76, 36), (92, 52, 22), (214, 180, 130)
        for ly in range(1, fh - 1):
            for lx in range(1, fw - 1):
                c = leather
                if ly == 2 or ly == fh - 3:
                    c = stitch if lx % 2 == 0 else dark_leather
                canvas.put(fx + lx, fy + ly, c)
        for side in ("right", "left"):
            sx, sy, sw, sh = regions[side]
            for ly in range(max(1, sh // 3)):
                for lx in range(sw):
                    canvas.put(sx + lx, sy + ly, dark_leather)


def paint(parts, origins, saddle):
    """origins: {"a": (paleta, estilo, semilla), "b": ...}. Las piezas con prefijo b_ usan el segundo padre."""
    background = scale(origins["a"][0][0], 0.3)
    canvas = Canvas(background)
    for part in parts:
        origin = origins["b"] if part["name"].startswith("b_") and "b" in origins else origins["a"]
        draw_part(canvas, part, origin, saddle)
    return canvas.rows()


def png_rgb(rows):
    raw = b"".join(b"\x00" + bytes(row) for row in rows)

    def chunk(tag, data):
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    header = struct.pack(">IIBBBBB", SIZE, SIZE, 8, 2, 0, 0, 0)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", header) + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")


def write(path, rows):
    with open(path, "wb") as f:
        f.write(png_rgb(rows))


def load_layouts():
    with open(LAYOUTS, encoding="utf-8") as f:
        return json.load(f)


def make_species(layouts, base, tex_dir, saddled):
    count = 0
    for key, parts in layouts["species"].items():
        for variant, pair in palette.variant_palettes(*base[key]).items():
            origins = {"a": (pair, style_of(key), seed_of(key))}
            name = f"{key}_{variant.lower()}"
            write(os.path.join(tex_dir, f"{name}.png"), paint(parts, origins, saddle=False))
            count += 1
            if saddled:
                write(os.path.join(tex_dir, f"{name}_silla.png"), paint(parts, origins, saddle=True))
                count += 1
    return count


def make_babies(layouts, base, tex_dir):
    count = 0
    for key, parts in layouts["species"].items():
        for variant, (primary, secondary) in palette.variant_palettes(*base[key]).items():
            light = (palette.lighten(primary), palette.lighten(secondary))
            origins = {"a": (light, style_of(key), seed_of(key))}
            write(os.path.join(tex_dir, f"{key}_{variant.lower()}_cria.png"), paint(parts, origins, saddle=False))
            count += 1
    return count


def make_hybrids(layouts, base, tex_dir):
    count = 0
    for key, parts in layouts["hybrids"].items():
        a, b = key.split("_x_")
        pal_a = palette.variant_palettes(*base[a])
        pal_b = palette.variant_palettes(*base[b])
        for variant in palette.VARIANTS:
            origins = {
                "a": (pal_a[variant], style_of(a), seed_of(a)),
                "b": (pal_b[variant], style_of(b), seed_of(b)),
            }
            name = f"{key}_{variant.lower()}"
            write(os.path.join(tex_dir, f"{name}.png"), paint(parts, origins, saddle=False))
            write(os.path.join(tex_dir, f"{name}_silla.png"), paint(parts, origins, saddle=True))
            count += 2
    return count


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else "all"
    if mode not in ("all", "species", "babies", "hybrids"):
        raise SystemExit("Uso: generate_assets.py [all|species|babies|hybrids]")
    layouts = load_layouts()
    base = palette.base_palettes()
    os.makedirs(TEX_DIR, exist_ok=True)
    if mode in ("all", "species"):
        print(f"Especies (con silla): {make_species(layouts, base, TEX_DIR, saddled=True)} texturas")
    if mode in ("all", "babies"):
        print(f"Crías: {make_babies(layouts, base, TEX_DIR)} texturas")
    if mode in ("all", "hybrids"):
        print(f"Híbridos (con silla): {make_hybrids(layouts, base, TEX_DIR)} texturas")


if __name__ == "__main__":
    main()
