#!/usr/bin/env python3
"""
Genera las texturas de Monster Collector con estilo voxel, a partir de la paleta del póster.

Uso, desde la raíz del proyecto:
    python3 tools/generate_assets.py [all|species|babies|hybrids]

- species: 44 especies x 5 variantes (220 texturas).
- babies:  versión infantil de cada variante, más clara (220 texturas).
- hybrids: un híbrido por cada par compatible y variante (335 texturas). La mitad izquierda usa el patrón
           y la paleta del primer padre, y la derecha la del segundo.

Cada especie tiene un patrón de bloques de 8x8 píxeles, como un voxel. Las cinco variantes comparten el patrón
y cambian solo el color (ver tools/palette.py).
"""
import os
import random
import struct
import sys
import re
import zlib

import palette

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SPECIES_JAVA = os.path.join(ROOT, "src/main/java/com/monstercollector/domain/Species.java")
BREEDING_JAVA = os.path.join(ROOT, "src/main/java/com/monstercollector/domain/Breeding.java")
TEX_DIR = os.path.join(ROOT, "src/main/resources/assets/monster_collector/textures/entity")
SIZE = 256
BLOCK = 8
CELLS = SIZE // BLOCK  # 32 bloques por lado
HALF = CELLS // 2


def read_species():
    pattern = re.compile(r'^\s+([A-Z0-9_]+)\("([^"]+)".*?Lineage\.(\w+)', re.M)
    with open(SPECIES_JAVA, encoding="utf-8") as f:
        text = f.read()
    return [(m.group(1).lower(), m.group(3)) for m in pattern.finditer(text)]


def compatible_pairs(species):
    with open(BREEDING_JAVA, encoding="utf-8") as f:
        extra = {frozenset((a.lower(), b.lower())) for a, b in
                 re.findall(r'Set\.of\(Species\.([A-Z0-9_]+), Species\.([A-Z0-9_]+)\)', f.read())}
    pairs = []
    for i, (ka, la) in enumerate(species):
        for kb, lb in species[i + 1:]:
            if la == lb or frozenset((ka, kb)) in extra:
                pairs.append((ka, kb))
    return pairs


def png_rgb(rows):
    raw = b"".join(b"\x00" + bytes(row) for row in rows)

    def chunk(tag, data):
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    header = struct.pack(">IIBBBBB", SIZE, SIZE, 8, 2, 0, 0, 0)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", header) + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")


def make_kinds(seed):
    """
    Categoría de color de cada bloque (0 principal, 1 secundario, 2 sombra, 3 luz) a partir de un ruido suave,
    para que las manchas sean grandes, como en la colección voxel, y no granulado.
    """
    rng = random.Random(seed)
    coarse = 8  # celdas de ruido de 4 bloques cada una
    grid = [[rng.random() for _ in range(coarse + 1)] for _ in range(coarse + 1)]
    kinds = []
    for by in range(CELLS):
        row = []
        for bx in range(CELLS):
            gx, gy = bx * coarse / CELLS, by * coarse / CELLS
            x0, y0 = int(gx), int(gy)
            fx, fy = gx - x0, gy - y0
            top = grid[y0][x0] * (1 - fx) + grid[y0][x0 + 1] * fx
            bottom = grid[y0 + 1][x0] * (1 - fx) + grid[y0 + 1][x0 + 1] * fx
            noise = top * (1 - fy) + bottom * fy
            if noise < 0.10:
                category = 2
            elif noise < 0.78:
                category = 0
            elif noise < 0.90:
                category = 1
            else:
                category = 3
            row.append((category, rng.randint(-4, 4)))
        kinds.append(row)
    return kinds


def four_colors(primary, secondary):
    dark = tuple(int(c * 0.55) for c in primary)
    light = palette.lighten(primary, 0.3)
    return (primary, secondary, dark, light)


def paint(kinds_a, colors_a, kinds_b=None, colors_b=None):
    """Pinta la textura. Si hay dos padres, la mitad izquierda usa el primero y la derecha el segundo."""
    if kinds_b is None:
        kinds_b, colors_b = kinds_a, colors_a
    rows = []
    cell_colors = []
    for by in range(CELLS):
        line = []
        for bx in range(CELLS):
            kinds, colors = (kinds_a, colors_a) if bx < HALF else (kinds_b, colors_b)
            category, jitter = kinds[by][bx]
            base = colors[category]
            line.append(tuple(max(0, min(255, c + jitter)) for c in base))
        cell_colors.append(line)
    for y in range(SIZE):
        by = y // BLOCK
        edge_row = y % BLOCK == 0
        row = bytearray(SIZE * 3)
        table = cell_colors[by]
        for x in range(SIZE):
            c = table[x // BLOCK]
            if edge_row or x % BLOCK == 0:
                c = (int(c[0] * 0.8), int(c[1] * 0.8), int(c[2] * 0.8))
            i = x * 3
            row[i], row[i + 1], row[i + 2] = c
        rows.append(row)
    return rows


def write(path, rows):
    with open(path, "wb") as f:
        f.write(png_rgb(rows))


def seed_of(key):
    return zlib.crc32(key.encode("utf-8")) & 0xFFFF


def make_species(species, base, tex_dir):
    count = 0
    for key, _ in species:
        kinds = make_kinds(seed_of(key))
        for variant, (primary, secondary) in palette.variant_palettes(*base[key]).items():
            write(os.path.join(tex_dir, f"{key}_{variant.lower()}.png"),
                  paint(kinds, four_colors(primary, secondary)))
            count += 1
    return count


def make_babies(species, base, tex_dir):
    count = 0
    for key, _ in species:
        kinds = make_kinds(seed_of(key))
        for variant, (primary, secondary) in palette.variant_palettes(*base[key]).items():
            light_p, light_s = palette.lighten(primary), palette.lighten(secondary)
            write(os.path.join(tex_dir, f"{key}_{variant.lower()}_cria.png"),
                  paint(kinds, four_colors(light_p, light_s)))
            count += 1
    return count


def make_hybrids(species, base, tex_dir):
    count = 0
    pairs = compatible_pairs(species)
    for ka, kb in pairs:
        kinds_a, kinds_b = make_kinds(seed_of(ka)), make_kinds(seed_of(kb))
        pal_a = palette.variant_palettes(*base[ka])
        pal_b = palette.variant_palettes(*base[kb])
        for variant in palette.VARIANTS:
            ca = four_colors(*pal_a[variant])
            cb = four_colors(*pal_b[variant])
            write(os.path.join(tex_dir, f"{ka}_x_{kb}_{variant.lower()}.png"),
                  paint(kinds_a, ca, kinds_b, cb))
            count += 1
    return count, len(pairs)


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else "all"
    if mode not in ("all", "species", "babies", "hybrids"):
        raise SystemExit("Uso: generate_assets.py [all|species|babies|hybrids]")
    species = read_species()
    base = palette.base_palettes()
    os.makedirs(TEX_DIR, exist_ok=True)
    if mode in ("all", "species"):
        print(f"Especies: {make_species(species, base, TEX_DIR)} texturas")
    if mode in ("all", "babies"):
        print(f"Crías: {make_babies(species, base, TEX_DIR)} texturas")
    if mode in ("all", "hybrids"):
        count, pairs = make_hybrids(species, base, TEX_DIR)
        print(f"Híbridos: {count} texturas ({pairs} pares)")


if __name__ == "__main__":
    main()
