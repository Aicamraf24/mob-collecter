#!/usr/bin/env python3
"""
Genera las texturas de las criaturas, diseñadas por especie.

Cada criatura tiene su textura base, con:
- los tonos de luz medidos en el póster (cara superior, lateral y sombra),
- un patrón propio del tipo de criatura (escamas, rayas, manchas, vientre claro, cristal...),
- detalles según la pieza: ojos, dientes o pico en la cabeza; membrana y nervios en las alas; púas en las placas;
  garras en las patas; anillos en la cola; radios en las aletas.

Las cinco variantes son recolores de esa misma base (ROJA, AZUL, VERDE, NEGRA, DORADA). La silla de montar se pinta
sobre la base (sufijo _silla). Si existe tools/pintadas/<clave>.png, esa textura sustituye a la base generada.

Uso, desde la raíz del proyecto:
    python3 tools/generate_assets.py [all|species|babies|hybrids]
"""
import json
import math
import os
import re
import struct
import sys
import zlib

import palette

try:
    from PIL import Image
except ImportError:  # sin PIL no se leen las texturas pintadas
    Image = None

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TEX_DIR = os.path.join(ROOT, "src/main/resources/assets/monster_collector/textures/entity")
LAYOUTS = os.path.join(ROOT, "tools/layouts.json")
SPECIES_JAVA = os.path.join(ROOT, "src/main/java/com/monstercollector/domain/Species.java")
PAINTED_DIR = os.path.join(ROOT, "tools/pintadas")
SIZE = 256

RAMPS = {
    "ROJA": ((70, 8, 8), (200, 38, 34), (255, 150, 120)),
    "AZUL": ((8, 22, 78), (40, 105, 215), (160, 210, 255)),
    "VERDE": ((14, 58, 20), (64, 160, 62), (200, 240, 150)),
    "NEGRA": ((4, 4, 6), (58, 58, 66), (170, 170, 178)),
    "DORADA": ((72, 40, 4), (205, 142, 30), (255, 242, 150)),
}

STYLE_GROUPS = [
    ({"tyrannosaurus_rex", "velociraptor", "triceratops", "stegosaurus", "brachiosaurus", "spinosaurus",
      "ankylosaurus", "carnotaurus", "parasaurolophus", "allosaurus", "giganotosaurus", "dilophosaurus",
      "compsognathus", "baryonyx", "ceratosaurus", "iguanodon", "apatosaurus", "argentinosaurus",
      "gallimimus", "oviraptor", "therizinosaurus", "rinoceronte_acorazado"}, "scales"),
    ({"pteranodon", "quetzalcoatlus", "dimorphodon", "grifo_salvaje", "fenix"}, "stripes"),
    ({"mosasaurus", "plesiosaurus", "ichthyosaurus", "megalodon", "tiburon_abisal", "raya_fantasma",
      "ballena_abisal", "leviatan_menor", "serpiente_marina", "anguila_marina"}, "belly"),
    ({"calamar_gigante", "pulpo_de_las_profundidades"}, "spots"),
    ({"reina_de_las_profundidades", "dragon_de_cristal"}, "glow"),
    ({"golem_de_cristal"}, "crystal"),
    ({"escorpion_colosal"}, "segments"),
    ({"lobo_de_sombras"}, "fur"),
]

FACE_ORDER = ("top", "bottom", "right", "front", "left", "back")


def style_of(key):
    for group, style in STYLE_GROUPS:
        if key in group:
            return style
    return "scales"


def read_species_info():
    """{clave: (dieta, movimiento)} leído de Species.java."""
    pattern = re.compile(r'^\s+([A-Z0-9_]+)\(.*?Movement\.(\w+), Lineage\.\w+, Habitat\.\w+, Diet\.(\w+)', re.M)
    with open(SPECIES_JAVA, encoding="utf-8") as f:
        return {m.group(1).lower(): (m.group(3), m.group(2)) for m in pattern.finditer(f.read())}


def seed_of(key):
    return zlib.crc32(key.encode("utf-8")) & 0xFFFF


def clamp01(x):
    return max(0.0, min(1.0, x))


def smooth(a, b, x):
    t = clamp01((x - a) / (b - a))
    return t * t * (3 - 2 * t)


def lerp(a, b, t):
    return tuple(a[i] + (b[i] - a[i]) * t for i in range(3))


def mul(c, f):
    return tuple(max(0.0, min(255.0, c[i] * f)) for i in range(3))


def hash8(x, y, seed):
    return ((x * 73856093) ^ (y * 19349663) ^ seed) & 0xFF


def faces_of(u, v, w, h, d):
    return {
        "top": (u + d, v, w, d),
        "bottom": (u + d + w, v, w, d),
        "right": (u, v + d, d, h),
        "front": (u + d, v + d, w, h),
        "left": (u + d + w, v + d, d, h),
        "back": (u + 2 * d + w, v + d, w, h),
    }


class Canvas:
    def __init__(self, fill=None, pixels=None):
        self.px = bytearray(pixels) if pixels is not None else bytearray(SIZE * SIZE * 3)
        if pixels is None:
            fill_bytes = bytes(int(c) for c in fill)
            for i in range(0, len(self.px), 3):
                self.px[i:i + 3] = fill_bytes

    def put(self, x, y, c):
        if 0 <= x < SIZE and 0 <= y < SIZE:
            i = (y * SIZE + x) * 3
            self.px[i] = int(max(0, min(255, c[0])))
            self.px[i + 1] = int(max(0, min(255, c[1])))
            self.px[i + 2] = int(max(0, min(255, c[2])))

    def copy(self):
        return Canvas(pixels=self.px)

    def rows(self):
        return [self.px[y * SIZE * 3:(y + 1) * SIZE * 3] for y in range(SIZE)]


def pattern_color(style, lx, ly, fw, fh, tone, accent, seed):
    """Patrón propio del tipo de criatura, en tonos suaves."""
    v = ly / max(1, fh - 1)
    col = lerp(tone, accent, smooth(0.6, 0.85, v) * 0.6)
    if style == "scales":
        if lx % 6 == 0 or ly % 6 == 0:
            col = mul(col, 0.9)
        cx, cy = lx % 6 - 3, ly % 6 - 3
        if cx * cx + cy * cy <= 1:
            col = mul(col, 1.06)
    elif style == "stripes":
        band = 0.5 + 0.5 * math.cos(2 * math.pi * (lx + ly) / 9.0)
        col = lerp(col, accent, band * 0.4)
    elif style == "belly":
        col = mul(col, 0.94 + 0.1 * smooth(0.0, 1.0, v))
    elif style == "spots":
        gx, gy = lx % 9 - 4.5, ly % 9 - 4.5
        dist = math.sqrt(gx * gx + gy * gy)
        col = lerp(col, accent, clamp01(1 - (dist - 2.2) / 1.2) * 0.8)
    elif style == "glow":
        t = 0.5 + 0.5 * math.sin(0.8 * lx + 0.6 * ly + seed % 10)
        col = lerp(col, lerp(tone, (255, 255, 255), 0.5), t * 0.3)
    elif style == "crystal":
        facet = ((lx + ly) % 8) / 8.0
        col = mul(col, 1.12 - 0.22 * facet)
    elif style == "segments":
        t = 0.5 + 0.5 * math.cos(2 * math.pi * ly / 6.0)
        col = mul(col, 0.92 + 0.1 * t)
    elif style == "fur":
        col = mul(col, 1.0 + (hash8(lx, ly, seed) % 7 - 3) / 100.0)
    return col


def draw_base(canvas, part, primary, accent, style, seed, tones):
    regions = faces_of(part["u"], part["v"], part["w"], part["h"], part["d"])
    face_tone = {"top": tones["top"], "bottom": tones["shadow"], "front": tones["side"],
                 "back": tones["side"], "left": tones["side"], "right": tones["side"]}
    for face, (fx, fy, fw, fh) in regions.items():
        tone = face_tone[face]
        for ly in range(fh):
            light = 1.03 - 0.06 * (ly / max(1, fh - 1))
            for lx in range(fw):
                col = pattern_color(style, lx, ly, fw, fh, tone, accent, seed)
                mottle = 1.0 + (hash8(lx + part["u"], ly + part["v"], seed) % 9 - 4) / 100.0
                col = mul(col, light * mottle)
                if lx == 0 or ly == 0 or lx == fw - 1 or ly == fh - 1:
                    col = mul(col, 0.92)
                canvas.put(fx + lx, fy + ly, col)
    return regions


def draw_head_front(canvas, region, diet, movement, primary, accent):
    fx, fy, fw, fh = region
    if fw < 4 or fh < 4:
        return
    eye = max(2, fw // 4)
    iris = mul(accent, 0.7)
    for ex in (int(fw * 0.26), int(fw * 0.74) - eye):
        ey = int(fh * 0.3)
        for dy in range(eye):
            for dx in range(eye):
                canvas.put(fx + ex + dx, fy + ey + dy, (238, 238, 232))
        cx, cy = ex + eye // 2, ey + eye // 2
        for dy in range(-1, eye - 1):
            for dx in range(-1, eye - 1):
                canvas.put(fx + cx + dx, fy + cy + dy, iris)
        canvas.put(fx + cx, fy + cy, (12, 12, 12))
    canvas.put(fx + fw // 2, fy + int(fh * 0.5), mul(primary, 0.4))
    if movement == "VOLADOR":
        for y in range(int(fh * 0.66), fh):
            for x in range(int(fw * 0.3), int(fw * 0.7)):
                canvas.put(fx + x, fy + y, mul(accent, 1.05))
    else:
        mouth_y = int(fh * 0.8)
        left, right = (int(fw * 0.22), int(fw * 0.78)) if diet == "CARNIVORO" else (int(fw * 0.32), int(fw * 0.68))
        for x in range(left, right):
            canvas.put(fx + x, fy + mouth_y, (30, 14, 14))
        if diet == "CARNIVORO" and mouth_y - 1 >= 0:
            for x in range(left, right, 2):
                canvas.put(fx + x, fy + mouth_y - 1, (245, 240, 230))


def draw_details(canvas, part, regions, primary, accent, diet, movement):
    role = part["role"]
    if role == "HEAD":
        draw_head_front(canvas, regions["front"], diet, movement, primary, accent)
    elif role == "BODY":
        fx, fy, fw, fh = regions["top"]
        for ly in range(fh):
            for lx in range(fw):
                if abs(lx - fw // 2) <= 1 and ly > 1:
                    canvas.put(fx + lx, fy + ly, mul(accent, 0.95))
    elif role in ("LEG", "ARM"):
        bx, by, bw, bh = regions["bottom"]
        for ly in range(bh):
            for lx in range(bw):
                canvas.put(bx + lx, by + ly, (32, 26, 26))
        fx, fy, fw, fh = regions["front"]
        for ly in range(max(1, fh - 2), fh):
            for lx in range(fw):
                canvas.put(fx + lx, fy + ly, mul(primary, 0.4))
    elif role == "WING":
        fx, fy, fw, fh = regions["top"]
        for ly in range(fh):
            for lx in range(fw):
                canvas.put(fx + lx, fy + ly, mul(primary, 1.05))
                if lx % max(2, fw // 5) == 0:
                    canvas.put(fx + lx, fy + ly, accent)
        ex, ey, ew, eh = regions["front"]
        for lx in range(ew):
            canvas.put(ex + lx, ey, mul(accent, 1.1))
    elif role == "FIN":
        fx, fy, fw, fh = regions["top"]
        for ly in range(fh):
            for lx in range(0, fw, 2):
                canvas.put(fx + lx, fy + ly, mul(primary, 0.78))
    elif role == "TAIL":
        for face in ("right", "left", "front", "back"):
            sx, sy, sw, sh = regions[face]
            for ly in range(sh):
                if (ly // 3) % 2 == 1:
                    for lx in range(sw):
                        canvas.put(sx + lx, sy + ly, mul(primary, 0.85))
        tx, ty, tw, th = regions["bottom"]
        for ly in range(th):
            for lx in range(tw):
                canvas.put(tx + lx, ty + ly, (40, 34, 34))
    elif role == "STATIC":
        for face in FACE_ORDER:
            fx, fy, fw, fh = regions[face]
            for ly in range(fh):
                for lx in range(fw):
                    edge = lx in (0, fw - 1) or ly in (0, fh - 1)
                    canvas.put(fx + lx, fy + ly, mul(accent, 0.7) if edge else accent)


def draw_saddle(canvas, part):
    if part["role"] != "BODY":
        return
    regions = faces_of(part["u"], part["v"], part["w"], part["h"], part["d"])
    fx, fy, fw, fh = regions["top"]
    leather, dark_leather, stitch = (124, 76, 36), (92, 52, 22), (214, 180, 130)
    for ly in range(1, fh - 1):
        for lx in range(1, fw - 1):
            c = leather
            if ly == 2 or ly == fh - 3:
                c = stitch if lx % 2 == 0 else dark_leather
            canvas.put(fx + lx, fy + ly, c)
    for side in ("right", "left"):
        sx, sy, sw, sh = regions[side]
        for ly in range(max(1, sh // 3)):
            for lx in range(sw):
                canvas.put(sx + lx, sy + ly, dark_leather)


def render_base(parts, origins):
    """origins: {"a": origen, "b": origen}. Cada origen: (primario, acento, estilo, semilla, tonos, (dieta, movimiento))."""
    pa = origins["a"]
    canvas = Canvas(fill=mul(pa[4]["shadow"], 0.8))
    for part in parts:
        o = origins["b"] if part["name"].startswith("b_") and "b" in origins else origins["a"]
        regions = draw_base(canvas, part, o[0], o[1], o[2], o[3], o[4])
        draw_details(canvas, part, regions, o[0], o[1], o[5][0], o[5][1])
    return canvas


def load_painted(name):
    path = os.path.join(PAINTED_DIR, name + ".png")
    if Image is None or not os.path.exists(path):
        return None
    im = Image.open(path).convert("RGB")
    if im.size != (SIZE, SIZE):
        raise SystemExit(f"{path} debe medir {SIZE} x {SIZE}")
    return Canvas(pixels=im.tobytes())


def gradient_map(canvas, ramp):
    dark, mid, light = ramp
    out = bytearray(len(canvas.px))
    for i in range(0, len(canvas.px), 3):
        r, g, b = canvas.px[i], canvas.px[i + 1], canvas.px[i + 2]
        lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255.0
        c = lerp(dark, mid, lum * 2) if lum < 0.5 else lerp(mid, light, (lum - 0.5) * 2)
        out[i], out[i + 1], out[i + 2] = int(c[0]), int(c[1]), int(c[2])
    return Canvas(pixels=out)


def lighten_canvas(canvas, amount=0.3):
    out = bytearray(len(canvas.px))
    for i in range(0, len(canvas.px), 3):
        for k in range(3):
            out[i + k] = int(canvas.px[i + k] + (255 - canvas.px[i + k]) * amount)
    return Canvas(pixels=out)


def png_rgb(rows):
    raw = b"".join(b"\x00" + bytes(row) for row in rows)

    def chunk(tag, data):
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    header = struct.pack(">IIBBBBB", SIZE, SIZE, 8, 2, 0, 0, 0)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", header) + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")


def write(path, canvas):
    with open(path, "wb") as f:
        f.write(png_rgb(canvas.rows()))


def write_variants(base_by_variant, parts, name, tex_dir):
    count = 0
    for variant, canvas in base_by_variant.items():
        write(os.path.join(tex_dir, f"{name}_{variant.lower()}.png"), canvas)
        count += 1
        sad = canvas.copy()
        for part in parts:
            draw_saddle(sad, part)
        write(os.path.join(tex_dir, f"{name}_{variant.lower()}_silla.png"), sad)
        count += 1
    return count


def variants_of(base_canvas, identity):
    return {v: (base_canvas if v == identity else gradient_map(base_canvas, RAMPS[v])) for v in palette.VARIANTS}


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else "all"
    if mode not in ("all", "species", "babies", "hybrids"):
        raise SystemExit("Uso: generate_assets.py [all|species|babies|hybrids]")
    with open(LAYOUTS, encoding="utf-8") as f:
        layouts = json.load(f)
    base = palette.base_palettes()
    tones = palette.base_tones()
    info = read_species_info()
    os.makedirs(TEX_DIR, exist_ok=True)

    def origin(key):
        primary, accent = base[key]
        return (primary, accent, style_of(key), seed_of(key), tones[key], info[key])

    if mode in ("all", "species"):
        count = 0
        for key, parts in layouts["species"].items():
            canvas = load_painted(key) or render_base(parts, {"a": origin(key)})
            identity = palette._identity_family(*base[key])
            count += write_variants(variants_of(canvas, identity), parts, key, TEX_DIR)
        print(f"Especies (con silla): {count} texturas")
    if mode in ("all", "babies"):
        count = 0
        for key, parts in layouts["species"].items():
            canvas = load_painted(key) or render_base(parts, {"a": origin(key)})
            identity = palette._identity_family(*base[key])
            for variant, variant_canvas in variants_of(canvas, identity).items():
                write(os.path.join(TEX_DIR, f"{key}_{variant.lower()}_cria.png"), lighten_canvas(variant_canvas))
                count += 1
        print(f"Crías: {count} texturas")
    if mode in ("all", "hybrids"):
        count = 0
        for key, parts in layouts["hybrids"].items():
            a, b = key.split("_x_")
            canvas = load_painted(key) or render_base(parts, {"a": origin(a), "b": origin(b)})
            identity = palette._identity_family(*base[a])
            count += write_variants(variants_of(canvas, identity), parts, key, TEX_DIR)
        print(f"Híbridos (con silla): {count} texturas")


if __name__ == "__main__":
    main()
