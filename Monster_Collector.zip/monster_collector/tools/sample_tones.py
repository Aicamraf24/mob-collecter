#!/usr/bin/env python3
"""
Mide, en cada celda de criatura del póster, el color principal y los tres tonos de iluminación
(cara superior, lateral y sombra). Uso: python3 tools/sample_tones.py ruta/al/poster.png
Escribe tools/poster_tones.json.
"""
import colorsys
import json
import os
import statistics
import sys
from collections import Counter

from PIL import Image

COLS = [(20, 168), (178, 326), (336, 484), (494, 642), (652, 800), (810, 958), (968, 1116), (1126, 1274), (1284, 1436)]
ROWS = [(225, 343), (353, 471), (479, 597), (607, 725)]
NAMES = [
    ["T-Rex", "Velociraptor", "Triceratops", "Stegosaurus", "Brachiosaurus", "Spinosaurus", "Ankylosaurus", "Parasaurolophus", "Pteranodon"],
    ["Quetzalcoatlus", "Dimorphodon", "Mosasaurus", "Plesiosaurus", "Ichthyosaurus", "Allosaurus", "Carnotaurus", "Giganotosaurus", "Dilophosaurus"],
    ["Compsognathus", "Baryonyx", "Ceratosaurus", "Iguanodon", "Apatosaurus", "Argentinosaurus", "Gallimimus", "Oviraptor", "Therizinosaurus"],
    ["Tiburón Abisal", "Calamar Gigante", "Pulpo de las Profundidades", "Anguila Marina", "Serpiente Marina", "Raya Fantasma", "Ballena Abisal", "Leviatán Menor", "Reina de las Profundidades"],
]


def dist(a, b):
    return sum((x - y) ** 2 for x, y in zip(a, b)) ** 0.5


def lum(c):
    return 0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2]


def main():
    poster_path = sys.argv[1]
    im = Image.open(poster_path).convert("RGB")
    W, H = im.size
    sx, sy = W / 1456.0, H / 819.0
    out = {}
    for ri, (y0, y1) in enumerate(ROWS):
        for ci, (x0, x1) in enumerate(COLS):
            name = NAMES[ri][ci]
            box = (int(x0 * sx) + 6, int(y0 * sy) + 6, int(x1 * sx) - 6, int((y0 + (y1 - y0) * 0.74) * sy))
            cell = im.crop(box)
            w, h = cell.size
            px = list(cell.getdata())
            border = [cell.getpixel((x, y)) for x in range(w) for y in (0, 1, h - 2, h - 1)]
            bg = tuple(int(statistics.median(c[i] for c in border)) for i in range(3))
            fg = [p for p in px if dist(p, bg) > 85] or [p for p in px if dist(p, bg) > 40] or px
            fg.sort(key=lum)
            n = len(fg)
            shadow = fg[: max(1, n // 6)]
            side = fg[n // 3: 2 * n // 3]
            top = fg[-max(1, n // 6):]
            mean = lambda pts: tuple(int(statistics.mean(p[i] for p in pts)) for i in range(3))
            counts = Counter((p[0] // 32, p[1] // 32, p[2] // 32) for p in side)
            key, _ = counts.most_common(1)[0]
            main_color = mean([p for p in side if (p[0] // 32, p[1] // 32, p[2] // 32) == key] or side)
            out[name] = {"primary": main_color, "top": mean(top), "side": mean(side), "shadow": mean(shadow)}
    dest = os.path.join(os.path.dirname(os.path.abspath(__file__)), "poster_tones.json")
    json.dump(out, open(dest, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    for name, t in out.items():
        print(f"{name:28s} top={t['top']} side={t['side']} shadow={t['shadow']}")


if __name__ == "__main__":
    main()
