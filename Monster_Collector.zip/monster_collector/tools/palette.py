"""
Paletas de color de Monster Collector.

- La paleta de cada especie sale del póster (tools/poster_palette.json, muestreado de las celdas de cada criatura).
- Las 8 especies que no aparecen en el póster tienen una paleta fija elegida a partir de las otras criaturas del póster.
- Cada especie tiene cinco variantes: ROJA, AZUL, VERDE, NEGRA y DORADA. Una de ellas es el color del póster
  (la familia de color más cercana) y las otras cuatro son recoloreados de esa misma criatura.
"""
import colorsys
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
VARIANTS = ["ROJA", "AZUL", "VERDE", "NEGRA", "DORADA"]  # mismo orden que ColorVariant
FAMILY_HUE = {"ROJA": 0 / 360, "AZUL": 215 / 360, "VERDE": 115 / 360, "DORADA": 42 / 360}

# Nombre del póster -> clave de la especie.
POSTER_KEYS = {
    "T-Rex": "tyrannosaurus_rex", "Velociraptor": "velociraptor", "Triceratops": "triceratops",
    "Stegosaurus": "stegosaurus", "Brachiosaurus": "brachiosaurus", "Spinosaurus": "spinosaurus",
    "Ankylosaurus": "ankylosaurus", "Parasaurolophus": "parasaurolophus", "Pteranodon": "pteranodon",
    "Quetzalcoatlus": "quetzalcoatlus", "Dimorphodon": "dimorphodon", "Mosasaurus": "mosasaurus",
    "Plesiosaurus": "plesiosaurus", "Ichthyosaurus": "ichthyosaurus", "Allosaurus": "allosaurus",
    "Carnotaurus": "carnotaurus", "Giganotosaurus": "giganotosaurus", "Dilophosaurus": "dilophosaurus",
    "Compsognathus": "compsognathus", "Baryonyx": "baryonyx", "Ceratosaurus": "ceratosaurus",
    "Iguanodon": "iguanodon", "Apatosaurus": "apatosaurus", "Argentinosaurus": "argentinosaurus",
    "Gallimimus": "gallimimus", "Oviraptor": "oviraptor", "Therizinosaurus": "therizinosaurus",
    "Tiburón Abisal": "tiburon_abisal", "Calamar Gigante": "calamar_gigante",
    "Pulpo de las Profundidades": "pulpo_de_las_profundidades", "Anguila Marina": "anguila_marina",
    "Serpiente Marina": "serpiente_marina", "Raya Fantasma": "raya_fantasma",
    "Ballena Abisal": "ballena_abisal", "Leviatán Menor": "leviatan_menor",
    "Reina de las Profundidades": "reina_de_las_profundidades",
}

# Especies que no están en el póster: colores tomados del resto de criaturas del póster y de la colección voxel.
MANUAL = {
    "dragon_de_cristal": ((170, 28, 52), (240, 120, 150)),   # dragón rojo cristalino del póster
    "grifo_salvaje": ((236, 236, 246), (222, 180, 70)),      # dragón blanco del póster, con detalles dorados
    "fenix": ((240, 150, 40), (255, 230, 120)),               # naranja y amarillo, como el ave del fondo
    "megalodon": ((70, 86, 108), (222, 228, 238)),            # tiburón gris azulado con vientre claro
    "golem_de_cristal": ((112, 114, 120), (70, 226, 236)),    # piedra gris con vetas cian de la colección voxel
    "escorpion_colosal": ((110, 52, 168), (176, 110, 226)),   # escorpión morado de la colección voxel
    "lobo_de_sombras": ((44, 44, 52), (124, 124, 136)),       # lobo negro con pelaje gris
    "rinoceronte_acorazado": ((124, 112, 102), (72, 64, 58)), # armadura gris parda
}


def _hsv(c):
    return colorsys.rgb_to_hsv(*(x / 255 for x in c))


def _rgb(h, s, v):
    r, g, b = colorsys.hsv_to_rgb(h, min(1, max(0, s)), min(1, max(0, v)))
    return (round(r * 255), round(g * 255), round(b * 255))


def _vivid(color, value_gain=1.0, sat_gain=1.0):
    """Más brillo y saturación, con el mismo tono. El muestreo del póster da colores ya sombreados."""
    h, s, v = _hsv(color)
    return _rgb(h, min(1.0, s * sat_gain), min(1.0, v * value_gain))


def base_palettes():
    """{clave: (primario, secundario)} de cada especie."""
    with open(os.path.join(HERE, "poster_palette.json"), encoding="utf-8") as f:
        poster = json.load(f)
    palettes = {}
    for name, colors in poster.items():
        palettes[POSTER_KEYS[name]] = (_vivid(tuple(colors["primary"])), _vivid(tuple(colors["secondary"])))
    palettes.update(MANUAL)
    return palettes


def _identity_family(primary, secondary):
    """Familia cromática más cercana al color principal (o al secundario si el principal es gris)."""
    for color in (primary, secondary):
        h, s, v = _hsv(color)
        if s >= 0.18:
            return min(FAMILY_HUE, key=lambda f: min(abs(FAMILY_HUE[f] - h), 1 - abs(FAMILY_HUE[f] - h)))
    return "ROJA"


def variant_palettes(primary, secondary):
    """{variante: (primario, secundario)} con las cinco variantes de una especie."""
    identity = _identity_family(primary, secondary)
    h, s, v = _hsv(primary)
    result = {}
    for variant in VARIANTS:
        if variant == identity:
            result[variant] = (primary, secondary)
        elif variant == "NEGRA":
            dark_primary = _rgb(h, s * 0.3, max(0.07, min(0.2, v * 0.3)))
            hs, ss, vs = _hsv(secondary)
            dark_secondary = _rgb(hs, ss * 0.25, min(0.65, max(0.35, vs * 0.9)))
            result[variant] = (dark_primary, dark_secondary)
        else:
            hue = FAMILY_HUE[variant]
            new_primary = _rgb(hue, max(s, 0.55), v)
            hs, ss, vs = _hsv(secondary)
            # El secundario gira hacia el nuevo tono, pero conserva parte del original para no perder la identidad.
            diff = ((hs - hue + 0.5) % 1.0) - 0.5
            new_secondary = _rgb(hue + diff * 0.45, max(ss * 0.9, 0.45), min(1.0, vs * 1.2 + 0.05))
            result[variant] = (new_primary, new_secondary)
    return result


def lighten(color, amount=0.35):
    return tuple(int(c + (255 - c) * amount) for c in color)
