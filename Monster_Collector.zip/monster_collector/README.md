# Monster Collector

Mod de Fabric para **Minecraft Java 26.1.2**. Incluye 44 criaturas coleccionables (25 de la especificación y 19 extras),
cinco variantes de color por especie, 67 híbridos, niveles, habilidades, crías, reproducción, domesticación,
enciclopedia y aparición natural. **No hay jefes.** Las capturas las hace el mod **Cápsulas**, que este mod no modifica.

## Requisitos

- Minecraft Java 26.1.2
- Fabric Loader 0.19.3 y Fabric API 0.150.0+26.1.2 (las mismas versiones que Cápsulas)
- Java 25 y Gradle compatible con Loom 1.15.2

## Compilar

```
gradle build
```

El `.jar` aparece en `build/libs/`.

## Qué incluye

**Criaturas**
- 44 especies con anatomía propia, animaciones de caminar, correr en ataque, descanso, vuelo (alas), natación (aletas) y cola.
- Texturas con estilo voxel y colores tomados del póster. Cada especie tiene cinco variantes con la misma
  probabilidad (20 %): roja, azul, verde, negra y dorada. Una de ellas es el color del póster y las otras cuatro
  son recoloreados de la misma criatura.
- 220 texturas de especie (44 × 5), 220 de crías y 335 de híbridos.
- Huevos de aparición de las 44 especies en la pestaña de huevos de aparición del creativo, con los colores de la criatura.
- Crías a escala 0.6 con la textura infantil. Crecen en 20 minutos y se aceleran al alimentarlas.

**Reproducción e híbridos**
- Dos criaturas en celo se cruzan si son compatibles. Hay un límite de 8 criaturas en 24 bloques para criar.
- Los híbridos son 67 tipos de entidad, con modelo combinado, textura mixta y habilidades heredadas.

**Combate, experiencia y domesticación**
- Habilidades ofensivas con tiempo de reutilización, a 3 bloques del objetivo.
- Experiencia por combate, por exploración (1 punto cada 40 bloques) y por alimentación (15 puntos). El nivel aparece encima de la criatura.
- Domesticación con 3 alimentos (trigo, carne cruda, bacalao o bayas dulces). Con la mano vacía cambias el comando: seguir, quieto o sentado.

**Aparición y datos**
- Aparición natural en los biomas de cada hábitat, con peso según la rareza.
- Tablas de botín por especie: huesos, cuero, plumas, conchas o gemas según la especie y su rareza.
- Receta de la enciclopedia: 8 papeles alrededor de un libro, en forma de cuadrado 3×3.

**Enciclopedia**
- Ítem «Enciclopedia de criaturas». Al usarlo se abre la pantalla.
- Lista de las 44 especies, marcadas según estén descubiertas. Ficha con rareza, vida, daño, velocidad, nivel máximo,
  hábitat, alimentación, comportamiento, parejas posibles, habilidades, ejemplares descubiertos y colores que faltan.
- Porcentaje de colección sobre las 220 combinaciones (44 especies × 5 variantes). Los híbridos no suman a ese porcentaje.
- Los descubrimientos se guardan con el jugador, sobreviven a la muerte y al reiniciar el mundo.
  Una criatura se registra una sola vez, cuando un jugador la tiene a 8 bloques.

**Idiomas**
- Español (es_es) e inglés (en_us) para nombres, enciclopedia y rarezas, hábitats, dietas, comportamientos y variantes.

## Límites de rendimiento

- Criaturas de Monster Collector en la categoría de criaturas de Minecraft, así que aplican los límites vanilla por zona.
- Criar requiere menos de 8 criaturas en 24 bloques.
- La IA de dueño y la experiencia por exploración se calculan cada medio segundo; el descubrimiento, cada segundo.
- No hay partículas propias: el celo y la alimentación usan las partículas de Minecraft.

## Compatibilidad con otros mods

- Todos los identificadores van en el espacio `monster_collector`, así no chocan con otros mods.
- Cápsulas: cada criatura se guarda con su variante, nivel, experiencia y estado de domesticación en el NBT.
  Cápsulas la captura y la libera sin cambios en su código.
- Este mod no añade dependencias obligatorias; Cápsulas se declara como `suggests`.
- No se ha probado la combinación con Acechador, Gancho, Reptilia, End Realms, Mundo Prehistórico, El Vacío Profundo,
  Abismo Oceánico ni Reino Micótico. Hay que probarla en el juego antes de usarla con ellos.

## Limitaciones conocidas

- Las habilidades defensivas se eligen en la lógica, pero no reducen el daño recibido todavía.
- Las habilidades de movimiento no se usan.
- Sentado es la cabeza baja, no una pose propia.
- La ficha de la enciclopedia no muestra la imagen del modelo.
- Las habilidades aparecen en español también en el idioma inglés.
- El daño de las habilidades usa `hurtServer`, y el registro de descubrimientos usa `getNearestPlayer`; ambos se confirmarán en la compilación.

## Regenerar los assets

```
python3 tools/generate_assets.py [all|species|babies|hybrids]
python3 tools/generate_data.py
```

- `tools/palette.py` define las paletas: los colores del póster (en `tools/poster_palette.json`), las ocho
  especies que no salen en el póster y las cinco variantes.
- `generate_assets.py` crea las texturas en estilo voxel.
- `generate_data.py` crea los idiomas, los huevos de aparición, el ítem de la enciclopedia, la receta y el botín.

Las ocho especies que no aparecen en el póster (Dragón de Cristal, Grifo Salvaje, Fénix, Megalodón, Gólem de Cristal,
Escorpión Colosal, Lobo de Sombras y Rinoceronte Acorazado) tienen colores elegidos a partir del resto del póster
y de la colección voxel. Si el diseño las pide distintas, se cambian en `MANUAL` dentro de `tools/palette.py`.

## Comprobaciones (sin Minecraft)

```
javac -encoding UTF-8 -d build/catalog-check $(find src/main/java/com/monstercollector/domain src/main/java/com/monstercollector/rig src/main/java/com/monstercollector/combat src/main/java/com/monstercollector/progression src/main/java/com/monstercollector/taming -name "*.java") src/test/java/com/monstercollector/CatalogCheck.java
java -cp build/catalog-check com.monstercollector.CatalogCheck
```

111 comprobaciones: catálogo, modelos, crías e híbridos, combate, experiencia, domesticación, descendencia,
enciclopedia guardada, límites, aparición, reproducción y niveles.

## Estructura

```
src/main/java/com/monstercollector/
  MonsterCollector.java        Entrada principal: valida el catálogo y registra entidades, ítems, adjuntos y aparición
  domain/                      Lógica pura: especies, variantes, rarezas, reproducción, descendencia, enciclopedia, límites
  rig/                         Anatomía de las 44 especies, crías e híbridos, y empaquetado de texturas
  combat/                      Tiempos de reutilización y elección de habilidades
  progression/                 Experiencia por combate, exploración y alimentación
  taming/                      Domesticación y comandos
  entity/                      CreatureEntity y registro de los tipos de entidad
  client/                      Modelo, renderizador, enciclopedia en pantalla
  attachment/                  Enciclopedia guardada con el jugador
  item/                        Ítem de la enciclopedia
  spawn/                       Aparición natural por bioma
src/main/resources/
  assets/monster_collector/    Texturas, idiomas, modelos del ítem
  data/monster_collector/      Receta y tablas de botín
```
