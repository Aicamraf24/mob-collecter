#!/usr/bin/env python3
"""
Genera las texturas de Monster Collector (44 especies x 5 variantes) y los archivos de idioma.

Uso, desde la raíz del proyecto:
    python3 tools/generate_assets.py

Las texturas son procedurales: cada especie tiene un patrón propio y cada variante, una paleta propia.
Los nombres se leen de Species.java, así que no hay que mantenerlos a mano en dos sitios.
"""
import json
import os
import re
import struct
import zlib

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SPECIES_JAVA = os.path.join(ROOT, "src/main/java/com/monstercollector/domain/Species.java")
OUT = os.path.join(ROOT, "src/main/resources/assets/monster_collector")
SIZE = 256  # mismo tamaño que Rig.ATLAS_SIZE

# Mismo orden que ColorVariant: ROJA, AZUL, VERDE, NEGRA, DORADA. Cada paleta: (base, acento, sombra).
PALETTES = [
    ((178, 38, 34), (255, 124, 56), (88, 18, 18)),
    ((36, 88, 186), (120, 206, 255), (16, 36, 98)),
    ((52, 148, 70), (168, 236, 112), (22, 78, 34)),
    ((40, 40, 46), (128, 118, 138), (8, 8, 12)),
    ((212, 160, 42), (255, 240, 130), (118, 78, 14)),
]
VARIANT_KEYS = ["roja", "azul", "verde", "negra", "dorada"]


def read_species():
    pattern = re.compile(r'^\s+([A-Z0-9_]+)\("([^"]+)"', re.M)
    with open(SPECIES_JAVA, encoding="utf-8") as f:
        text = f.read()
    found = [(m.group(1).lower(), m.group(2)) for m in pattern.finditer(text)]
    if len(found) < 25:
        raise SystemExit("No se han encontrado las especies en Species.java")
    return found


def png_bytes(width, height, rows):
    raw = b"".join(b"\x00" + bytes(row) for row in rows)

    def chunk(tag, data):
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    header = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)  # RGB, 8 bits
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", header) + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")


def paint(seed, palette):
    base, accent, dark = palette
    style = seed % 4
    ox = (seed >> 3) % 17
    oy = (seed >> 7) % 13
    rows = []
    for y in range(SIZE):
        row = bytearray(SIZE * 3)
        for x in range(SIZE):
            if style == 0:  # rayas diagonales
                band = ((x + y + ox) // 10) % 3
                c = dark if band == 0 else (base if band == 1 else accent)
            elif style == 1:  # manchas
                dx = (x + ox) % 32 - 16
                dy = (y + oy) % 32 - 16
                c = accent if dx * dx + dy * dy < 30 else base
            elif style == 2:  # escamas
                gx = (x + ox) % 16 - 8
                gy = (y + oy) % 12 - 6
                edge = gx * gx / 64.0 + gy * gy / 36.0
                c = accent if edge < 0.25 else (base if edge < 0.8 else dark)
            else:  # degradado con ruido
                shade = y / SIZE
                noise = ((x * 73856093) ^ (y * 19349663) ^ seed) & 0x1F
                c = tuple(min(255, max(0, int(base[i] * (1 - shade) + dark[i] * shade) + noise - 16)) for i in range(3))
            i = x * 3
            row[i], row[i + 1], row[i + 2] = c
        rows.append(row)
    return rows


def main():
    species = read_species()
    tex_dir = os.path.join(OUT, "textures/entity")
    os.makedirs(tex_dir, exist_ok=True)
    count = 0
    for key, _ in species:
        seed = zlib.crc32(key.encode("utf-8")) & 0xFFFF
        for variant_key, palette in zip(VARIANT_KEYS, PALETTES):
            path = os.path.join(tex_dir, f"{key}_{variant_key}.png")
            with open(path, "wb") as f:
                f.write(png_bytes(SIZE, SIZE, paint(seed, palette)))
            count += 1

    lang_dir = os.path.join(OUT, "lang")
    os.makedirs(lang_dir, exist_ok=True)
    entries = {f"entity.monster_collector.{key}": name for key, name in species}
    for locale in ("es_es", "en_us"):
        with open(os.path.join(lang_dir, f"{locale}.json"), "w", encoding="utf-8") as f:
            json.dump(entries, f, ensure_ascii=False, indent=2, sort_keys=True)
    print(f"Texturas: {count} ({len(species)} especies x {len(VARIANT_KEYS)} variantes)")
    print(f"Idiomas: {len(entries)} entradas en es_es y en_us")


if __name__ == "__main__":
    main()
