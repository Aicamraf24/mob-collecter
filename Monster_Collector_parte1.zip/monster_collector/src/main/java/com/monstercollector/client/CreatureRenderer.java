package com.monstercollector.client;

import com.monstercollector.MonsterCollector;
import com.monstercollector.domain.Movement;
import com.monstercollector.domain.Species;
import com.monstercollector.entity.CreatureEntity;
import com.monstercollector.rig.Rig;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

/** Renderiza una especie. Cada especie tiene su propia instancia con su modelo. */
public class CreatureRenderer extends MobRenderer<CreatureEntity, CreatureRenderState, CreatureModel> {

    private final Species species;

    public CreatureRenderer(EntityRendererProvider.Context context, Species species, Rig rig) {
        super(context,
                new CreatureModel(context.bakeLayer(CreatureClient.layerOf(species)), rig),
                (float) (rig.widthBlocks() * 0.4));
        this.species = species;
    }

    @Override
    public CreatureRenderState createRenderState() {
        return new CreatureRenderState();
    }

    @Override
    public void extractRenderState(CreatureEntity entity, CreatureRenderState state, float tickProgress) {
        super.extractRenderState(entity, state, tickProgress);
        state.speciesKey = species.key();
        state.variantIndex = entity.variantIndex();
        state.resting = entity.isResting();
        state.attacking = entity.isAttacking();
        state.flying = species.movement() == Movement.VOLADOR;
        state.swimming = species.movement() == Movement.ACUATICO;
    }

    @Override
    public Identifier getTextureLocation(CreatureRenderState state) {
        return Identifier.fromNamespaceAndPath(
                MonsterCollector.MOD_ID,
                "textures/entity/" + state.speciesKey + "_" + com.monstercollector.domain.ColorVariant.byIndex(state.variantIndex).key() + ".png");
    }
}
