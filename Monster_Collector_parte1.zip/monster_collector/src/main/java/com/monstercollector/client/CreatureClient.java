package com.monstercollector.client;

import com.monstercollector.MonsterCollector;
import com.monstercollector.domain.Species;
import com.monstercollector.entity.ModEntityTypes;
import com.monstercollector.rig.Rig;
import com.monstercollector.rig.Rigs;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.resources.Identifier;

/** Registro de modelos y renderizadores de las 44 especies en el cliente. */
public final class CreatureClient {

    private CreatureClient() {}

    public static ModelLayerLocation layerOf(Species species) {
        return new ModelLayerLocation(Identifier.fromNamespaceAndPath(MonsterCollector.MOD_ID, species.key()), "main");
    }

    public static void register() {
        for (Species s : Species.values()) {
            Rig rig = Rigs.of(s);
            ModelLayerRegistry.registerModelLayer(layerOf(s), () -> CreatureModel.createLayer(rig));
            EntityRendererRegistry.register(ModEntityTypes.typeOf(s), context -> new CreatureRenderer(context, s, rig));
        }
    }
}
