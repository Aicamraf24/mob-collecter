package com.monstercollector.client;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

/** Datos que el renderizador necesita del ejemplar en cada fotograma. */
public class CreatureRenderState extends LivingEntityRenderState {
    public String speciesKey = "";
    public int variantIndex;
    public boolean resting;
    public boolean attacking;
    public boolean flying;
    public boolean swimming;
}
