package com.monstercollector.domain;

import java.util.List;
import java.util.Locale;

/**
 * Las 25 especies obligatorias de la especificación. Cada una tiene rareza, linaje, hábitat,
 * estadísticas, habilidades y si puede domesticarse o es un jefe (los jefes nunca se reproducen).
 */
public enum Species implements Labeled {
    TYRANNOSAURUS_REX("Tyrannosaurus Rex", Rarity.EPIC, Movement.TERRESTRE, Lineage.TEROPODOS, Habitat.SELVA, Diet.CARNIVORO, Behavior.AGRESIVO, new BaseStats(90, 20, 0.22), false, false, Abilities.MORDIDA_DEVASTADORA),
    VELOCIRAPTOR("Velociraptor", Rarity.COMMON, Movement.TERRESTRE, Lineage.TEROPODOS, Habitat.SELVA, Diet.CARNIVORO, Behavior.AGRESIVO, new BaseStats(36, 7, 0.34), false, true, Abilities.ATAQUE_RAPIDO),
    TRICERATOPS("Triceratops", Rarity.COMMON, Movement.TERRESTRE, Lineage.ACORAZADOS, Habitat.LLANURA, Diet.HERBIVORO, Behavior.TERRITORIAL, new BaseStats(70, 9, 0.20), false, true, Abilities.EMBESTIDA),
    STEGOSAURUS("Stegosaurus", Rarity.COMMON, Movement.TERRESTRE, Lineage.ACORAZADOS, Habitat.LLANURA, Diet.HERBIVORO, Behavior.PASIVO, new BaseStats(60, 11, 0.19), false, true, Abilities.GOLPE_COLA),
    BRACHIOSAURUS("Brachiosaurus", Rarity.RARE, Movement.TERRESTRE, Lineage.SAUROPODOS, Habitat.SELVA, Diet.HERBIVORO, Behavior.PASIVO, new BaseStats(140, 6, 0.14), false, true, Abilities.PISOTON),
    SPINOSAURUS("Spinosaurus", Rarity.EPIC, Movement.TERRESTRE, Lineage.TEROPODOS, Habitat.AGUA_DULCE, Diet.CARNIVORO, Behavior.AGRESIVO, new BaseStats(110, 16, 0.24), false, false, Abilities.ATAQUE_ACUATICO),
    ANKYLOSAURUS("Ankylosaurus", Rarity.UNCOMMON, Movement.TERRESTRE, Lineage.ACORAZADOS, Habitat.LLANURA, Diet.HERBIVORO, Behavior.NEUTRAL, new BaseStats(75, 8, 0.15), false, true, Abilities.CAPARAZON),
    CARNOTAURUS("Carnotaurus", Rarity.UNCOMMON, Movement.TERRESTRE, Lineage.TEROPODOS, Habitat.LLANURA, Diet.CARNIVORO, Behavior.AGRESIVO, new BaseStats(58, 12, 0.30), false, true, Abilities.CARGA_RAPIDA),
    PTERANODON("Pteranodon", Rarity.UNCOMMON, Movement.VOLADOR, Lineage.VOLADORES_PREHISTORICOS, Habitat.MONTANA, Diet.PISCIVORO, Behavior.NEUTRAL, new BaseStats(34, 6, 0.30), false, true, Abilities.VUELO),
    QUETZALCOATLUS("Quetzalcoatlus", Rarity.RARE, Movement.VOLADOR, Lineage.VOLADORES_PREHISTORICOS, Habitat.MONTANA, Diet.CARNIVORO, Behavior.TERRITORIAL, new BaseStats(80, 10, 0.26), false, false, Abilities.VIENTO),
    DIMORPHODON("Dimorphodon", Rarity.UNCOMMON, Movement.VOLADOR, Lineage.VOLADORES_PREHISTORICOS, Habitat.MONTANA, Diet.CARNIVORO, Behavior.NOCTURNO, new BaseStats(28, 5, 0.36), false, true, Abilities.PICADO),
    DRAGON_DE_CRISTAL("Dragón de Cristal", Rarity.LEGENDARY, Movement.VOLADOR, Lineage.DRAGONIDOS, Habitat.ZONA_MINERAL, Diet.CARNIVORO, Behavior.TERRITORIAL, new BaseStats(300, 26, 0.30), true, false, Abilities.ENERGIA, Abilities.VUELO),
    GRIFO_SALVAJE("Grifo Salvaje", Rarity.EPIC, Movement.VOLADOR, Lineage.DRAGONIDOS, Habitat.MONTANA, Diet.CARNIVORO, Behavior.AGRESIVO, new BaseStats(120, 14, 0.30), false, true, Abilities.GARRA_AEREA),
    MEGALODON("Megalodón", Rarity.EPIC, Movement.ACUATICO, Lineage.MARINOS, Habitat.OCEANO, Diet.CARNIVORO, Behavior.AGRESIVO, new BaseStats(160, 24, 0.30), false, false, Abilities.MORDIDA_SUBMARINA),
    MOSASAURUS("Mosasaurus", Rarity.RARE, Movement.ACUATICO, Lineage.MARINOS_PREHISTORICOS, Habitat.OCEANO, Diet.CARNIVORO, Behavior.AGRESIVO, new BaseStats(130, 18, 0.28), false, false, Abilities.ATAQUE_ACUATICO_PODEROSO),
    PLESIOSAURUS("Plesiosaurus", Rarity.UNCOMMON, Movement.ACUATICO, Lineage.MARINOS_PREHISTORICOS, Habitat.OCEANO, Diet.CARNIVORO, Behavior.NEUTRAL, new BaseStats(90, 12, 0.26), false, false, Abilities.NADO_VELOZ),
    TIBURON_ABISAL("Tiburón Abisal", Rarity.RARE, Movement.ACUATICO, Lineage.MARINOS, Habitat.OCEANO, Diet.CARNIVORO, Behavior.AGRESIVO, new BaseStats(70, 13, 0.32), false, false, Abilities.MORDIDA_RAPIDA),
    CALAMAR_GIGANTE("Calamar Gigante", Rarity.COMMON, Movement.ACUATICO, Lineage.MARINOS, Habitat.OCEANO, Diet.CARNIVORO, Behavior.PASIVO, new BaseStats(65, 9, 0.20), false, false, Abilities.TINTA),
    SERPIENTE_MARINA("Serpiente Marina", Rarity.COMMON, Movement.ACUATICO, Lineage.MARINOS, Habitat.OCEANO, Diet.CARNIVORO, Behavior.NEUTRAL, new BaseStats(60, 10, 0.27), false, false, Abilities.CONSTRICCION),
    GOLEM_DE_CRISTAL("Gólem de Cristal", Rarity.EPIC, Movement.TERRESTRE, Lineage.MINERALES, Habitat.ZONA_MINERAL, Diet.MINERAL, Behavior.PASIVO, new BaseStats(180, 14, 0.12), false, false, Abilities.DEFENSA_CRISTALINA),
    ESCORPION_COLOSAL("Escorpión Colosal", Rarity.UNCOMMON, Movement.TERRESTRE, Lineage.ARTROPODOS, Habitat.ZONA_CALIDA, Diet.CARNIVORO, Behavior.TERRITORIAL, new BaseStats(70, 15, 0.22), false, false, Abilities.VENENO),
    LOBO_DE_SOMBRAS("Lobo de Sombras", Rarity.RARE, Movement.TERRESTRE, Lineage.LOBUNOS, Habitat.BOSQUE_OSCURO, Diet.CARNIVORO, Behavior.NOCTURNO, new BaseStats(55, 13, 0.32), false, true, Abilities.SOMBRA),
    RINOCERONTE_ACORAZADO("Rinoceronte Acorazado", Rarity.RARE, Movement.TERRESTRE, Lineage.ACORAZADOS, Habitat.LLANURA, Diet.HERBIVORO, Behavior.TERRITORIAL, new BaseStats(150, 15, 0.20), false, true, Abilities.CARGA_ACORAZADA),
    FENIX("Fénix", Rarity.LEGENDARY, Movement.VOLADOR, Lineage.DRAGONIDOS, Habitat.ZONA_CALIDA, Diet.OMNIVORO, Behavior.NEUTRAL, new BaseStats(200, 20, 0.30), false, true, Abilities.FUEGO),
    LEVIATAN_MENOR("Leviatán Menor", Rarity.LEGENDARY, Movement.ACUATICO, Lineage.MARINOS, Habitat.OCEANO, Diet.CARNIVORO, Behavior.AGRESIVO, new BaseStats(350, 22, 0.25), true, false, Abilities.OLEAJE);

    private final String displayName;
    private final Rarity rarity;
    private final Movement movement;
    private final Lineage lineage;
    private final Habitat habitat;
    private final Diet diet;
    private final Behavior behavior;
    private final BaseStats baseStats;
    private final boolean boss;
    private final boolean domesticable;
    private final List<Ability> abilities;

    Species(String displayName, Rarity rarity, Movement movement, Lineage lineage, Habitat habitat,
            Diet diet, Behavior behavior, BaseStats baseStats, boolean boss, boolean domesticable,
            Ability... abilities) {
        this.displayName = displayName;
        this.rarity = rarity;
        this.movement = movement;
        this.lineage = lineage;
        this.habitat = habitat;
        this.diet = diet;
        this.behavior = behavior;
        this.baseStats = baseStats;
        this.boss = boss;
        this.domesticable = domesticable;
        this.abilities = List.of(abilities);
    }

    /** Clave estable para registros, JSON y enciclopedia (p. ej. "tyrannosaurus_rex"). */
    public String key() {
        return name().toLowerCase(Locale.ROOT);
    }

    @Override
    public String displayName() {
        return displayName;
    }

    public Rarity rarity() { return rarity; }
    public Movement movement() { return movement; }
    public Lineage lineage() { return lineage; }
    public Habitat habitat() { return habitat; }
    public Diet diet() { return diet; }
    public Behavior behavior() { return behavior; }
    public BaseStats baseStats() { return baseStats; }
    public boolean isBoss() { return boss; }
    public boolean isDomesticable() { return domesticable; }
    public List<Ability> abilities() { return abilities; }
}
