package com.monstercollector.domain;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

/**
 * Reglas de reproducción. Dos especies pueden reproducirse si comparten linaje o si forman un par explícito.
 * Los jefes nunca se reproducen. Una misma especie sí puede reproducirse consigo misma (no jefes).
 */
public final class Breeding {

    /** Tiempo de espera entre crías de un mismo ejemplar: 5 minutos (6000 ticks). */
    public static final long BREED_COOLDOWN_TICKS = 6_000L;

    private static final Set<Set<Species>> EXTRA_PAIRS = Set.of(
            Set.of(Species.LOBO_DE_SOMBRAS, Species.VELOCIRAPTOR),
            Set.of(Species.GRIFO_SALVAJE, Species.PTERANODON),
            Set.of(Species.GOLEM_DE_CRISTAL, Species.RINOCERONTE_ACORAZADO),
            Set.of(Species.ESCORPION_COLOSAL, Species.ANKYLOSAURUS));

    private Breeding() {}

    public static boolean canBreed(Species a, Species b) {
        if (a.isBoss() || b.isBoss()) return false;
        if (a == b) return true;
        if (a.lineage() == b.lineage()) return true;
        return EXTRA_PAIRS.contains(Set.of(a, b));
    }

    public static List<Species> matesOf(Species species) {
        return Arrays.stream(Species.values())
                .filter(other -> canBreed(species, other))
                .toList();
    }

    /** Un ejemplar puede criar si ya es adulto y ha cumplido su espera. */
    public static boolean readyToBreed(Growth growth, long cooldownTicksLeft) {
        return growth.isAdult() && cooldownTicksLeft <= 0L;
    }
}
