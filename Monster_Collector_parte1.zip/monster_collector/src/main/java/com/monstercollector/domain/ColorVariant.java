package com.monstercollector.domain;

import java.util.random.RandomGenerator;

/**
 * Las cinco variantes de color de cada especie. Todas tienen exactamente la misma probabilidad (20 %)
 * y no dependen de la rareza. Cada especie tiene su propia textura para cada variante.
 */
public enum ColorVariant implements Labeled {
    ROJA("Roja"),
    AZUL("Azul"),
    VERDE("Verde"),
    NEGRA("Negra"),
    DORADA("Dorada");

    public static final int COUNT = 5;

    private final String displayName;

    ColorVariant(String displayName) {
        this.displayName = displayName;
    }

    @Override
    public String displayName() {
        return displayName;
    }

    /** Probabilidad de cada variante: 1/5 = 20 %. */
    public double probability() {
        return 1.0 / COUNT;
    }

    /** Elige una variante con probabilidad uniforme. */
    public static ColorVariant random(RandomGenerator rng) {
        return values()[rng.nextInt(COUNT)];
    }
}
