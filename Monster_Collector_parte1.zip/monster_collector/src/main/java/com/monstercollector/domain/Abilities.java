package com.monstercollector.domain;

import com.monstercollector.domain.Ability.Kind;

import java.util.List;

/** Catálogo de habilidades. Cada especie usa una o dos de estas. */
public final class Abilities {
    private Abilities() {}

    public static final Ability MORDIDA_DEVASTADORA = new Ability("mordida_devastadora", "Mordida devastadora", Kind.OFENSIVA, 8, 2.0);
    public static final Ability ATAQUE_RAPIDO = new Ability("ataque_rapido", "Ataque rápido", Kind.OFENSIVA, 3, 1.1);
    public static final Ability EMBESTIDA = new Ability("embestida", "Embestida", Kind.OFENSIVA, 10, 1.8);
    public static final Ability GOLPE_COLA = new Ability("golpe_cola", "Golpe con la cola", Kind.OFENSIVA, 6, 1.5);
    public static final Ability PISOTON = new Ability("pisoton", "Pisotón", Kind.OFENSIVA, 12, 1.4);
    public static final Ability ATAQUE_ACUATICO = new Ability("ataque_acuatico", "Ataque acuático", Kind.OFENSIVA, 7, 1.6);
    public static final Ability CAPARAZON = new Ability("caparazon", "Caparazón", Kind.DEFENSIVA, 12, 0.5);
    public static final Ability CARGA_RAPIDA = new Ability("carga_rapida", "Carga rápida", Kind.OFENSIVA, 7, 1.3);
    public static final Ability VUELO = new Ability("vuelo", "Vuelo", Kind.MOVIMIENTO, 15, 1.0);
    public static final Ability VIENTO = new Ability("rafaga_viento", "Ráfaga de viento", Kind.OFENSIVA, 10, 1.3);
    public static final Ability PICADO = new Ability("picado", "Picado", Kind.OFENSIVA, 5, 1.2);
    public static final Ability ENERGIA = new Ability("proyectiles_energia", "Proyectiles de energía", Kind.OFENSIVA, 4, 1.5);
    public static final Ability GARRA_AEREA = new Ability("garra_aerea", "Garra aérea", Kind.OFENSIVA, 6, 1.4);
    public static final Ability MORDIDA_SUBMARINA = new Ability("mordida_submarina", "Mordida submarina", Kind.OFENSIVA, 8, 2.0);
    public static final Ability ATAQUE_ACUATICO_PODEROSO = new Ability("ataque_acuatico_poderoso", "Ataque acuático poderoso", Kind.OFENSIVA, 7, 1.7);
    public static final Ability NADO_VELOZ = new Ability("nado_veloz", "Nado veloz", Kind.MOVIMIENTO, 10, 1.2);
    public static final Ability MORDIDA_RAPIDA = new Ability("mordida_rapida", "Mordida rápida", Kind.OFENSIVA, 4, 1.2);
    public static final Ability TINTA = new Ability("nube_tinta", "Nube de tinta", Kind.DEFENSIVA, 12, 0.6);
    public static final Ability CONSTRICCION = new Ability("constriccion", "Constricción", Kind.OFENSIVA, 6, 1.3);
    public static final Ability DEFENSA_CRISTALINA = new Ability("defensa_cristalina", "Defensa cristalina", Kind.DEFENSIVA, 14, 0.5);
    public static final Ability VENENO = new Ability("aguijon_venenoso", "Aguijón venenoso", Kind.OFENSIVA, 9, 1.3);
    public static final Ability SOMBRA = new Ability("mordida_de_sombra", "Mordida de sombra", Kind.OFENSIVA, 6, 1.4);
    public static final Ability CARGA_ACORAZADA = new Ability("carga_acorazada", "Carga acorazada", Kind.OFENSIVA, 9, 1.6);
    public static final Ability FUEGO = new Ability("ataque_de_fuego", "Ataque de fuego", Kind.OFENSIVA, 8, 1.6);
    public static final Ability OLEAJE = new Ability("oleaje", "Oleaje", Kind.OFENSIVA, 10, 1.5);

    public static final List<Ability> ALL = List.of(
            MORDIDA_DEVASTADORA, ATAQUE_RAPIDO, EMBESTIDA, GOLPE_COLA, PISOTON, ATAQUE_ACUATICO,
            CAPARAZON, CARGA_RAPIDA, VUELO, VIENTO, PICADO, ENERGIA, GARRA_AEREA, MORDIDA_SUBMARINA,
            ATAQUE_ACUATICO_PODEROSO, NADO_VELOZ, MORDIDA_RAPIDA, TINTA, CONSTRICCION,
            DEFENSA_CRISTALINA, VENENO, SOMBRA, CARGA_ACORAZADA, FUEGO, OLEAJE);
}
