package com.monstercollector.domain;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * Registro de descubrimientos del jugador. El porcentaje de colección cuenta solo las 125 combinaciones
 * base (especie × variante). Los híbridos se registran aparte y no entran en ese porcentaje.
 */
public final class Encyclopedia {

    private final Map<Species, EnumMap<ColorVariant, Integer>> copies = new EnumMap<>(Species.class);
    private final Map<String, Integer> hybridCopies = new TreeMap<>();

    public void recordSpecimen(Species species, ColorVariant variant) {
        copies.computeIfAbsent(species, s -> new EnumMap<>(ColorVariant.class))
                .merge(variant, 1, Integer::sum);
    }

    public void recordHybrid(Hybrid hybrid) {
        hybridCopies.merge(hybrid.key(), 1, Integer::sum);
    }

    public int copies(Species species, ColorVariant variant) {
        EnumMap<ColorVariant, Integer> byVariant = copies.get(species);
        return byVariant == null ? 0 : byVariant.getOrDefault(variant, 0);
    }

    public boolean isDiscovered(Species species, ColorVariant variant) {
        return copies(species, variant) > 0;
    }

    public int discoveredCombinations() {
        int count = 0;
        for (Species s : Species.values()) {
            for (ColorVariant v : ColorVariant.values()) {
                if (isDiscovered(s, v)) count++;
            }
        }
        return count;
    }

    public static int totalCombinations() {
        return Species.values().length * ColorVariant.COUNT;
    }

    public double completionPercent() {
        return 100.0 * discoveredCombinations() / totalCombinations();
    }

    /** Especies de las que todavía no se ha encontrado ninguna variante. */
    public List<Species> missingSpecies() {
        List<Species> missing = new ArrayList<>();
        for (Species s : Species.values()) {
            if (missingVariants(s).size() == ColorVariant.COUNT) {
                missing.add(s);
            }
        }
        return missing;
    }

    /** Variantes de color que aún no se han encontrado para una especie. */
    public Set<ColorVariant> missingVariants(Species species) {
        EnumSet<ColorVariant> missing = EnumSet.allOf(ColorVariant.class);
        for (ColorVariant v : ColorVariant.values()) {
            if (isDiscovered(species, v)) missing.remove(v);
        }
        return missing;
    }

    public Set<String> discoveredHybridKeys() {
        return Collections.unmodifiableSet(hybridCopies.keySet());
    }

    public int hybridsDiscovered() {
        return hybridCopies.size();
    }
}
