package com.monstercollector.domain;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Comprobaciones de coherencia del catálogo. Se ejecutan al arrancar el mod. */
public final class Catalog {

    public static final int MIN_SPECIES = 25;

    private Catalog() {}

    /** Lista de errores. Vacía significa que el catálogo es válido. */
    public static List<String> validate() {
        List<String> errors = new ArrayList<>();

        if (Species.values().length < MIN_SPECIES) {
            errors.add("Hay " + Species.values().length + " especies; el mínimo es " + MIN_SPECIES);
        }
        if (ColorVariant.values().length != ColorVariant.COUNT) {
            errors.add("Se requieren exactamente " + ColorVariant.COUNT + " variantes de color");
        }

        double sum = 0.0;
        for (ColorVariant v : ColorVariant.values()) {
            sum += v.probability();
        }
        if (Math.abs(sum - 1.0) > 1e-9) {
            errors.add("Las probabilidades de las variantes suman " + sum + " en lugar de 1");
        }

        Set<String> names = new HashSet<>();
        for (Species s : Species.values()) {
            if (!names.add(s.displayName())) {
                errors.add("Nombre duplicado: " + s.displayName());
            }
            BaseStats st = s.baseStats();
            if (st.maxHealth() < 10 || st.maxHealth() > 1000) {
                errors.add(s.displayName() + ": vida base fuera de rango");
            }
            if (st.attackDamage() < 1 || st.attackDamage() > 100) {
                errors.add(s.displayName() + ": daño base fuera de rango");
            }
            if (st.movementSpeed() < 0.05 || st.movementSpeed() > 0.5) {
                errors.add(s.displayName() + ": velocidad base fuera de rango");
            }
            if (s.abilities().isEmpty()) {
                errors.add(s.displayName() + ": sin habilidades");
            }
            for (Ability ability : s.abilities()) {
                if (!Abilities.ALL.contains(ability)) {
                    errors.add(s.displayName() + ": habilidad no registrada en Abilities");
                }
            }
            if (s.isBoss() && !Breeding.matesOf(s).isEmpty()) {
                errors.add(s.displayName() + ": un jefe no puede tener parejas");
            }
        }

        Set<String> abilityIds = new HashSet<>();
        for (Ability ability : Abilities.ALL) {
            if (!abilityIds.add(ability.id())) {
                errors.add("Id de habilidad duplicado: " + ability.id());
            }
        }

        for (Species a : Species.values()) {
            for (Species b : Species.values()) {
                if (Breeding.canBreed(a, b) != Breeding.canBreed(b, a)) {
                    errors.add("Compatibilidad no simétrica: " + a + " / " + b);
                }
            }
        }

        return errors;
    }

    public static void requireValid() {
        List<String> errors = validate();
        if (!errors.isEmpty()) {
            throw new IllegalStateException("Catálogo de Monster Collector inválido: " + String.join("; ", errors));
        }
    }
}
