package com.monstercollector.entity;

import com.monstercollector.combat.AbilityChooser;
import com.monstercollector.combat.Cooldowns;
import com.monstercollector.domain.Ability;
import com.monstercollector.domain.Behavior;
import com.monstercollector.domain.BaseStats;
import com.monstercollector.domain.ColorVariant;
import com.monstercollector.domain.CreatureProfile;
import com.monstercollector.domain.Growth;
import com.monstercollector.domain.Hybrid;
import com.monstercollector.domain.Leveling;
import com.monstercollector.domain.Movement;
import com.monstercollector.domain.Offspring;
import com.monstercollector.domain.Species;
import com.monstercollector.progression.ExperienceRules;
import com.monstercollector.rig.Rig;
import com.monstercollector.rig.Rigs;
import com.monstercollector.taming.Domestication;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.BreedGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.WaterBoundPathNavigation;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.Vec3;

import java.util.List;
import java.util.Random;
import java.util.UUID;

/**
 * Criatura de Monster Collector: una clase para las 44 especies y para los híbridos.
 * Extiende {@link Animal} para tener reproducción, crías y alimentación de forma nativa.
 * Guarda variante, nivel, experiencia y estado de domesticación en el NBT, así Cápsulas
 * la captura y la libera sin perder nada.
 */
public class CreatureEntity extends Animal {

    private static final EntityDataAccessor<Integer> DATA_VARIANT =
            SynchedEntityData.defineId(CreatureEntity.class, EntityDataSerializers.INT);

    private static final String NBT_VARIANT = "mc_variant";
    private static final String NBT_LEVEL = "mc_level";
    private static final String NBT_XP = "mc_xp";
    private static final String NBT_FOOD = "mc_food";
    private static final String NBT_MODE = "mc_mode";
    private static final String NBT_OWNER = "mc_owner";
    private static final String NBT_PENDING = "mc_pending_blocks";

    /** Distancia a la que el ejemplar domesticado sigue a su dueño: 6 bloques. */
    private static final double FOLLOW_DISTANCE_SQ = 36.0;
    /** Distancia de ataque cuerpo a cuerpo para usar habilidades: 3 bloques. */
    private static final double STRIKE_RANGE_SQ = 9.0;
    /** Ticks que dura el efecto visible de una habilidad. */
    private static final int ACTION_BAR_TICKS = 40;

    private final Species species;
    private final Species secondary;
    private final List<Ability> abilities;
    private final Cooldowns cooldowns = new Cooldowns();
    private final Domestication domestication;
    private boolean variantAssigned;
    private int creatureLevel = 1;
    private long creatureXp;
    private UUID ownerUuid;
    private Random abilityRandom;
    private LivingEntity lastTarget;
    private double pendingBlocks;
    private Vec3 lastPosition;
    private int shownLevel = -1;

    public CreatureEntity(EntityType<? extends CreatureEntity> type, Level level, Species species) {
        this(type, level, species, null);
    }

    public CreatureEntity(EntityType<? extends CreatureEntity> type, Level level, Species species, Species secondary) {
        super(type, level);
        this.species = species;
        this.secondary = secondary;
        this.abilities = secondary == null ? species.abilities() : hybridAbilities(species, secondary);
        boolean domesticable = species.isDomesticable() && (secondary == null || secondary.isDomesticable());
        this.domestication = new Domestication(domesticable, canSitOn(species));

        if (species.movement() == Movement.VOLADOR) {
            this.moveControl = new FlyingMoveControl(this, 10, true);
            this.navigation = new FlyingPathNavigation(this, level);
            this.setNoGravity(true);
        } else if (species.movement() == Movement.ACUATICO) {
            this.navigation = new WaterBoundPathNavigation(this, level);
        }
    }

    /** Atributos por defecto: vida, daño y velocidad. Para híbridos se pasan las estadísticas heredadas. */
    public static AttributeSupplier.Builder createAttributes(BaseStats st) {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, st.maxHealth())
                .add(Attributes.ATTACK_DAMAGE, st.attackDamage())
                .add(Attributes.MOVEMENT_SPEED, st.movementSpeed());
    }

    public Species species() {
        return species;
    }

    public Species secondary() {
        return secondary;
    }

    public boolean isHybrid() {
        return secondary != null;
    }

    public int variantIndex() {
        return this.entityData.get(DATA_VARIANT);
    }

    public ColorVariant variant() {
        return ColorVariant.byIndex(variantIndex());
    }

    public int creatureLevel() {
        return creatureLevel;
    }

    public Domestication domestication() {
        return domestication;
    }

    /** Parado o casi parado: la cabeza baja en la animación de descanso. */
    public boolean isResting() {
        Vec3 v = this.getDeltaMovement();
        return v.x * v.x + v.z * v.z < 1.0E-4;
    }

    public boolean isAttacking() {
        return this.getTarget() != null;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_VARIANT, 0);
    }

    /**
     * Se llama desde el constructor de Mob, antes de que los campos de esta clase estén asignados,
     * así que la especie se consulta por el tipo de entidad.
     */
    @Override
    protected void registerGoals() {
        Species s = ModEntityTypes.speciesOf(this.getType());
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new BreedGoal(this, 1.0));
        if (s != null && s.behavior() == Behavior.AGRESIVO) {
            this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0, false));
            this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, true));
        }
        this.targetSelector.addGoal(2, new HurtByTargetGoal(this));
        this.goalSelector.addGoal(3, new RandomStrollGoal(this, 1.0));
        this.goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 6.0f));
        this.goalSelector.addGoal(5, new RandomLookAroundGoal(this));
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide()) {
            return;
        }
        if (!variantAssigned) {
            this.entityData.set(DATA_VARIANT, this.random.nextInt(ColorVariant.COUNT));
            variantAssigned = true;
        }
        updateExploration();
        updateCombat();
        updateOwnerBehavior();
        updateNameTag();
    }

    /** Experiencia por recorrer terreno: 1 punto cada 40 bloques. */
    private void updateExploration() {
        Vec3 now = this.position();
        if (lastPosition != null && this.onGround()) {
            double dx = now.x - lastPosition.x;
            double dz = now.z - lastPosition.z;
            pendingBlocks += Math.sqrt(dx * dx + dz * dz);
        }
        lastPosition = now;
        long xp = ExperienceRules.explorationXp(pendingBlocks);
        if (xp > 0) {
            pendingBlocks -= xp * ExperienceRules.BLOCKS_PER_XP;
            gainXp(xp);
        }
    }

    /** Usa habilidades ofensivas cuando tiene objetivo a distancia de ataque, y da experiencia al abatirlo. */
    private void updateCombat() {
        LivingEntity target = this.getTarget();
        if (target != null) {
            lastTarget = target;
            if (target.isAlive() && level() instanceof ServerLevel serverLevel && distanceToSqr(target) <= STRIKE_RANGE_SQ) {
                long now = serverLevel.getGameTime();
                AbilityChooser.choose(abilities, cooldowns, now, true, 1.0, rng())
                        .ifPresent(ability -> strike(serverLevel, ability, target, now));
            }
        } else if (lastTarget != null) {
            if (lastTarget.isDeadOrDying()) {
                gainXp(ExperienceRules.combatXp(lastTarget.getMaxHealth()));
            }
            lastTarget = null;
        }
    }

    private void strike(ServerLevel serverLevel, Ability ability, LivingEntity target, long now) {
        float damage = (float) AbilityChooser.damageDealt(ability, this.getAttributeValue(Attributes.ATTACK_DAMAGE));
        target.hurtServer(serverLevel, serverLevel.damageSources().mobAttack(this), damage);
        cooldowns.use(ability, now);
        this.swing(InteractionHand.MAIN_HAND);
    }

    /** Sigue al dueño, se queda quieto o sentado según su comando, y defiende al dueño. */
    private void updateOwnerBehavior() {
        if (!domestication.isTamed()) {
            return;
        }
        Player owner = ownerPlayer();
        switch (domestication.mode()) {
            case SEGUIR -> {
                if (owner != null && this.distanceToSqr(owner) > FOLLOW_DISTANCE_SQ) {
                    this.getNavigation().moveTo(owner, 1.0);
                }
            }
            case QUIETO, SENTADO -> this.getNavigation().stop();
            default -> { }
        }
        if (owner != null && this.getTarget() == null) {
            LivingEntity attacker = owner.getLastHurtByMob();
            if (attacker != null && attacker.isAlive() && attacker != this) {
                this.setTarget(attacker);
            }
        }
    }

    /** Muestra el nivel encima de la criatura y lo actualiza cuando sube. */
    private void updateNameTag() {
        if (creatureLevel != shownLevel) {
            shownLevel = creatureLevel;
            this.setCustomName(Component.literal("Nv " + creatureLevel + " · " + displayName()));
            this.setCustomNameVisible(true);
        }
    }

    @Override
    public boolean canAttack(LivingEntity target) {
        if (ownerUuid != null && ownerUuid.equals(target.getUUID())) {
            return false;
        }
        return super.canAttack(target);
    }

    @Override
    public boolean isFood(ItemStack stack) {
        return stack.is(Items.WHEAT) || stack.is(Items.BEEF) || stack.is(Items.COD) || stack.is(Items.SWEET_BERRIES);
    }

    /** Alimentar: acelera la cría, da experiencia, domestica o pone en celo para reproducirse. */
    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (isFood(held)) {
            if (!this.level().isClientSide()) {
                feedBy(player);
            }
            if (!player.getAbilities().instabuild) {
                held.shrink(1);
            }
            return InteractionResult.SUCCESS;
        }
        if (!this.level().isClientSide() && domestication.isTamed() && player.getUUID().equals(ownerUuid) && held.isEmpty()) {
            Domestication.Mode mode = domestication.cycleCommand();
            player.sendSystemMessage(Component.literal(commandLabel(mode)));
            return InteractionResult.SUCCESS;
        }
        return InteractionResult.PASS;
    }

    private void feedBy(Player player) {
        gainXp(ExperienceRules.feedXp());
        if (this.isBaby()) {
            this.ageUp((int) (Growth.FEED_SPEEDUP_TICKS / 20), true);
            return;
        }
        if (!domestication.isTamed() && domestication.isDomesticable()) {
            if (domestication.feed()) {
                ownerUuid = player.getUUID();
                player.sendSystemMessage(Component.literal(displayName() + " ha sido domesticado"));
            }
            return;
        }
        this.setInLove(player);
    }

    @Override
    public boolean canMate(Animal other) {
        if (other == this || !(other instanceof CreatureEntity mate)) {
            return false;
        }
        if (!this.isInLove() || !mate.isInLove()) {
            return false;
        }
        return Offspring.resolve(species, secondary, mate.species, mate.secondary).isPresent();
    }

    /** La cría empieza siendo bebé: 20 minutos hasta la edad adulta. */
    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob partner) {
        if (!(partner instanceof CreatureEntity mate)) {
            return null;
        }
        Offspring kind = Offspring.resolve(species, secondary, mate.species, mate.secondary).orElse(null);
        if (kind == null) {
            return null;
        }
        EntityType<CreatureEntity> type = kind.isHybrid()
                ? ModEntityTypes.hybridTypeOf(kind.primary(), kind.secondary())
                : ModEntityTypes.typeOf(kind.primary());
        CreatureEntity child = new CreatureEntity(type, level, kind.primary(), kind.secondary());
        child.setAge(-(int) Growth.ADULT_TICKS);
        return child;
    }

    private void gainXp(long amount) {
        CreatureProfile.XpGain gain = currentProfile().gainXp(amount);
        creatureLevel = gain.profile().level();
        creatureXp = gain.profile().xp();
    }

    private CreatureProfile currentProfile() {
        BaseStats stats = isHybrid() ? BaseStats.hybridOf(species.baseStats(), secondary.baseStats()) : species.baseStats();
        return new CreatureProfile(
                isHybrid() ? ModEntityTypes.hybridKey(species, secondary) : species.key(),
                displayName(),
                stats,
                isHybrid() ? (species.rarity().ordinal() >= secondary.rarity().ordinal() ? species.rarity() : secondary.rarity()) : species.rarity(),
                variant(),
                abilities,
                creatureLevel,
                creatureXp,
                Leveling.DEFAULT_MAX_LEVEL);
    }

    public String displayName() {
        return isHybrid() ? species.displayName() + " × " + secondary.displayName() : species.displayName();
    }

    private Player ownerPlayer() {
        return ownerUuid == null ? null : this.level().getPlayerByUUID(ownerUuid);
    }

    private Random rng() {
        if (abilityRandom == null) {
            abilityRandom = new Random(this.random.nextLong());
        }
        return abilityRandom;
    }

    private static String commandLabel(Domestication.Mode mode) {
        return switch (mode) {
            case SEGUIR -> "Modo: seguir";
            case QUIETO -> "Modo: quieto";
            case SENTADO -> "Modo: sentado";
            case SALVAJE -> "Salvaje";
        };
    }

    /** Habilidades de un híbrido: se eligen con una semilla fija por par, así todos los ejemplares son iguales. */
    private static List<Ability> hybridAbilities(Species a, Species b) {
        return Hybrid.breed(a, b, new Random(31L * a.ordinal() + b.ordinal())).abilities();
    }

    /** Un animal sienta solo si es terrestre y tiene entre 1 y 4 patas. */
    public static boolean canSitOn(Species s) {
        long legs = Rigs.of(s).parts().stream().filter(p -> p.role() == Rig.Role.LEG).count();
        return s.movement() == Movement.TERRESTRE && legs >= 1 && legs <= 4;
    }

    @Override
    protected void addAdditionalSaveData(ValueOutput output) {
        super.addAdditionalSaveData(output);
        output.putInt(NBT_VARIANT, variantIndex());
        output.putInt(NBT_LEVEL, creatureLevel);
        output.putLong(NBT_XP, creatureXp);
        output.putInt(NBT_FOOD, domestication.foodGiven());
        output.putString(NBT_MODE, domestication.mode().name());
        output.putLong(NBT_PENDING, Math.round(pendingBlocks * 100.0));
        if (ownerUuid != null) {
            output.putString(NBT_OWNER, ownerUuid.toString());
        }
    }

    @Override
    protected void readAdditionalSaveData(ValueInput input) {
        super.readAdditionalSaveData(input);
        int variant = input.getInt(NBT_VARIANT).orElse(0);
        this.entityData.set(DATA_VARIANT, Math.floorMod(variant, ColorVariant.COUNT));
        this.variantAssigned = input.getInt(NBT_VARIANT).isPresent();
        this.creatureLevel = Math.max(1, Math.min(Leveling.DEFAULT_MAX_LEVEL, input.getInt(NBT_LEVEL).orElse(1)));
        this.creatureXp = Math.max(0L, input.getLong(NBT_XP).orElse(0L));
        this.pendingBlocks = input.getLong(NBT_PENDING).orElse(0L) / 100.0;

        String rawMode = input.getString(NBT_MODE).orElse("SALVAJE");
        Domestication.Mode mode;
        try {
            mode = Domestication.Mode.valueOf(rawMode);
        } catch (IllegalArgumentException e) {
            mode = Domestication.Mode.SALVAJE;
        }
        domestication.restore(input.getInt(NBT_FOOD).orElse(0), mode);

        String rawOwner = input.getString(NBT_OWNER).orElse(null);
        this.ownerUuid = rawOwner == null ? null : UUID.fromString(rawOwner);
    }
}
