package com.monstercollector.entity;

import com.monstercollector.domain.Behavior;
import com.monstercollector.domain.BaseStats;
import com.monstercollector.domain.ColorVariant;
import com.monstercollector.domain.Leveling;
import com.monstercollector.domain.Movement;
import com.monstercollector.domain.Species;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.WaterBoundPathNavigation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.Vec3;

/**
 * Criatura de Monster Collector. Una clase para las 44 especies; la especie la fija el tipo de entidad.
 * Guarda variante, nivel y experiencia en el NBT, así Cápsulas la captura y la libera sin perder nada.
 */
public class CreatureEntity extends PathfinderMob {

    private static final EntityDataAccessor<Integer> DATA_VARIANT =
            SynchedEntityData.defineId(CreatureEntity.class, EntityDataSerializers.INT);

    private static final String NBT_VARIANT = "mc_variant";
    private static final String NBT_LEVEL = "mc_level";
    private static final String NBT_XP = "mc_xp";

    private final Species species;
    private boolean variantAssigned;
    private int creatureLevel = 1;
    private long creatureXp;

    public CreatureEntity(EntityType<? extends CreatureEntity> type, Level level, Species species) {
        super(type, level);
        this.species = species;
        if (species.movement() == Movement.VOLADOR) {
            this.moveControl = new FlyingMoveControl(this, 10, true);
            this.navigation = new FlyingPathNavigation(this, level);
            this.setNoGravity(true);
        } else if (species.movement() == Movement.ACUATICO) {
            this.navigation = new WaterBoundPathNavigation(this, level);
        }
    }

    /** Atributos por defecto de la especie: vida, daño y velocidad del catálogo. */
    public static AttributeSupplier.Builder createAttributes(Species species) {
        BaseStats st = species.baseStats();
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, st.maxHealth())
                .add(Attributes.ATTACK_DAMAGE, st.attackDamage())
                .add(Attributes.MOVEMENT_SPEED, st.movementSpeed());
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_VARIANT, 0);
    }

    /**
     * Se llama desde el constructor de Mob, antes de que los campos de esta clase estén asignados,
     * así que la especie se consulta por el tipo de entidad.
     */
    @Override
    protected void registerGoals() {
        Species s = ModEntityTypes.speciesOf(this.getType());
        this.goalSelector.addGoal(0, new FloatGoal(this));
        if (s != null && s.behavior() == Behavior.AGRESIVO) {
            this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.0, false));
            this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, true));
        }
        this.targetSelector.addGoal(2, new HurtByTargetGoal(this));
        this.goalSelector.addGoal(2, new RandomStrollGoal(this, 1.0));
        this.goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 6.0f));
        this.goalSelector.addGoal(4, new RandomLookAroundGoal(this));
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide() && !this.variantAssigned) {
            this.entityData.set(DATA_VARIANT, this.random.nextInt(ColorVariant.COUNT));
            this.variantAssigned = true;
        }
    }

    public Species species() {
        return species;
    }

    public int variantIndex() {
        return this.entityData.get(DATA_VARIANT);
    }

    public ColorVariant variant() {
        return ColorVariant.byIndex(variantIndex());
    }

    public int creatureLevel() {
        return creatureLevel;
    }

    /** Parado o casi parado: la cabeza baja en la animación de descanso. */
    public boolean isResting() {
        Vec3 v = this.getDeltaMovement();
        return v.x * v.x + v.z * v.z < 1.0E-4;
    }

    public boolean isAttacking() {
        return this.getTarget() != null;
    }

    @Override
    protected void addAdditionalSaveData(ValueOutput output) {
        super.addAdditionalSaveData(output);
        output.putInt(NBT_VARIANT, variantIndex());
        output.putInt(NBT_LEVEL, creatureLevel);
        output.putLong(NBT_XP, creatureXp);
    }

    @Override
    protected void readAdditionalSaveData(ValueInput input) {
        super.readAdditionalSaveData(input);
        int variant = input.getInt(NBT_VARIANT).orElse(0);
        this.entityData.set(DATA_VARIANT, Math.floorMod(variant, ColorVariant.COUNT));
        this.variantAssigned = input.getInt(NBT_VARIANT).isPresent();
        this.creatureLevel = Math.max(1, Math.min(Leveling.DEFAULT_MAX_LEVEL, input.getInt(NBT_LEVEL).orElse(1)));
        this.creatureXp = Math.max(0L, input.getLong(NBT_XP).orElse(0L));
    }
}
