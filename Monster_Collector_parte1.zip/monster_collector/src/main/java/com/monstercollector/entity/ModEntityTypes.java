package com.monstercollector.entity;

import com.monstercollector.MonsterCollector;
import com.monstercollector.domain.Species;
import com.monstercollector.rig.Rig;
import com.monstercollector.rig.Rigs;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;

/** Registro de las 44 especies como tipos de entidad. */
public final class ModEntityTypes {

    private static final Map<Species, EntityType<CreatureEntity>> TYPES = new EnumMap<>(Species.class);
    private static final Map<EntityType<?>, Species> BY_TYPE = new HashMap<>();

    private ModEntityTypes() {}

    public static void registerAll() {
        for (Species s : Species.values()) {
            Rig rig = Rigs.of(s);
            ResourceKey<EntityType<?>> key = ResourceKey.create(
                    Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath(MonsterCollector.MOD_ID, s.key()));
            EntityType<CreatureEntity> type = Registry.register(
                    BuiltInRegistries.ENTITY_TYPE,
                    key,
                    EntityType.Builder.<CreatureEntity>of((t, level) -> new CreatureEntity(t, level, s), MobCategory.CREATURE)
                            .sized((float) rig.widthBlocks(), (float) rig.heightBlocks())
                            .clientTrackingRange(8)
                            .updateInterval(3)
                            .build(key));
            TYPES.put(s, type);
            BY_TYPE.put(type, s);
            FabricDefaultAttributeRegistry.register(type, CreatureEntity.createAttributes(s));
        }
    }

    public static EntityType<CreatureEntity> typeOf(Species species) {
        return TYPES.get(species);
    }

    /** Especie de un tipo de entidad, o null si no es de Monster Collector. */
    public static Species speciesOf(EntityType<?> type) {
        return BY_TYPE.get(type);
    }
}
