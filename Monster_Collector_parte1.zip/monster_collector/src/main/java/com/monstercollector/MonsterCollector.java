package com.monstercollector;

import com.monstercollector.domain.Catalog;
import net.fabricmc.api.ModInitializer;

public class MonsterCollector implements ModInitializer {
    public static final String MOD_ID = "monster_collector";

    @Override
    public void onInitialize() {
        // Falla al arrancar si el catálogo de especies, variantes o habilidades está mal definido.
        Catalog.requireValid();
    }
}
