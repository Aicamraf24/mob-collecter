package com.monstercollector;

import com.monstercollector.domain.Abilities;
import com.monstercollector.domain.Ability;
import com.monstercollector.domain.Breeding;
import com.monstercollector.domain.Catalog;
import com.monstercollector.domain.ColorVariant;
import com.monstercollector.domain.CreatureProfile;
import com.monstercollector.domain.Encyclopedia;
import com.monstercollector.domain.Growth;
import com.monstercollector.domain.Hybrid;
import com.monstercollector.domain.Rarity;
import com.monstercollector.domain.SpawnTable;
import com.monstercollector.domain.Species;
import com.monstercollector.domain.BaseStats;

import java.util.List;
import java.util.Random;

/**
 * Comprobaciones de la lógica pura del mod (sin Minecraft).
 * Se ejecuta con: java -cp build/catalog-check com.monstercollector.CatalogCheck
 */
public final class CatalogCheck {

    private static int passed = 0;
    private static int failed = 0;

    private static void check(String name, boolean ok) {
        if (ok) {
            passed++;
            System.out.println("  PASS  " + name);
        } else {
            failed++;
            System.out.println("  FAIL  " + name);
        }
    }

    private static boolean throwsIllegalArgument(Runnable action) {
        try {
            action.run();
            return false;
        } catch (IllegalArgumentException expected) {
            return true;
        }
    }

    private static boolean near(double a, double b, double tol) {
        return Math.abs(a - b) <= tol;
    }

    public static void main(String[] args) {
        System.setOut(new java.io.PrintStream(System.out, true, java.nio.charset.StandardCharsets.UTF_8));
        Random rng = new Random(20260611L);

        System.out.println("== Catálogo ==");
        check("hay al menos 25 especies", Species.values().length >= Catalog.MIN_SPECIES);
        check("hay exactamente 25 especies de la especificación", Species.values().length == 25);
        check("validate() no devuelve errores", Catalog.validate().isEmpty());
        check("cada especie tiene una rareza definida", java.util.Arrays.stream(Species.values()).allMatch(s -> s.rarity() != null));
        check("hay 5 variantes de color", ColorVariant.values().length == 5);
        check("cada variante tiene probabilidad exacta de 0.2", java.util.Arrays.stream(ColorVariant.values()).allMatch(v -> near(v.probability(), 0.2, 1e-12)));
        check("hay 125 combinaciones base", Encyclopedia.totalCombinations() == 125);
        check("las 3 especies legendarias existen", java.util.Arrays.stream(Species.values()).filter(s -> s.rarity() == Rarity.LEGENDARY).count() == 3);
        check("un Ability con reutilización de 1 s es rechazado", throwsIllegalArgument(() -> new Ability("x", "x", Ability.Kind.OFENSIVA, 1, 1.0)));
        check("una ofensiva con potencia 0.5 es rechazada", throwsIllegalArgument(() -> new Ability("x", "x", Ability.Kind.OFENSIVA, 5, 0.5)));
        check("estadísticas no positivas son rechazadas", throwsIllegalArgument(() -> new BaseStats(0, 1, 1)));

        System.out.println("== Variantes y rareza (muestreo) ==");
        int samples = 1_000_000;
        int[] variantCount = new int[ColorVariant.COUNT];
        for (int i = 0; i < samples; i++) {
            variantCount[ColorVariant.random(rng).ordinal()]++;
        }
        boolean uniform = true;
        for (int c : variantCount) {
            if (!near((double) c / samples, 0.2, 0.002)) uniform = false;
        }
        check("1.000.000 tiradas: cada variante cae en 20 % ± 0.2 %", uniform);

        List<Species> all = List.of(Species.values());
        int raritySamples = 500_000;
        int[][] byRarityVariant = new int[Rarity.values().length][ColorVariant.COUNT];
        int[] rarityCount = new int[Rarity.values().length];
        for (int i = 0; i < raritySamples; i++) {
            Species s = SpawnTable.pick(all, rng);
            ColorVariant v = ColorVariant.random(rng);
            rarityCount[s.rarity().ordinal()]++;
            byRarityVariant[s.rarity().ordinal()][v.ordinal()]++;
        }
        boolean rarityFollowsWeights =
                near((double) rarityCount[Rarity.COMMON.ordinal()] / raritySamples, 0.60, 0.01)
                && near((double) rarityCount[Rarity.LEGENDARY.ordinal()] / raritySamples, 0.01, 0.003);
        check("la rareza controla la frecuencia (común ≈ 60 %, legendaria ≈ 1 %)", rarityFollowsWeights);

        boolean variantIndependent = true;
        for (Rarity r : Rarity.values()) {
            int total = rarityCount[r.ordinal()];
            if (total < 1000) continue;
            for (int c : byRarityVariant[r.ordinal()]) {
                if (!near((double) c / total, 0.2, 0.03)) variantIndependent = false;
            }
        }
        check("dentro de cada rareza, las variantes siguen siendo 20 % cada una", variantIndependent);

        System.out.println("== Reproducción ==");
        boolean symmetric = true;
        for (Species a : Species.values()) {
            for (Species b : Species.values()) {
                if (Breeding.canBreed(a, b) != Breeding.canBreed(b, a)) symmetric = false;
            }
        }
        check("la compatibilidad es simétrica", symmetric);
        check("los jefes no tienen parejas", Breeding.matesOf(Species.DRAGON_DE_CRISTAL).isEmpty() && Breeding.matesOf(Species.LEVIATAN_MENOR).isEmpty());
        check("una especie normal puede reproducirse consigo misma", Breeding.canBreed(Species.VELOCIRAPTOR, Species.VELOCIRAPTOR));
        check("T-Rex y Triceratops no son compatibles", !Breeding.canBreed(Species.TYRANNOSAURUS_REX, Species.TRICERATOPS));
        check("Lobo de Sombras y Velociraptor sí son compatibles (par explícito)", Breeding.canBreed(Species.LOBO_DE_SOMBRAS, Species.VELOCIRAPTOR));
        check("las crías necesitan ser adultas para criar", !Breeding.readyToBreed(Growth.newborn(), 0));

        System.out.println("== Híbridos ==");
        Hybrid h1 = Hybrid.breed(Species.VELOCIRAPTOR, Species.TYRANNOSAURUS_REX, new Random(7));
        Hybrid h2 = Hybrid.breed(Species.TYRANNOSAURUS_REX, Species.VELOCIRAPTOR, new Random(7));
        check("el híbrido tiene clave estable sin importar el orden", h1.key().equals(h2.key()) && h1.key().equals("tyrannosaurus_rex+velociraptor"));
        check("nombre de híbrido determinista (Tyrannoraptor)", h1.name().equals("Tyrannoraptor") && h2.name().equals("Tyrannoraptor"));
        check("la rareza del híbrido es la más alta de sus padres", h1.rarity() == Rarity.EPIC);
        check("la vida del híbrido es la media de los padres con vigor 5 %", near(h1.stats().maxHealth(), (90 + 36) / 2.0 * 1.05, 1e-9));
        check("el híbrido tiene 1 o 2 habilidades", h1.abilities().size() >= 1 && h1.abilities().size() <= 2);
        check("el mismo seed produce el mismo híbrido", Hybrid.breed(Species.VELOCIRAPTOR, Species.TYRANNOSAURUS_REX, new Random(7)).equals(h1));
        check("dos especies de la misma criatura no generan híbrido", throwsIllegalArgument(() -> Hybrid.breed(Species.VELOCIRAPTOR, Species.VELOCIRAPTOR, rng)));
        check("un jefe no puede generar híbrido", throwsIllegalArgument(() -> Hybrid.breed(Species.DRAGON_DE_CRISTAL, Species.GRIFO_SALVAJE, rng)));
        check("un híbrido de terópodos puede cruzarse con Carnotaurus", h1.canBreedWith(Species.CARNOTAURUS));
        check("un híbrido de terópodos no puede cruzarse con Triceratops", !h1.canBreedWith(Species.TRICERATOPS));
        boolean allHybridsValid = true;
        for (Species a : Species.values()) {
            for (Species b : Species.values()) {
                if (a == b || !Breeding.canBreed(a, b)) continue;
                Hybrid h = Hybrid.breed(a, b, rng);
                if (h.abilities().size() > 2 || h.abilities().isEmpty()) allHybridsValid = false;
            }
        }
        check("todos los híbridos compatibles tienen de 1 a 2 habilidades", allHybridsValid);

        System.out.println("== Niveles y experiencia ==");
        CreatureProfile wild = CreatureProfile.wild(Species.VELOCIRAPTOR, ColorVariant.AZUL, 50);
        check("un salvaje empieza en nivel 1 sin experiencia", wild.level() == 1 && wild.xp() == 0);
        check("23 de experiencia suben al nivel 2", wild.gainXp(23).profile().level() == 2);
        check("22 de experiencia no suben de nivel", wild.gainXp(22).profile().level() == 1);
        CreatureProfile.XpGain huge = wild.gainXp(1_000_000L);
        check("el nivel nunca pasa del máximo configurado", huge.profile().level() == 50);
        check("al llegar al máximo la experiencia queda en 0", huge.profile().xp() == 0);
        check("levelsGained coincide con la subida real", huge.levelsGained() == 49);
        check("las estadísticas suben con el nivel", new CreatureProfile(wild.key(), wild.name(), wild.baseStats(), wild.rarity(), wild.variant(), wild.abilities(), 10, 0, 50).currentStats().maxHealth() > wild.currentStats().maxHealth());
        check("el nivel máximo no puede superar 100", throwsIllegalArgument(() -> CreatureProfile.wild(Species.VELOCIRAPTOR, ColorVariant.ROJA, 101)));
        check("la curva de experiencia crece con el nivel", Leveling_increasing());

        System.out.println("== Crecimiento ==");
        Growth cria = Growth.newborn();
        check("una cría nueva empieza en etapa CRIA", cria.stage() == Growth.Stage.CRIA && !cria.isAdult());
        check("tras el tiempo completo es adulta", cria.tick(Growth.ADULT_TICKS).isAdult());
        check("alimentar acelera el crecimiento", cria.feed().remainingTicks() == Growth.ADULT_TICKS - Growth.FEED_SPEEDUP_TICKS);
        check("alimentar a un adulto no hace nada", Growth.withRemaining(0).feed().isAdult());

        System.out.println("== Enciclopedia ==");
        Encyclopedia enc = new Encyclopedia();
        check("enciclopedia vacía: 0 %", enc.completionPercent() == 0.0);
        enc.recordSpecimen(Species.VELOCIRAPTOR, ColorVariant.AZUL);
        enc.recordSpecimen(Species.VELOCIRAPTOR, ColorVariant.AZUL);
        check("una combinación de 125 da 0.8 %", near(enc.completionPercent(), 0.8, 1e-9));
        check("cuenta los ejemplares descubiertos", enc.copies(Species.VELOCIRAPTOR, ColorVariant.AZUL) == 2);
        check("lista las variantes que faltan", enc.missingVariants(Species.VELOCIRAPTOR).size() == 4);
        enc.recordHybrid(h1);
        check("los híbridos no suben el porcentaje de colección", near(enc.completionPercent(), 0.8, 1e-9));
        check("los híbridos se registran aparte", enc.hybridsDiscovered() == 1);
        Encyclopedia full = new Encyclopedia();
        for (Species s : Species.values()) for (ColorVariant v : ColorVariant.values()) full.recordSpecimen(s, v);
        check("colección completa: 100 %", near(full.completionPercent(), 100.0, 1e-9));
        check("con colección completa no faltan especies", full.missingSpecies().isEmpty());

        System.out.println();
        System.out.println("Resultado: " + passed + " correctas, " + failed + " fallidas");
        if (failed > 0) {
            System.exit(1);
        }
    }

    private static boolean Leveling_increasing() {
        for (int lvl = 1; lvl < 100; lvl++) {
            if (com.monstercollector.domain.Leveling.xpToNextLevel(lvl + 1) <= com.monstercollector.domain.Leveling.xpToNextLevel(lvl)) {
                return false;
            }
        }
        return true;
    }
}
