package com.monstercollector;

import com.monstercollector.domain.Abilities;
import com.monstercollector.domain.Ability;
import com.monstercollector.domain.Breeding;
import com.monstercollector.domain.Catalog;
import com.monstercollector.domain.ColorVariant;
import com.monstercollector.domain.CreatureProfile;
import com.monstercollector.domain.Encyclopedia;
import com.monstercollector.domain.Growth;
import com.monstercollector.domain.Hybrid;
import com.monstercollector.domain.Leveling;
import com.monstercollector.domain.Rarity;
import com.monstercollector.domain.SpawnRules;
import com.monstercollector.domain.SpawnTable;
import com.monstercollector.domain.Species;
import com.monstercollector.domain.BaseStats;
import com.monstercollector.rig.Rig;
import com.monstercollector.rig.Rigs;
import com.monstercollector.rig.TexturePacker;

import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Random;

/**
 * Comprobaciones de la lógica pura y de los modelos (sin Minecraft).
 * Ejecutar: java -cp build/catalog-check com.monstercollector.CatalogCheck
 */
public final class CatalogCheck {

    private static int passed = 0;
    private static int failed = 0;

    private static void check(String name, boolean ok) {
        if (ok) {
            passed++;
            System.out.println("  PASS  " + name);
        } else {
            failed++;
            System.out.println("  FAIL  " + name);
        }
    }

    private static boolean throwsIllegalArgument(Runnable action) {
        try {
            action.run();
            return false;
        } catch (IllegalArgumentException expected) {
            return true;
        }
    }

    private static boolean throwsIllegalState(Runnable action) {
        try {
            action.run();
            return false;
        } catch (IllegalStateException expected) {
            return true;
        }
    }

    private static boolean near(double a, double b, double tol) {
        return Math.abs(a - b) <= tol;
    }

    public static void main(String[] args) {
        System.setOut(new PrintStream(System.out, true, StandardCharsets.UTF_8));
        Random rng = new Random(20260611L);

        System.out.println("== Catálogo ==");
        check("hay 44 especies (25 de la especificación + 19 extras)", Species.values().length == 44);
        check("hay al menos 25 especies", Species.values().length >= Catalog.MIN_SPECIES);
        check("validate() no devuelve errores", Catalog.validate().isEmpty());
        check("hay 5 variantes de color", ColorVariant.values().length == 5);
        check("cada variante tiene probabilidad exacta de 0.2",
                java.util.Arrays.stream(ColorVariant.values()).allMatch(v -> near(v.probability(), 0.2, 1e-12)));
        check("hay 220 combinaciones base (44 x 5)", Encyclopedia.totalCombinations() == 220);
        check("hay 3 especies legendarias", java.util.Arrays.stream(Species.values()).filter(s -> s.rarity() == Rarity.LEGENDARY).count() == 3);
        check("reutilización de 1 s es rechazada", throwsIllegalArgument(() -> new Ability("x", "x", Ability.Kind.OFENSIVA, 1, 1.0)));
        check("ofensiva con potencia 0.5 es rechazada", throwsIllegalArgument(() -> new Ability("x", "x", Ability.Kind.OFENSIVA, 5, 0.5)));
        check("estadísticas no positivas son rechazadas", throwsIllegalArgument(() -> new BaseStats(0, 1, 1)));
        check("Abilities.ALL tiene ids únicos", Abilities.ALL.stream().map(Ability::id).distinct().count() == Abilities.ALL.size());
        check("cada variante tiene su índice", ColorVariant.byIndex(5) == ColorVariant.ROJA && ColorVariant.byIndex(-1) == ColorVariant.DORADA);

        System.out.println("== Modelos (rig) ==");
        check("hay un modelo por especie", Rigs.count() == Species.values().length);
        boolean allPacked = true;
        boolean allInside = true;
        boolean allNoOverlap = true;
        boolean allSized = true;
        for (Species s : Species.values()) {
            Rig rig = Rigs.of(s);
            allPacked &= rig.parts().size() >= 3;
            for (Rig.Part p : rig.parts()) {
                allInside &= p.u() >= 0 && p.v() >= 0 && p.u() + p.atlasWidth() <= Rig.ATLAS_SIZE && p.v() + p.atlasHeight() <= Rig.ATLAS_SIZE;
            }
            allNoOverlap &= TexturePacker.overlapFree(rig.parts());
            allSized &= rig.widthBlocks() > 0 && rig.heightBlocks() > 0 && rig.heightBlocks() <= 3.0;
        }
        check("cada modelo tiene al menos 3 piezas", allPacked);
        check("todas las regiones de textura caben en el atlas", allInside);
        check("ninguna región de textura se solapa", allNoOverlap);
        check("hitbox razonable en todas las especies", allSized);
        check("una línea mal formada es rechazada", throwsIllegalArgument(() -> Rig.parse("x", "cuerpo BODY 0 0 0 1 1")));
        check("un rol desconocido es rechazado", throwsIllegalArgument(() -> Rig.parse("x", "cuerpo NADA 0 0 0 1 1 1")));
        check("un nombre de pieza duplicado es rechazado", throwsIllegalArgument(() -> Rig.parse("x", "a BODY 0 0 0 1 1 1\na HEAD 0 0 0 1 1 1")));
        check("un atlas sin espacio se detecta", throwsIllegalState(() -> TexturePacker.pack(
                List.of(new Rig.Part("gigante", Rig.Role.BODY, 0, 0, 0, 100, 100, 100, 0, 0)), Rig.ATLAS_SIZE)));

        System.out.println("== Variantes y rareza (muestreo) ==");
        int samples = 1_000_000;
        int[] variantCount = new int[ColorVariant.COUNT];
        for (int i = 0; i < samples; i++) {
            variantCount[ColorVariant.random(rng).ordinal()]++;
        }
        boolean uniform = true;
        for (int c : variantCount) {
            if (!near((double) c / samples, 0.2, 0.002)) uniform = false;
        }
        check("1.000.000 tiradas: cada variante cae en 20 % ± 0.2 %", uniform);

        List<Species> all = List.of(Species.values());
        int raritySamples = 500_000;
        int[][] byRarityVariant = new int[Rarity.values().length][ColorVariant.COUNT];
        int[] rarityCount = new int[Rarity.values().length];
        for (int i = 0; i < raritySamples; i++) {
            Species s = SpawnTable.pick(all, rng);
            ColorVariant v = ColorVariant.random(rng);
            rarityCount[s.rarity().ordinal()]++;
            byRarityVariant[s.rarity().ordinal()][v.ordinal()]++;
        }
        boolean rarityFollowsWeights =
                near((double) rarityCount[Rarity.COMMON.ordinal()] / raritySamples, 0.60, 0.01)
                && near((double) rarityCount[Rarity.LEGENDARY.ordinal()] / raritySamples, 0.01, 0.003);
        check("la rareza controla la frecuencia (común ≈ 60 %, legendaria ≈ 1 %)", rarityFollowsWeights);

        boolean variantIndependent = true;
        for (Rarity r : Rarity.values()) {
            int total = rarityCount[r.ordinal()];
            if (total < 1000) continue;
            for (int c : byRarityVariant[r.ordinal()]) {
                if (!near((double) c / total, 0.2, 0.03)) variantIndependent = false;
            }
        }
        check("dentro de cada rareza, las variantes siguen siendo 20 % cada una", variantIndependent);

        System.out.println("== Aparición natural ==");
        boolean weightsDecrease = SpawnRules.weight(Rarity.COMMON) > SpawnRules.weight(Rarity.UNCOMMON)
                && SpawnRules.weight(Rarity.UNCOMMON) > SpawnRules.weight(Rarity.RARE)
                && SpawnRules.weight(Rarity.RARE) > SpawnRules.weight(Rarity.EPIC)
                && SpawnRules.weight(Rarity.EPIC) >= SpawnRules.weight(Rarity.LEGENDARY);
        check("las especies raras tienen menos peso de aparición", weightsDecrease);
        boolean groupsValid = true;
        for (Rarity r : Rarity.values()) {
            if (SpawnRules.weight(r) <= 0 || SpawnRules.minGroupSize(r) < 1 || SpawnRules.maxGroupSize(r) < SpawnRules.minGroupSize(r)) groupsValid = false;
        }
        check("pesos y tamaños de grupo válidos para todas las rarezas", groupsValid);
        check("las especies legendarias aparecen en grupos de 1", SpawnRules.maxGroupSize(Rarity.LEGENDARY) == 1);

        System.out.println("== Reproducción ==");
        boolean symmetric = true;
        for (Species a : Species.values()) {
            for (Species b : Species.values()) {
                if (Breeding.canBreed(a, b) != Breeding.canBreed(b, a)) symmetric = false;
            }
        }
        check("la compatibilidad es simétrica", symmetric);
        check("no hay jefes: todas las especies tienen parejas", java.util.Arrays.stream(Species.values()).allMatch(s -> !Breeding.matesOf(s).isEmpty()));
        check("una especie puede reproducirse consigo misma", Breeding.canBreed(Species.VELOCIRAPTOR, Species.VELOCIRAPTOR));
        check("T-Rex y Triceratops no son compatibles", !Breeding.canBreed(Species.TYRANNOSAURUS_REX, Species.TRICERATOPS));
        check("T-Rex y Carnotaurus sí son compatibles (mismo linaje)", Breeding.canBreed(Species.TYRANNOSAURUS_REX, Species.CARNOTAURUS));
        check("Lobo de Sombras y Velociraptor sí son compatibles (par explícito)", Breeding.canBreed(Species.LOBO_DE_SOMBRAS, Species.VELOCIRAPTOR));
        check("Dragón de Cristal y Grifo Salvaje sí son compatibles", Breeding.canBreed(Species.DRAGON_DE_CRISTAL, Species.GRIFO_SALVAJE));
        check("una cría necesita ser adulta para criar", !Breeding.readyToBreed(Growth.newborn(), 0));

        System.out.println("== Híbridos ==");
        Hybrid h1 = Hybrid.breed(Species.TYRANNOSAURUS_REX, Species.CARNOTAURUS, new Random(7));
        Hybrid h2 = Hybrid.breed(Species.CARNOTAURUS, Species.TYRANNOSAURUS_REX, new Random(7));
        check("la clave del híbrido no depende del orden", h1.key().equals(h2.key()) && h1.key().equals("tyrannosaurus_rex+carnotaurus"));
        check("nombre de híbrido determinista (Tyrannotaurus)", h1.name().equals("Tyrannotaurus") && h2.name().equals("Tyrannotaurus"));
        check("la rareza del híbrido es la más alta de sus padres", h1.rarity() == Rarity.EPIC);
        check("la vida del híbrido es la media de los padres con vigor 5 %", near(h1.stats().maxHealth(), (90 + 58) / 2.0 * 1.05, 1e-9));
        check("el mismo seed produce el mismo híbrido", Hybrid.breed(Species.TYRANNOSAURUS_REX, Species.CARNOTAURUS, new Random(7)).equals(h1));
        check("dos ejemplares de la misma especie no generan híbrido", throwsIllegalArgument(() -> Hybrid.breed(Species.VELOCIRAPTOR, Species.VELOCIRAPTOR, rng)));
        check("una combinación incompatible no genera híbrido", throwsIllegalArgument(() -> Hybrid.breed(Species.TYRANNOSAURUS_REX, Species.TRICERATOPS, rng)));
        check("un híbrido de Tyrannotaurus no puede cruzarse con Triceratops", !h1.canBreedWith(Species.TRICERATOPS));
        check("un híbrido de Tyrannotaurus sí puede cruzarse con Allosaurus", h1.canBreedWith(Species.ALLOSAURUS));
        boolean allHybridsValid = true;
        for (Species a : Species.values()) {
            for (Species b : Species.values()) {
                if (a == b || !Breeding.canBreed(a, b)) continue;
                Hybrid h = Hybrid.breed(a, b, rng);
                if (h.abilities().size() > 2 || h.abilities().isEmpty()) allHybridsValid = false;
            }
        }
        check("todos los híbridos compatibles tienen de 1 a 2 habilidades", allHybridsValid);

        System.out.println("== Niveles y experiencia ==");
        CreatureProfile wild = CreatureProfile.wild(Species.VELOCIRAPTOR, ColorVariant.AZUL, 50);
        check("un salvaje empieza en nivel 1 sin experiencia", wild.level() == 1 && wild.xp() == 0);
        check("23 de experiencia suben al nivel 2", wild.gainXp(23).profile().level() == 2);
        check("22 de experiencia no suben de nivel", wild.gainXp(22).profile().level() == 1);
        CreatureProfile.XpGain huge = wild.gainXp(1_000_000L);
        check("el nivel nunca pasa del máximo configurado", huge.profile().level() == 50);
        check("al llegar al máximo la experiencia queda en 0", huge.profile().xp() == 0);
        check("levelsGained coincide con la subida real", huge.levelsGained() == 49);
        check("las estadísticas suben con el nivel", atLevel(wild, 10).currentStats().maxHealth() > wild.currentStats().maxHealth());
        check("el nivel máximo no puede superar 100", throwsIllegalArgument(() -> CreatureProfile.wild(Species.VELOCIRAPTOR, ColorVariant.ROJA, 101)));
        boolean curveIncreases = true;
        for (int lvl = 1; lvl < 100; lvl++) {
            if (Leveling.xpToNextLevel(lvl + 1) <= Leveling.xpToNextLevel(lvl)) curveIncreases = false;
        }
        check("la curva de experiencia crece con el nivel", curveIncreases);

        System.out.println("== Crecimiento ==");
        Growth cria = Growth.newborn();
        check("una cría nueva empieza en etapa CRIA", cria.stage() == Growth.Stage.CRIA && !cria.isAdult());
        check("tras el tiempo completo es adulta", cria.tick(Growth.ADULT_TICKS).isAdult());
        check("alimentar acelera el crecimiento", cria.feed().remainingTicks() == Growth.ADULT_TICKS - Growth.FEED_SPEEDUP_TICKS);
        check("alimentar a un adulto no hace nada", Growth.withRemaining(0).feed().isAdult());

        System.out.println("== Enciclopedia ==");
        Encyclopedia enc = new Encyclopedia();
        check("enciclopedia vacía: 0 %", enc.completionPercent() == 0.0);
        enc.recordSpecimen(Species.VELOCIRAPTOR, ColorVariant.AZUL);
        enc.recordSpecimen(Species.VELOCIRAPTOR, ColorVariant.AZUL);
        check("una combinación de 220 da 100/220 %", near(enc.completionPercent(), 100.0 / 220.0, 1e-9));
        check("cuenta los ejemplares descubiertos", enc.copies(Species.VELOCIRAPTOR, ColorVariant.AZUL) == 2);
        check("lista las variantes que faltan", enc.missingVariants(Species.VELOCIRAPTOR).size() == 4);
        enc.recordHybrid(h1);
        check("los híbridos no suben el porcentaje de colección", near(enc.completionPercent(), 100.0 / 220.0, 1e-9));
        check("los híbridos se registran aparte", enc.hybridsDiscovered() == 1);
        Encyclopedia full = new Encyclopedia();
        for (Species s : Species.values()) for (ColorVariant v : ColorVariant.values()) full.recordSpecimen(s, v);
        check("colección completa: 100 %", near(full.completionPercent(), 100.0, 1e-9));
        check("con colección completa no faltan especies", full.missingSpecies().isEmpty());

        System.out.println();
        System.out.println("Resultado: " + passed + " correctas, " + failed + " fallidas");
        if (failed > 0) {
            System.exit(1);
        }
    }

    private static CreatureProfile atLevel(CreatureProfile p, int level) {
        return new CreatureProfile(p.key(), p.name(), p.baseStats(), p.rarity(), p.variant(), p.abilities(), level, 0, p.maxLevel());
    }
}
