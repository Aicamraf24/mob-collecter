# Monster Collector

Mod de Fabric para **Minecraft Java 26.1.2**: 44 criaturas coleccionables (las 25 de la especificación y 19 extras),
cinco variantes de color por especie, niveles, habilidades, rarezas, enciclopedia y reproducción.
No hay jefes. Todas las criaturas se capturan con el mod **Cápsulas**, que este mod no modifica.

## Estado: Parte 1 (criaturas en el mundo)

Incluido:
- Las 44 especies como entidades, con anatomía propia (modelo generado a partir de `Rigs.java`).
- Animaciones de caminar, correr en fase de ataque, descanso, vuelo (alas), natación (aletas) y cola.
- 220 texturas (44 especies × 5 variantes) generadas por `tools/generate_assets.py`.
- Variante, nivel y experiencia guardados en el NBT. Cápsulas las conserva al capturar y liberar.
- Idioma en español e inglés.

Pendiente en las partes siguientes:
- Aparición natural por bioma (requiere verificar la API de modificación de biomas en 26.1.2).
- Experiencia por combate, habilidades en combate, crías, reproducción en el mundo, híbridos,
  domesticación, enciclopedia en pantalla y recetas.

## Requisitos

- Minecraft Java 26.1.2, Fabric Loader 0.19.3 y Fabric API 0.150.0+26.1.2 (mismas versiones que Cápsulas).
- Java 25 y Gradle compatible con Loom 1.15.2.

## Compilar

```
gradle build
```

El `.jar` aparece en `build/libs/`.

## Comprobaciones (sin Minecraft)

```
javac -encoding UTF-8 -d build/catalog-check $(find src/main/java/com/monstercollector/domain src/main/java/com/monstercollector/rig -name "*.java") src/test/java/com/monstercollector/CatalogCheck.java
java -cp build/catalog-check com.monstercollector.CatalogCheck
```

63 comprobaciones: catálogo, modelos, reparto de variantes, rareza, reproducción, híbridos, niveles, crecimiento y enciclopedia.

## Regenerar texturas e idioma

```
python3 tools/generate_assets.py
```

## Estructura

```
src/main/java/com/monstercollector/
  MonsterCollector.java        Entrada principal: valida el catálogo y registra las entidades
  domain/                      Lógica pura (especies, variantes, rarezas, habilidades, reproducción, niveles, enciclopedia)
  rig/                         Anatomía de las 44 especies y empaquetado de texturas (puro)
  entity/                      CreatureEntity y registro de tipos de entidad
  client/                      Modelo genérico, renderizador y registro en el cliente
src/main/resources/assets/monster_collector/
  textures/entity/             220 texturas
  lang/                        es_es y en_us
```

## Notas de diseño

- **Captura con Cápsulas.** Cada criatura es un `Mob` y guarda su variante, nivel y experiencia en el NBT.
  Cápsulas la captura con `mob.save` y la recrea con `EntityType.create`, así que no hace falta nada más.
- **Variantes.** Cada variante tiene probabilidad 1/5 (20 %) y no depende de la rareza.
- **Reproducción.** Dos especies se cruzan si comparten linaje o forman uno de los 4 pares explícitos en `Breeding.java`.
