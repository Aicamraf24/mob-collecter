# Monster Collector

Mod de Fabric para **Minecraft Java 26.1.2** que añade criaturas coleccionables: 25 especies obligatorias,
cinco variantes de color por especie, niveles, habilidades, rarezas, enciclopedia, reproducción e híbridos.

> **Estado de esta entrega: Parte 1 de 3.**
> Incluye el esqueleto Gradle/Fabric, el catálogo completo de especies y toda la lógica pura
> (variantes, rarezas, niveles, crecimiento, reproducción, híbridos y enciclopedia), con 52 comprobaciones automáticas.
> **Todavía no añade criaturas al juego**: faltan entidades, modelos 3D, texturas, animaciones, aparición en biomas,
> persistencia en NBT y la interfaz de la enciclopedia. Eso llega en las partes 2 y 3.

## Requisitos

- Minecraft Java 26.1.2
- Fabric Loader 0.19.3 y Fabric API 0.150.0+26.1.2 (mismas versiones que Cápsulas)
- Java 25 para compilar y ejecutar
- Gradle compatible con Loom 1.15.2

## Compilar

El repositorio no incluye `gradle-wrapper.jar` (es binario). Genéralo una vez con tu Gradle local:

```
gradle wrapper
./gradlew build
```

El `.jar` aparece en `build/libs/`.

## Comprobar el catálogo y la lógica

No necesita Minecraft. Requiere una JDK:

```
javac -d build/catalog-check $(find src/main/java/com/monstercollector/domain -name "*.java") src/test/java/com/monstercollector/CatalogCheck.java
java -cp build/catalog-check com.monstercollector.CatalogCheck
```

En Windows usa `dir /s /b src\main\java\com\monstercollector\domain\*.java` o pasa la lista de archivos a mano.
El programa termina con código 1 si alguna comprobación falla.

## Integración con Cápsulas

Monster Collector no tiene sistema de captura propio. Cápsulas captura cualquier `Mob` vivo, salvo el Ender Dragon,
guardando su NBT completo (`mob.save`) y recreándolo con `EntityType.create`. Por eso:

- Cada criatura de Monster Collector debe extender `Mob` y registrar su `EntityType` al arrancar.
- La variante, el nivel, la experiencia y la especie deben guardarse en el NBT de la entidad (en la parte 2).
  Si no, una criatura capturada y liberada volvería como ejemplar diferente.
- Cápsulas no se modifica ni se duplica en este mod. `fabric.mod.json` solo la declara en `suggests`.

## Decisiones de diseño pendientes

- **Jefes capturables.** Por defecto, Dragón de Cristal y Leviatán Menor son jefes: nunca se reproducen y no son domesticables.
  Cápsulas, tal como está, sí podría capturarlos. Hay que decidir si se permite.
- **Pares de reproducción explícitos.** Además de los linajes, hay cuatro pares: Lobo de Sombras con Velociraptor,
  Grifo Salvaje con Pteranodon, Gólem de Cristal con Rinoceronte Acorazado y Escorpión Colosal con Ankylosaurus.
- **Nombres de híbridos.** Se generan a partir de los padres (p. ej. Tyrannoraptor). Puede hacerse una tabla con nombres curados.
- **Pesos de rareza.** Común 60, poco común 25, rara 10, épica 4, legendaria 1. Son valores iniciales ajustables en `Rarity`.

## Estructura

```
src/main/java/com/monstercollector/
  MonsterCollector.java          Entrada de Fabric; valida el catálogo al arrancar
  domain/                        Lógica pura, sin Minecraft (probada)
    Species.java                 Las 25 especies con rareza, estadísticas, linaje, hábitat, jefe/domesticable
    Abilities.java, Ability.java Habilidades con reutilización y potencia validadas
    ColorVariant.java            5 variantes, 20 % cada una, independientes de la rareza
    Rarity.java                  Común a legendaria, con peso de aparición
    Breeding.java                Reglas de reproducción (sin jefes)
    Hybrid.java                  Cría híbrida: nombre, estadísticas, habilidades, variante, rareza
    CreatureProfile.java         Estado de una criatura (nivel, experiencia, estadísticas actuales)
    Leveling.java, Growth.java   Curva de experiencia y crecimiento de crías
    Encyclopedia.java            Descubrimientos y porcentaje de colección (125 combinaciones base)
    SpawnTable.java              Elección de especie según la rareza
    Catalog.java                 Comprobaciones de coherencia del catálogo
src/test/java/com/monstercollector/CatalogCheck.java   Comprobaciones automáticas (52)
```

## Compilación en GitHub Actions

`.github/workflows/build.yml` compila el mod con `gradle build`, ejecuta las comprobaciones del catálogo y sube el `.jar`.
